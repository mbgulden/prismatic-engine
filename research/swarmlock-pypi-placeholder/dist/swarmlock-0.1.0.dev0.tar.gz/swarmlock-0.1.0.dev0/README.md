# Swarmlock

Coordination primitives for autonomous agents. Leases, heartbeats, fencing
tokens, reentrancy, cascade revocation — see `research/swarmlock-spec.md` v0.3.

## Quickstart

```python
from swarmlock import Swarmlock

async with Swarmlock(backend="in_process") as sl:
    async with await sl.lease(resource="orders/cart-7", holder="agent-1",
                              trace_id="abc", ttl_seconds=300) as lease:
        await downstream.write(payload=..., fencing_token=lease.fencing_token)
```

## Status

v0.1 alpha. Reference implementation + failure-mode tests in progress.
