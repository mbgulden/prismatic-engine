"""
test_cross_backend_equivalence.py — SWL-3.6 cross-backend equivalence.

Runs the SAME scenario across all three reference backends and asserts
equivalent observable behavior. This is the contract test that ensures
InProcess / File / Redis all honour the same 8-verb protocol with the
same semantics (reentrancy, fencing tokens, cascade revocation, etc.).

Scenarios covered:
1. Acquire → release → reacquire (fencing token monotonicity)
2. Reentrant acquire (acquisition_count, reentrant flag, no TTL reset)
3. Contention: wait="queue" vs wait="fail"
4. Cascade revocation: revoke_all wipes multiple child leases
5. Steal denied when HELD, succeeds when EXPIRED
6. Renew extends TTL; renew lost for expired lease

The test parameterises over the backend factory.
"""
from __future__ import annotations

import asyncio
import tempfile

import pytest

from swarmlock.types import (
    AcquireRequest, HistoryRequest, InspectRequest, Intent,
    ReleaseRequest, RenewRequest, RevokeAllRequest, StealRequest,
)


# ─────────────────────────────────────────────────────────────
# Backend fixtures — produce identical-shape backends per param
# ─────────────────────────────────────────────────────────────

def _in_process_factory():
    from swarmlock.backends.in_process import InProcessBackend
    return InProcessBackend(admin_token="sekret")


def _file_factory():
    from swarmlock.backends.file import FileBackend
    # Use a fresh tempdir per test (caller's pytest fixture handles it)
    tmp = tempfile.mkdtemp(prefix="swarmlock-eq-")
    return FileBackend(root=tmp, admin_token="sekret")


def _redis_factory():
    import fakeredis.aioredis as faio
    from swarmlock.backends.redis_backend import RedisBackend
    client = faio.FakeRedis()
    be = RedisBackend(client=client, admin_token="sekret")
    return be


@pytest.fixture(
    params=["in_process", "file", "redis"],
    ids=["in_process", "file", "redis"],
)
async def backend_factory(request):
    """Returns a (backend, cleanup_async_fn) tuple."""
    kind = request.param
    if kind == "in_process":
        be = _in_process_factory()
        yield be
    elif kind == "file":
        be = _file_factory()
        yield be
        # File backend leaves state on disk — caller (the test) should not
        # assume cleanup, but pytest tmpdir semantics handle it.
    elif kind == "redis":
        be = _redis_factory()
        await be.start()
        try:
            yield be
        finally:
            await be.stop()


# Helper: ensure async lifecycle is started for all backends.
@pytest.fixture
async def backend(backend_factory):
    """Returns a started backend ready for async operations."""
    # InProcessBackend needs no start; FileBackend needs no start;
    # RedisBackend needs start. Idempotent.
    if hasattr(backend_factory, "start"):
        await backend_factory.start()
    return backend_factory


# ─────────────────────────────────────────────────────────────
# Scenario 1: acquire → release → reacquire (fencing token monotonic)
# ─────────────────────────────────────────────────────────────

async def test_scenario_fencing_token_monotonic_across_release(backend):
    r1 = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    assert r1.is_acquired
    await backend.release(ReleaseRequest(
        lease_id=r1.lease.lease_id, holder="a", reason="done",
    ))
    r2 = await backend.acquire(AcquireRequest(
        resource="r/1", holder="b", ttl_seconds=60,
    ))
    assert r2.is_acquired
    assert r2.lease.fencing_token > r1.lease.fencing_token, (
        f"fencing token must be monotonic across releases "
        f"({r1.lease.fencing_token} → {r2.lease.fencing_token})"
    )


# ─────────────────────────────────────────────────────────────
# Scenario 2: reentrant acquire
# ─────────────────────────────────────────────────────────────

async def test_scenario_reentrant_acquire_increments_count(backend):
    r1 = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
    ))
    assert r1.lease.acquisition_count == 1
    assert r1.lease.reentrant is False
    expires_before = r1.lease.expires_at

    r2 = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
    ))
    assert r2.lease.acquisition_count == 2
    assert r2.lease.reentrant is True
    # TTL NOT reset on reentrant acquire (§14.2)
    assert r2.lease.expires_at == expires_before, (
        f"reentrant acquire must not reset TTL "
        f"(before={expires_before}, after={r2.lease.expires_at})"
    )
    assert r2.lease.fencing_token == r1.lease.fencing_token


# ─────────────────────────────────────────────────────────────
# Scenario 3: contention
# ─────────────────────────────────────────────────────────────

async def test_scenario_contention_queue_mode(backend):
    await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    r = await backend.acquire(AcquireRequest(
        resource="r/1", holder="b", ttl_seconds=60, wait="queue",
    ))
    assert r.status == "queued"
    assert r.current_holder == "a"
    assert r.queue_position == 1


async def test_scenario_contention_fail_mode_raises(backend):
    from swarmlock.errors import ResourceHeldError
    await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    with pytest.raises(ResourceHeldError):
        await backend.acquire(AcquireRequest(
            resource="r/1", holder="b", ttl_seconds=60, wait="fail",
        ))


# ─────────────────────────────────────────────────────────────
# Scenario 4: cascade revocation
# ─────────────────────────────────────────────────────────────

async def test_scenario_revoke_all_cascades(backend):
    r1 = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
        intent=Intent(reason="x", parent_task="task-99"),
    ))
    r2 = await backend.acquire(AcquireRequest(
        resource="r/2", holder="a", ttl_seconds=60,
        intent=Intent(reason="x", parent_task="task-99"),
    ))
    r3 = await backend.acquire(AcquireRequest(
        resource="r/3", holder="a", ttl_seconds=60,
        intent=Intent(reason="x", parent_task="task-99"),
    ))
    rv = await backend.revoke_all(RevokeAllRequest(
        parent_task="task-99", reason="parent died",
        admin_token="sekret",
    ))
    assert rv.status == "revoked"
    assert rv.revoked_count == 3
    assert set(rv.revoked_lease_ids) == {
        r1.lease.lease_id, r2.lease.lease_id, r3.lease.lease_id,
    }
    # All three resources free
    for resource in ["r/1", "r/2", "r/3"]:
        ins = await backend.inspect(InspectRequest(resource=resource))
        assert ins.status == "none"


# ─────────────────────────────────────────────────────────────
# Scenario 5: steal — denied when HELD, succeeds when EXPIRED
# ─────────────────────────────────────────────────────────────

async def test_scenario_steal_denied_when_held(backend):
    await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    steal = await backend.steal(StealRequest(
        resource="r/1", new_holder="b", reason="emergency",
        admin_token="sekret",
    ))
    assert steal.status == "denied"
    assert steal.error_code == "RESOURCE_HELD"


async def test_scenario_steal_succeeds_when_expired(backend):
    r = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=1,
    ))
    await asyncio.sleep(1.2)
    steal = await backend.steal(StealRequest(
        resource="r/1", new_holder="b", reason="recovery",
        admin_token="sekret",
    ))
    assert steal.status == "stolen"
    assert steal.new_fencing_token > r.lease.fencing_token


# ─────────────────────────────────────────────────────────────
# Scenario 6: renew
# ─────────────────────────────────────────────────────────────

async def test_scenario_renew_extends_ttl(backend):
    r = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    renewed = await backend.renew(RenewRequest(
        lease_id=r.lease.lease_id, holder="a", extend_by_seconds=300,
    ))
    assert renewed.status == "renewed"
    assert renewed.expires_at > r.lease.expires_at


async def test_scenario_renew_lost_for_holder_mismatch(backend):
    r = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    renewed = await backend.renew(RenewRequest(
        lease_id=r.lease.lease_id, holder="wrong", extend_by_seconds=300,
    ))
    assert renewed.status == "lost"


# ─────────────────────────────────────────────────────────────
# Scenario 7: inspect shows current state (HELD or NONE)
# ─────────────────────────────────────────────────────────────

async def test_scenario_inspect_shows_held(backend):
    r = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    ins = await backend.inspect(InspectRequest(resource="r/1"))
    assert ins.status == "found"
    assert ins.state == "HELD"
    assert ins.fencing_token == r.lease.fencing_token


async def test_scenario_inspect_shows_none_when_free(backend):
    ins = await backend.inspect(InspectRequest(resource="r/never-held"))
    assert ins.status == "none"


# ─────────────────────────────────────────────────────────────
# Scenario 8: release after reentrant acquire — full release
# ─────────────────────────────────────────────────────────────

async def test_scenario_reentrant_release_full_cycle(backend):
    """Reentrant acquire 3 times → release 3 times → resource free."""
    # Three reentrant acquires — only the third one's lease_id is used below.
    _r1 = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
    ))
    _r2 = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
    ))
    r3 = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
    ))
    assert r3.lease.acquisition_count == 3

    # First release: count 3→2, resource still held
    rel1 = await backend.release(ReleaseRequest(
        lease_id=r3.lease.lease_id, holder="a", reason="done",
    ))
    assert rel1.status == "noop"
    assert rel1.remaining_acquisitions == 2
    ins = await backend.inspect(InspectRequest(resource="r/1"))
    assert ins.status == "found"

    # Second release: count 2→1
    rel2 = await backend.release(ReleaseRequest(
        lease_id=r3.lease.lease_id, holder="a", reason="done",
    ))
    assert rel2.status == "noop"
    assert rel2.remaining_acquisitions == 1

    # Third release: count 1→0, resource freed
    rel3 = await backend.release(ReleaseRequest(
        lease_id=r3.lease.lease_id, holder="a", reason="done",
    ))
    assert rel3.status == "released"
    assert rel3.remaining_acquisitions == 0
    ins = await backend.inspect(InspectRequest(resource="r/1"))
    assert ins.status == "none"


# ─────────────────────────────────────────────────────────────
# Scenario 9: history records all state transitions
# ─────────────────────────────────────────────────────────────

async def test_scenario_history_records_lifecycle(backend):
    r = await backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    await backend.renew(RenewRequest(
        lease_id=r.lease.lease_id, holder="a", extend_by_seconds=120,
    ))
    await backend.release(ReleaseRequest(
        lease_id=r.lease.lease_id, holder="a", reason="done",
    ))
    hist = await backend.history(HistoryRequest(resource="r/1"))
    events = [e.event for e in hist.events]
    # At minimum: acquired, renewed, released must all appear.
    assert "acquired" in events
    assert "renewed" in events
    assert "released" in events
