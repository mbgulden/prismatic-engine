"""
test_file_basic.py — FileBackend happy-path tests (SWL-1.6).

Mirrors the InProcessBackend test suite for the 8 verbs, ensuring the file
backend produces equivalent results (SWL-3.6 cross-backend equivalence).

Each test gets a fresh TemporaryDirectory so the test suite doesn't pollute
``~/.swarmlock`` and tests don't interfere with each other.
"""
from __future__ import annotations

import tempfile

import pytest

from swarmlock.backends.file import FileBackend
from swarmlock.errors import (
    AdminRequiredError, ResourceHeldError,
)
from swarmlock.types import (
    AcquireRequest, HistoryRequest, InspectRequest, Intent, ListRequest,
    ReleaseRequest, RenewRequest, RevokeAllRequest, StealRequest,
)


@pytest.fixture
def file_backend():
    """A FileBackend rooted in a fresh temp directory."""
    with tempfile.TemporaryDirectory() as tmp:
        be = FileBackend(root=tmp, admin_token="sekret")
        yield be


# ─── acquire ──────────────────────────────────────────────────

async def test_acquire_grants_fresh_lease(file_backend):
    r = await file_backend.acquire(AcquireRequest(
        resource="orders/cart-7",
        holder="agent-1",
        ttl_seconds=60,
    ))
    assert r.is_acquired
    assert r.lease.resource == "orders/cart-7"
    assert r.lease.holder == "agent-1"
    assert r.lease.fencing_token == 1
    assert r.lease.acquisition_count == 1
    assert r.lease.reentrant is False


async def test_acquire_returns_queued_when_held(file_backend):
    await file_backend.acquire(AcquireRequest(
        resource="orders/cart-7", holder="agent-1", ttl_seconds=60,
    ))
    r2 = await file_backend.acquire(AcquireRequest(
        resource="orders/cart-7", holder="agent-2", ttl_seconds=60, wait="queue",
    ))
    assert r2.status == "queued"
    assert r2.current_holder == "agent-1"
    assert r2.current_fencing_token == 1
    assert r2.queue_position == 1
    assert r2.retry_after_ms is not None and r2.retry_after_ms > 0


async def test_acquire_raises_when_held_with_fail(file_backend):
    await file_backend.acquire(AcquireRequest(
        resource="orders/cart-7", holder="agent-1", ttl_seconds=60,
    ))
    with pytest.raises(ResourceHeldError) as exc:
        await file_backend.acquire(AcquireRequest(
            resource="orders/cart-7", holder="agent-2", ttl_seconds=60, wait="fail",
        ))
    assert exc.value.code == "RESOURCE_HELD"
    assert exc.value.current_holder == "agent-1"
    assert exc.value.current_fencing_token == 1


async def test_acquire_reentrant_increments_count(file_backend):
    r1 = await file_backend.acquire(AcquireRequest(
        resource="orders/cart-7", holder="agent-1", ttl_seconds=60, trace_id="abc",
    ))
    r2 = await file_backend.acquire(AcquireRequest(
        resource="orders/cart-7", holder="agent-1", ttl_seconds=60, trace_id="abc",
    ))
    assert r1.is_acquired and r2.is_acquired
    assert r2.lease.reentrant is True
    assert r2.lease.acquisition_count == 2
    assert r2.lease.fencing_token == r1.lease.fencing_token  # same token on reentry


async def test_acquire_fencing_token_is_monotonic(file_backend):
    r1 = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    await file_backend.release(ReleaseRequest(
        lease_id=r1.lease.lease_id, holder="a", reason="done",
    ))
    r2 = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="b", ttl_seconds=60,
    ))
    assert r2.lease.fencing_token > r1.lease.fencing_token


async def test_acquire_intent_is_persisted(file_backend):
    r = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
        intent=Intent(reason="checkout", parent_task="flow-1", trace_id="t1"),
    ))
    assert r.lease.intent is not None
    assert r.lease.intent.reason == "checkout"
    assert r.lease.parent_task == "flow-1"


# ─── renew ────────────────────────────────────────────────────

async def test_renew_extends_ttl(file_backend):
    r = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    original_expires = r.lease.expires_at
    renewed = await file_backend.renew(RenewRequest(
        lease_id=r.lease.lease_id, holder="a", extend_by_seconds=120,
    ))
    assert renewed.status == "renewed"
    assert renewed.expires_at > original_expires


async def test_renew_returns_lost_for_missing_lease(file_backend):
    renewed = await file_backend.renew(RenewRequest(
        lease_id="lease_nonexistent", holder="a", extend_by_seconds=120,
    ))
    assert renewed.status == "lost"


async def test_renew_returns_lost_for_holder_mismatch(file_backend):
    r = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    renewed = await file_backend.renew(RenewRequest(
        lease_id=r.lease.lease_id, holder="b", extend_by_seconds=120,
    ))
    assert renewed.status == "lost"


# ─── release ──────────────────────────────────────────────────

async def test_release_frees_resource(file_backend):
    r = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    rel = await file_backend.release(ReleaseRequest(
        lease_id=r.lease.lease_id, holder="a", reason="done",
    ))
    assert rel.status == "released"
    ins = await file_backend.inspect(InspectRequest(resource="r/1"))
    assert ins.status == "none"


async def test_release_reentrant_decrements(file_backend):
    await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
    ))
    r2 = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
    ))
    rel = await file_backend.release(ReleaseRequest(
        lease_id=r2.lease.lease_id, holder="a", reason="done",
    ))
    assert rel.status == "noop"
    assert rel.remaining_acquisitions == 1
    # Resource is still held
    ins = await file_backend.inspect(InspectRequest(resource="r/1"))
    assert ins.status == "found"


# ─── inspect ──────────────────────────────────────────────────

async def test_inspect_returns_none_when_free(file_backend):
    ins = await file_backend.inspect(InspectRequest(resource="r/1"))
    assert ins.status == "none"
    assert ins.resource == "r/1"


async def test_inspect_returns_lease_when_held(file_backend):
    r = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    ins = await file_backend.inspect(InspectRequest(resource="r/1"))
    assert ins.status == "found"
    assert ins.lease_id == r.lease.lease_id
    assert ins.holder == "a"
    assert ins.state == "HELD"
    assert ins.fencing_token == 1
    assert ins.ttl_remaining_seconds is not None and 0 < ins.ttl_remaining_seconds <= 60


async def test_inspect_include_intent_false_redacts(file_backend):
    await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
        intent=Intent(reason="secret", parent_task="p"),
    ))
    ins = await file_backend.inspect(InspectRequest(
        resource="r/1", include_intent=False,
    ))
    assert ins.status == "found"
    assert ins.intent is None


# ─── list ─────────────────────────────────────────────────────

async def test_list_returns_active_leases(file_backend):
    await file_backend.acquire(AcquireRequest(
        resource="orders/cart-1", holder="a", ttl_seconds=60,
    ))
    await file_backend.acquire(AcquireRequest(
        resource="orders/cart-2", holder="b", ttl_seconds=60,
    ))
    lst = await file_backend.list(ListRequest())
    assert lst.count == 2
    resources = sorted(s.resource for s in lst.leases)
    assert resources == ["orders/cart-1", "orders/cart-2"]


async def test_list_resource_prefix_filters(file_backend):
    await file_backend.acquire(AcquireRequest(
        resource="orders/cart-1", holder="a", ttl_seconds=60,
    ))
    await file_backend.acquire(AcquireRequest(
        resource="inventory/sku-1", holder="b", ttl_seconds=60,
    ))
    lst = await file_backend.list(ListRequest(resource_prefix="orders/"))
    assert lst.count == 1
    assert lst.leases[0].resource == "orders/cart-1"


# ─── steal ────────────────────────────────────────────────────

async def test_steal_denied_when_held(file_backend):
    r = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    steal = await file_backend.steal(StealRequest(
        resource="r/1", new_holder="b", reason="emergency",
        admin_token="sekret",
    ))
    assert steal.status == "denied"
    assert steal.error_code == "RESOURCE_HELD"
    assert steal.old_lease_id == r.lease.lease_id


async def test_steal_succeeds_when_expired(file_backend):
    """After TTL elapses, steal succeeds (v0.3 simplification)."""
    # Use a very short TTL and then sleep
    import asyncio
    r = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=1,
    ))
    await asyncio.sleep(1.1)
    steal = await file_backend.steal(StealRequest(
        resource="r/1", new_holder="b", reason="recovery",
        admin_token="sekret",
    ))
    assert steal.status == "stolen"
    assert steal.new_holder == "b"
    assert steal.new_fencing_token > r.lease.fencing_token


async def test_steal_requires_admin_token(file_backend):
    with pytest.raises(AdminRequiredError):
        await file_backend.steal(StealRequest(
            resource="r/1", new_holder="b", reason="x", admin_token="wrong",
        ))


# ─── history ──────────────────────────────────────────────────

async def test_history_records_acquire_and_release(file_backend):
    r = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    await file_backend.release(ReleaseRequest(
        lease_id=r.lease.lease_id, holder="a", reason="done",
    ))
    hist = await file_backend.history(HistoryRequest(
        resource="r/1",
    ))
    # Should have at least acquired + released
    events = [e.event for e in hist.events]
    assert "acquired" in events
    assert "released" in events


# ─── revoke_all ───────────────────────────────────────────────

async def test_revoke_all_cascades_across_resources(file_backend):
    """Parent-cleans-up-children: 3 leases under one parent_task, all revoked."""
    r1 = await file_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
        intent=Intent(reason="x", parent_task="task-1"),
    ))
    r2 = await file_backend.acquire(AcquireRequest(
        resource="r/2", holder="a", ttl_seconds=60,
        intent=Intent(reason="x", parent_task="task-1"),
    ))
    r3 = await file_backend.acquire(AcquireRequest(
        resource="r/3", holder="a", ttl_seconds=60,
        intent=Intent(reason="x", parent_task="task-1"),
    ))
    rv = await file_backend.revoke_all(RevokeAllRequest(
        parent_task="task-1", reason="parent died",
        admin_token="sekret",
    ))
    assert rv.status == "revoked"
    assert rv.revoked_count == 3
    assert set(rv.revoked_lease_ids) == {
        r1.lease.lease_id, r2.lease.lease_id, r3.lease.lease_id,
    }
    # All three resources should now be free
    for resource in ["r/1", "r/2", "r/3"]:
        ins = await file_backend.inspect(InspectRequest(resource=resource))
        assert ins.status == "none", f"{resource} should be free after revoke_all"


async def test_revoke_all_requires_admin_token(file_backend):
    with pytest.raises(AdminRequiredError):
        await file_backend.revoke_all(RevokeAllRequest(
            parent_task="task-1", reason="x", admin_token="wrong",
        ))


# ─── state persistence ────────────────────────────────────────

async def test_state_persists_across_instances(tmp_path):
    """FileBackend must survive process restart (state.json persisted)."""
    be1 = FileBackend(root=str(tmp_path), admin_token="sekret")
    r = await be1.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    # New instance on same root
    be2 = FileBackend(root=str(tmp_path), admin_token="sekret")
    ins = await be2.inspect(InspectRequest(resource="r/1"))
    assert ins.status == "found"
    assert ins.lease_id == r.lease.lease_id  # type: ignore[union-attr]
