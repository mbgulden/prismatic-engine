"""
test_redis_basic.py — RedisBackend happy-path tests (SWL-1.5).

Uses fakeredis.aioredis for the test environment. Each test gets a fresh
FakeRedis instance to ensure isolation.

Run with:
    pytest tests/test_redis_basic.py
    # Or against a real Redis:
    SWARMLOCK_TEST_REDIS_URL=redis://localhost:6379/0 pytest tests/test_redis_basic.py
"""
from __future__ import annotations

import asyncio

import pytest

# Skip whole module if lupa isn't available (fakeredis Lua support needs it)
try:
    import lupa  # noqa: F401
    HAS_LUPA = True
except ImportError:
    HAS_LUPA = False

from swarmlock.backends.redis_backend import RedisBackend
from swarmlock.errors import AdminRequiredError, ResourceHeldError
from swarmlock.types import (
    AcquireRequest, HistoryRequest, InspectRequest, Intent,
    ListRequest, ReleaseRequest, RenewRequest, RevokeAllRequest,
    StealRequest,
)

pytestmark = pytest.mark.skipif(
    not HAS_LUPA,
    reason="fakeredis Lua support requires 'lupa' module (pip install lupa)",
)


@pytest.fixture
async def redis_backend():
    """A RedisBackend backed by a fresh FakeAsyncRedis."""
    import fakeredis.aioredis as faio
    client = faio.FakeRedis()
    be = RedisBackend(client=client, admin_token="sekret")
    await be.start()
    yield be
    await be.stop()


# ─── acquire ──────────────────────────────────────────────────

async def test_acquire_grants_fresh_lease(redis_backend):
    r = await redis_backend.acquire(AcquireRequest(
        resource="orders/cart-7", holder="agent-1", ttl_seconds=60,
    ))
    assert r.is_acquired
    assert r.lease.fencing_token == 1
    assert r.lease.acquisition_count == 1
    assert r.lease.reentrant is False


async def test_acquire_returns_queued_when_held(redis_backend):
    await redis_backend.acquire(AcquireRequest(
        resource="orders/cart-7", holder="agent-1", ttl_seconds=60,
    ))
    r2 = await redis_backend.acquire(AcquireRequest(
        resource="orders/cart-7", holder="agent-2", ttl_seconds=60, wait="queue",
    ))
    assert r2.status == "queued"
    assert r2.current_holder == "agent-1"
    assert r2.queue_position == 1


async def test_acquire_raises_when_held_with_fail(redis_backend):
    await redis_backend.acquire(AcquireRequest(
        resource="orders/cart-7", holder="agent-1", ttl_seconds=60,
    ))
    with pytest.raises(ResourceHeldError) as exc:
        await redis_backend.acquire(AcquireRequest(
            resource="orders/cart-7", holder="agent-2", ttl_seconds=60, wait="fail",
        ))
    assert exc.value.code == "RESOURCE_HELD"


async def test_acquire_reentrant_increments_count(redis_backend):
    r1 = await redis_backend.acquire(AcquireRequest(
        resource="orders/cart-7", holder="agent-1", ttl_seconds=60, trace_id="abc",
    ))
    r2 = await redis_backend.acquire(AcquireRequest(
        resource="orders/cart-7", holder="agent-1", ttl_seconds=60, trace_id="abc",
    ))
    assert r2.is_acquired
    assert r2.lease.reentrant is True
    assert r2.lease.acquisition_count == 2
    assert r2.lease.fencing_token == r1.lease.fencing_token


async def test_acquire_fencing_token_is_monotonic(redis_backend):
    r1 = await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    await redis_backend.release(ReleaseRequest(
        lease_id=r1.lease.lease_id, holder="a", reason="done",
    ))
    r2 = await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="b", ttl_seconds=60,
    ))
    assert r2.lease.fencing_token > r1.lease.fencing_token


async def test_acquire_intent_is_persisted(redis_backend):
    r = await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
        intent=Intent(reason="checkout", parent_task="flow-1", trace_id="t1"),
    ))
    assert r.lease.intent is not None
    assert r.lease.intent.reason == "checkout"
    assert r.lease.parent_task == "flow-1"


# ─── renew ────────────────────────────────────────────────────

async def test_renew_extends_ttl(redis_backend):
    r = await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    renewed = await redis_backend.renew(RenewRequest(
        lease_id=r.lease.lease_id, holder="a", extend_by_seconds=120,
    ))
    assert renewed.status == "renewed"
    assert renewed.expires_at > r.lease.expires_at


async def test_renew_returns_lost_for_missing_lease(redis_backend):
    renewed = await redis_backend.renew(RenewRequest(
        lease_id="lease_nonexistent", holder="a", extend_by_seconds=120,
    ))
    assert renewed.status == "lost"


# ─── release ──────────────────────────────────────────────────

async def test_release_frees_resource(redis_backend):
    r = await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    rel = await redis_backend.release(ReleaseRequest(
        lease_id=r.lease.lease_id, holder="a", reason="done",
    ))
    assert rel.status == "released"
    ins = await redis_backend.inspect(InspectRequest(resource="r/1"))
    assert ins.status == "none"


async def test_release_reentrant_decrements(redis_backend):
    await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
    ))
    r2 = await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
    ))
    rel = await redis_backend.release(ReleaseRequest(
        lease_id=r2.lease.lease_id, holder="a", reason="done",
    ))
    assert rel.status == "noop"
    assert rel.remaining_acquisitions == 1


# ─── inspect ──────────────────────────────────────────────────

async def test_inspect_returns_lease_when_held(redis_backend):
    r = await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    ins = await redis_backend.inspect(InspectRequest(resource="r/1"))
    assert ins.status == "found"
    assert ins.lease_id == r.lease.lease_id
    assert ins.fencing_token == 1


async def test_inspect_include_intent_false_redacts(redis_backend):
    await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
        intent=Intent(reason="secret", parent_task="p"),
    ))
    ins = await redis_backend.inspect(InspectRequest(
        resource="r/1", include_intent=False,
    ))
    assert ins.status == "found"
    assert ins.intent is None


# ─── list ─────────────────────────────────────────────────────

async def test_list_returns_active_leases(redis_backend):
    await redis_backend.acquire(AcquireRequest(
        resource="orders/cart-1", holder="a", ttl_seconds=60,
    ))
    await redis_backend.acquire(AcquireRequest(
        resource="orders/cart-2", holder="b", ttl_seconds=60,
    ))
    lst = await redis_backend.list(ListRequest())
    assert lst.count == 2


async def test_list_resource_prefix_filters(redis_backend):
    await redis_backend.acquire(AcquireRequest(
        resource="orders/cart-1", holder="a", ttl_seconds=60,
    ))
    await redis_backend.acquire(AcquireRequest(
        resource="inventory/sku-1", holder="b", ttl_seconds=60,
    ))
    lst = await redis_backend.list(ListRequest(resource_prefix="orders/"))
    assert lst.count == 1


# ─── steal ────────────────────────────────────────────────────

async def test_steal_denied_when_held(redis_backend):
    await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    steal = await redis_backend.steal(StealRequest(
        resource="r/1", new_holder="b", reason="emergency",
        admin_token="sekret",
    ))
    assert steal.status == "denied"
    assert steal.error_code == "RESOURCE_HELD"


async def test_steal_succeeds_when_expired(redis_backend):
    r = await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=1,
    ))
    await asyncio.sleep(1.1)
    steal = await redis_backend.steal(StealRequest(
        resource="r/1", new_holder="b", reason="recovery",
        admin_token="sekret",
    ))
    assert steal.status == "stolen"
    assert steal.new_fencing_token > r.lease.fencing_token


async def test_steal_requires_admin_token(redis_backend):
    with pytest.raises(AdminRequiredError):
        await redis_backend.steal(StealRequest(
            resource="r/1", new_holder="b", reason="x", admin_token="wrong",
        ))


# ─── history ──────────────────────────────────────────────────

async def test_history_records_acquire_and_release(redis_backend):
    r = await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
    ))
    await redis_backend.release(ReleaseRequest(
        lease_id=r.lease.lease_id, holder="a", reason="done",
    ))
    hist = await redis_backend.history(HistoryRequest(resource="r/1"))
    events = [e.event for e in hist.events]
    assert "acquired" in events
    assert "released" in events


# ─── revoke_all ───────────────────────────────────────────────

async def test_revoke_all_cascades_across_resources(redis_backend):
    r1 = await redis_backend.acquire(AcquireRequest(
        resource="r/1", holder="a", ttl_seconds=60,
        intent=Intent(reason="x", parent_task="task-1"),
    ))
    r2 = await redis_backend.acquire(AcquireRequest(
        resource="r/2", holder="a", ttl_seconds=60,
        intent=Intent(reason="x", parent_task="task-1"),
    ))
    r3 = await redis_backend.acquire(AcquireRequest(
        resource="r/3", holder="a", ttl_seconds=60,
        intent=Intent(reason="x", parent_task="task-1"),
    ))
    rv = await redis_backend.revoke_all(RevokeAllRequest(
        parent_task="task-1", reason="parent died",
        admin_token="sekret",
    ))
    assert rv.status == "revoked"
    assert rv.revoked_count == 3
    assert set(rv.revoked_lease_ids) == {
        r1.lease.lease_id, r2.lease.lease_id, r3.lease.lease_id,
    }
    for resource in ["r/1", "r/2", "r/3"]:
        ins = await redis_backend.inspect(InspectRequest(resource=resource))
        assert ins.status == "none"


async def test_revoke_all_requires_admin_token(redis_backend):
    with pytest.raises(AdminRequiredError):
        await redis_backend.revoke_all(RevokeAllRequest(
            parent_task="task-1", reason="x", admin_token="wrong",
        ))
