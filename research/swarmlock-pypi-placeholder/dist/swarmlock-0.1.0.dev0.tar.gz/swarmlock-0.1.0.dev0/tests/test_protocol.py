"""Tests for swarmlock.protocol (SWL-1.3).

Verifies the Backend Protocol is structurally satisfied by a minimal stub,
and that verify_backend() correctly reports missing methods.
"""
from __future__ import annotations

import pytest

from swarmlock.protocol import verify_backend
from swarmlock.types import (
    AcquireRequest, AcquireResult, RenewRequest, RenewResult,
    ReleaseRequest, ReleaseResult, InspectRequest, InspectResult,
    ListRequest, ListResult, StealRequest, StealResult,
    HistoryRequest, HistoryResult, RevokeAllRequest, RevokeAllResult,
)


class MinimalBackend:
    """Minimal async backend satisfying the protocol."""

    async def acquire(self, request: AcquireRequest) -> AcquireResult:
        return AcquireResult(status="denied")

    async def renew(self, request: RenewRequest) -> RenewResult:
        return RenewResult(status="lost")

    async def release(self, request: ReleaseRequest) -> ReleaseResult:
        return ReleaseResult(status="released", lease_id=request.lease_id)

    async def inspect(self, request: InspectRequest) -> InspectResult:
        return InspectResult(status="none", resource=request.resource)

    async def list(self, request: ListRequest) -> ListResult:
        return ListResult(count=0, leases=[])

    async def steal(self, request: StealRequest) -> StealResult:
        return StealResult(status="denied")

    async def history(self, request: HistoryRequest) -> HistoryResult:
        return HistoryResult(events=[])

    async def revoke_all(self, request: RevokeAllRequest) -> RevokeAllResult:
        return RevokeAllResult(
            status="ok", parent_task=request.parent_task,
            revoked_count=0, revoked_lease_ids=[],
        )


class IncompleteBackend:
    """Missing several verbs — must fail verify_backend()."""
    async def acquire(self, request): pass
    async def release(self, request): pass


class TestProtocolSatisfaction:
    def test_minimal_satisfies_verify(self):
        """verify_backend() is the authoritative runtime check.
        isinstance() against @runtime_checkable Protocol is unreliable in
        Python 3.12+ when method signatures don't match exactly.
        """
        b = MinimalBackend()
        verify_backend(b)  # should not raise

    def test_minimal_has_all_verbs(self):
        b = MinimalBackend()
        for verb in ["acquire", "renew", "release", "inspect",
                     "list", "steal", "history", "revoke_all"]:
            assert hasattr(b, verb), f"missing {verb}"
            assert callable(getattr(b, verb)), f"{verb} not callable"


class TestVerifyBackend:
    def test_complete_passes(self):
        b = MinimalBackend()
        verify_backend(b)  # should not raise

    def test_incomplete_raises(self):
        b = IncompleteBackend()
        with pytest.raises(TypeError) as excinfo:
            verify_backend(b)
        # Should mention some of the missing verbs
        msg = str(excinfo.value)
        assert "renew" in msg or "inspect" in msg or "list" in msg
