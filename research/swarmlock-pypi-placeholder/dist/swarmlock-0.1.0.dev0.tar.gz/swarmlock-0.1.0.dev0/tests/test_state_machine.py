"""Tests for swarmlock.state_machine (SWL-1.8).

Verifies the §4 transition table and helper predicates.
Pure unit tests — no time, no I/O.
"""
from __future__ import annotations

import pytest

from swarmlock.state_machine import (
    is_allowed, next_state, is_terminal,
    can_acquire_freshly, can_reenter, can_steal,
    InvalidTransition,
)


class TestTransitions:
    """Spec §4.2 — each (state, trigger) pair."""

    def test_none_acquire_to_held(self):
        assert next_state("NONE", "acquire") == "HELD"

    def test_held_renew_stays_held(self):
        assert next_state("HELD", "renew") == "HELD"

    def test_held_reentrant_acquire_stays_held(self):
        assert next_state("HELD", "acquire") == "HELD"

    def test_held_release_to_released(self):
        assert next_state("HELD", "release") == "RELEASED"

    def test_held_revoke_all_to_revoked(self):
        assert next_state("HELD", "revoke_all") == "REVOKED"

    def test_held_expire_to_expired(self):
        assert next_state("HELD", "expire") == "EXPIRED"

    def test_expired_acquire_to_held(self):
        assert next_state("EXPIRED", "acquire") == "HELD"

    def test_expired_steal_to_stolen(self):
        assert next_state("EXPIRED", "steal") == "STOLEN"

    def test_stolen_acquire_to_held(self):
        assert next_state("STOLEN", "acquire") == "HELD"

    def test_invalid_none_release(self):
        with pytest.raises(InvalidTransition):
            next_state("NONE", "release")

    def test_invalid_none_steal(self):
        with pytest.raises(InvalidTransition):
            next_state("NONE", "steal")

    def test_invalid_released_acquire(self):
        # RELEASED is terminal — no outgoing transitions
        with pytest.raises(InvalidTransition):
            next_state("RELEASED", "acquire")

    def test_invalid_revoked_acquire(self):
        with pytest.raises(InvalidTransition):
            next_state("REVOKED", "acquire")

    def test_invalid_held_steal(self):
        # Spec §5.6 v0.3 — steal on HELD must fail
        with pytest.raises(InvalidTransition):
            next_state("HELD", "steal")


class TestIsAllowed:
    def test_allowed_returns_true(self):
        assert is_allowed("NONE", "acquire") is True

    def test_disallowed_returns_false(self):
        assert is_allowed("NONE", "release") is False
        assert is_allowed("HELD", "steal") is False
        assert is_allowed("RELEASED", "acquire") is False


class TestTerminal:
    def test_released_is_terminal(self):
        assert is_terminal("RELEASED") is True

    def test_revoked_is_terminal(self):
        assert is_terminal("REVOKED") is True

    def test_held_not_terminal(self):
        assert is_terminal("HELD") is False

    def test_expired_not_terminal(self):
        assert is_terminal("EXPIRED") is False

    def test_none_not_terminal(self):
        assert is_terminal("NONE") is False

    def test_stolen_not_terminal(self):
        assert is_terminal("STOLEN") is False


class TestCanAcquireFreshly:
    def test_none_can(self):
        assert can_acquire_freshly("NONE") is True

    def test_expired_can(self):
        assert can_acquire_freshly("EXPIRED") is True

    def test_stolen_can(self):
        assert can_acquire_freshly("STOLEN") is True

    def test_held_cannot(self):
        assert can_acquire_freshly("HELD") is False

    def test_released_cannot(self):
        assert can_acquire_freshly("RELEASED") is False


class TestCanReenter:
    def test_held_can_reenter(self):
        assert can_reenter("HELD") is True

    def test_others_cannot(self):
        for state in ("NONE", "EXPIRED", "STOLEN", "RELEASED", "REVOKED"):
            assert can_reenter(state) is False, f"can_reenter({state!r}) should be False"


class TestCanSteal:
    """Spec §5.6 v0.3 — steal succeeds only on EXPIRED or RELEASED."""

    def test_expired_can_steal(self):
        assert can_steal("EXPIRED") is True

    def test_released_can_steal(self):
        assert can_steal("RELEASED") is True

    def test_held_cannot_steal(self):
        assert can_steal("HELD") is False

    def test_none_cannot_steal(self):
        assert can_steal("NONE") is False

    def test_revoked_cannot_steal(self):
        assert can_steal("REVOKED") is False


class TestInvalidTransitionAttrs:
    def test_attributes_preserved(self):
        try:
            next_state("NONE", "release")
        except InvalidTransition as e:
            assert e.state == "NONE"
            assert e.trigger == "release"
        else:
            pytest.fail("expected InvalidTransition")
