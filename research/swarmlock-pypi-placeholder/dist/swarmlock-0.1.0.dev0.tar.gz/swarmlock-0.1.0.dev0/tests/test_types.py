"""Tests for swarmlock.types (SWL-1.2)."""
from __future__ import annotations

from swarmlock._compat import datetime, UTC, timedelta

import pytest

from swarmlock.types import (
    Intent, Lease, AcquireRequest, AcquireResult,
    RenewRequest, RenewResult,
    ReleaseRequest, ReleaseResult,
    InspectRequest, InspectResult,
    ListRequest, ListResult, LeaseSummary,
    StealRequest, StealResult,
    HistoryRequest, HistoryEvent,
    RevokeAllRequest, RevokeAllResult,
    LeaseEvent, WatchRequest,
)


NOW = datetime.now(UTC)
FUTURE = NOW + timedelta(seconds=300)
PAST = NOW - timedelta(seconds=10)


# ─── Intent ─────────────────────────────────────────────────────────

class TestIntent:
    def test_required_reason(self):
        i = Intent(reason="test")
        assert i.reason == "test"
        assert i.parent_task is None
        assert i.trace_id is None
        assert i.metadata == {}

    def test_frozen(self):
        i = Intent(reason="test")
        with pytest.raises(Exception):  # FrozenInstanceError
            i.reason = "changed"  # type: ignore[misc]

    def test_metadata_factory(self):
        a = Intent(reason="a", metadata={"k": 1})
        b = Intent(reason="b", metadata={"k": 2})
        # Each instance gets its own dict (default_factory)
        assert a.metadata is not b.metadata


# ─── Lease ──────────────────────────────────────────────────────────

class TestLease:
    def make_lease(self, **overrides):
        defaults = dict(
            lease_id="lease_1",
            resource="orders/cart-7",
            holder="agent-42",
            acquired_at=NOW,
            expires_at=FUTURE,
            ttl_seconds=300,
            fencing_token=42,
            acquisition_count=1,
            reentrant=False,
            intent=Intent(reason="test"),
        )
        defaults.update(overrides)
        return Lease(**defaults)

    def test_state_when_held(self):
        l = self.make_lease()
        assert l.state == "HELD"

    def test_state_when_expired(self):
        l = self.make_lease(expires_at=PAST)
        assert l.state == "EXPIRED"

    def test_ttl_remaining_positive(self):
        # Compute expected delta from "now" rather than relying on a module-level NOW
        # (the test may run 10+ seconds after NOW was captured if other tests run first).
        from datetime import datetime, UTC, timedelta
        l = self.make_lease(expires_at=datetime.now(UTC) + timedelta(seconds=10))
        # Should be within a small window of 10s (allowing for test execution latency)
        assert 8.0 < l.ttl_remaining_seconds <= 10.0

    def test_ttl_remaining_negative_when_expired(self):
        l = self.make_lease(expires_at=PAST)
        assert l.ttl_remaining_seconds < 0

    def test_frozen(self):
        l = self.make_lease()
        with pytest.raises(Exception):
            l.lease_id = "changed"  # type: ignore[misc]


# ─── Request / Result types — shape only ────────────────────────────

class TestRequestShapes:
    def test_acquire_request(self):
        r = AcquireRequest(
            resource="r", holder="h", ttl_seconds=300,
            wait="queue", trace_id="t", intent=Intent(reason="x"),
        )
        assert r.resource == "r"
        assert r.wait == "queue"

    def test_renew_request(self):
        r = RenewRequest(lease_id="l", holder="h", extend_by_seconds=60)
        assert r.extend_by_seconds == 60

    def test_release_request(self):
        r = ReleaseRequest(lease_id="l", holder="h", reason="done")
        assert r.reason == "done"

    def test_inspect_request_default(self):
        r = InspectRequest(resource="r")
        assert r.include_intent is True

    def test_list_request_limit_default(self):
        r = ListRequest()
        assert r.limit == 100

    def test_steal_request(self):
        r = StealRequest(resource="r", new_holder="nh", reason="deadlock", admin_token="tok")
        assert r.admin_token == "tok"

    def test_revoke_all_request(self):
        r = RevokeAllRequest(parent_task="parent-1", reason="parent died", admin_token="tok")
        assert r.parent_task == "parent-1"

    def test_history_request(self):
        r = HistoryRequest(resource="r", limit=50)
        assert r.limit == 50

    def test_watch_request_default(self):
        r = WatchRequest()
        assert r.resource_patterns == []
        assert r.parent_tasks == []
        assert r.include_intent is False


class TestResultShapes:
    def test_acquire_result_is_acquired(self):
        l = Lease(
            lease_id="l", resource="r", holder="h",
            acquired_at=NOW, expires_at=FUTURE,
            ttl_seconds=300, fencing_token=1,
        )
        r = AcquireResult(status="acquired", lease=l)
        assert r.is_acquired is True

    def test_acquire_result_contended(self):
        r = AcquireResult(
            status="contended",
            current_holder="agent-17",
            current_fencing_token=33,
            retry_after_ms=250,
        )
        assert r.is_acquired is False

    def test_renew_result_renewed(self):
        r = RenewResult(status="renewed", lease_id="l", expires_at=FUTURE)
        assert r.status == "renewed"

    def test_renew_result_lost(self):
        r = RenewResult(status="lost", error="lease expired")
        assert r.error == "lease expired"

    def test_release_result_remaining(self):
        r = ReleaseResult(status="noop", lease_id="l", remaining_acquisitions=2)
        assert r.remaining_acquisitions == 2

    def test_inspect_result_none(self):
        r = InspectResult(status="none", resource="r")
        assert r.state is None

    def test_list_result(self):
        r = ListResult(count=2, leases=[
            LeaseSummary(lease_id="l1", resource="r", holder="h", state="HELD"),
            LeaseSummary(lease_id="l2", resource="r2", holder="h2", state="HELD"),
        ])
        assert r.count == 2

    def test_steal_result_denied(self):
        r = StealResult(status="denied", error_code="RESOURCE_HELD")
        assert r.error_code == "RESOURCE_HELD"

    def test_history_event_ordering(self):
        e = HistoryEvent(event="renewed", at=NOW, lease_id="l", extend_by_seconds=60)
        assert e.at == NOW
        assert e.extend_by_seconds == 60

    def test_revoke_all_result(self):
        r = RevokeAllResult(
            status="revoked", parent_task="p",
            revoked_count=3, revoked_lease_ids=["l1", "l2", "l3"],
            revoked_at=NOW,
        )
        assert r.revoked_count == 3


class TestLeaseEvent:
    def test_minimum_shape(self):
        e = LeaseEvent(
            resource="r", lease_id="l", holder="h",
            event_type="released", fencing_token=42, at=NOW,
        )
        assert e.intent is None

    def test_with_intent(self):
        e = LeaseEvent(
            resource="r", lease_id=None, holder=None,
            event_type="expired", fencing_token=0, at=NOW,
            intent=Intent(reason="test"),
        )
        assert e.intent is not None
