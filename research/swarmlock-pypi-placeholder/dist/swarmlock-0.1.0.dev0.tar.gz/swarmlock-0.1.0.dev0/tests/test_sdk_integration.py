"""
test_sdk_integration.py — SDK integration tests (GRO-4744).

Covers:
- Async context manager semantics (acquire on enter, release on exit)
- Sync context manager semantics (acquire on enter, release on exit)
- Background heartbeat keeps lease alive past TTL
- Heartbeat detects lease loss → raises LeaseLostError
- Reentrant acquire (same trace_id) increments acquisition_count
- Fencing token exposed on handle
- ResourceHeldError raised on contention (wait="fail")
- on_released callback fires
- Lifecycle: start()/stop() and async context manager on Swarmlock
- Low-level verb passthroughs (acquire, renew, release, inspect)
- Cross-backend: SDK works identically on InProcess / File / Redis
"""
from __future__ import annotations

import asyncio
import tempfile
import time

import pytest

from swarmlock import (
    AsyncLeaseHandle,
    Intent,
    LeaseHandle,
    LeaseLostError,
    ResourceHeldError,
    Swarmlock,
)
from swarmlock.types import (
    AcquireRequest,
    HistoryRequest,
    InspectRequest,
    ListRequest,
    ReleaseRequest,
    RenewRequest,
    RevokeAllRequest,
    StealRequest,
)


# ─────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────

@pytest.fixture
def in_process_client():
    """A fresh Swarmlock with the in-process backend."""
    return Swarmlock(backend="in_process", admin_token="sekret")


@pytest.fixture
def file_client():
    """A fresh Swarmlock with the file backend in a temp dir."""
    tmp = tempfile.mkdtemp(prefix="swarmlock-sdk-")
    return Swarmlock(backend="file", root=tmp, admin_token="sekret")


@pytest.fixture
def redis_client():
    """A fresh Swarmlock with the redis backend (fakeredis)."""
    import fakeredis.aioredis as faio
    client = faio.FakeRedis()
    return Swarmlock(backend="redis", client=client, admin_token="sekret")


@pytest.fixture(params=["in_process", "file", "redis"])
def any_backend_client(request):
    """Parametrized fixture: tests run against all 3 backends."""
    if request.param == "in_process":
        return Swarmlock(backend="in_process", admin_token="sekret")
    if request.param == "file":
        tmp = tempfile.mkdtemp(prefix="swarmlock-sdk-")
        return Swarmlock(backend="file", root=tmp, admin_token="sekret")
    if request.param == "redis":
        import fakeredis.aioredis as faio
        client = faio.FakeRedis()
        return Swarmlock(backend="redis", client=client, admin_token="sekret")
    raise ValueError(request.param)


# ─────────────────────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────────────────────

async def test_swarmlock_async_context_manager_starts_stops(in_process_client):
    assert in_process_client._started is False
    async with in_process_client:
        assert in_process_client._started is True
    assert in_process_client._started is False


def test_swarmlock_sync_context_manager_starts_stops(in_process_client):
    assert in_process_client._started is False
    with in_process_client:
        assert in_process_client._started is True
    assert in_process_client._started is False


async def test_swarmlock_explicit_start_stop(in_process_client):
    await in_process_client.start()
    assert in_process_client._started is True
    await in_process_client.stop()
    assert in_process_client._started is False


# ─────────────────────────────────────────────────────────────
# Async context manager
# ─────────────────────────────────────────────────────────────

async def test_async_context_manager_acquires_and_releases(in_process_client):
    async with in_process_client:
        async with await in_process_client.lease(
            resource="r/1", holder="a", ttl_seconds=60,
        ) as lease:
            assert lease.lease_id
            assert lease.fencing_token == 1
            assert lease.acquisition_count == 1
        # After exit, lease should be released
        ins = await in_process_client.inspect(InspectRequest(resource="r/1"))
        assert ins.status == "none"


async def test_async_lease_exposes_lease_handle(in_process_client):
    async with in_process_client:
        async with await in_process_client.lease(
            resource="r/1", holder="a", ttl_seconds=60,
            trace_id="t1", intent=Intent(reason="checkout", parent_task="p1"),
        ) as lease:
            assert isinstance(lease, AsyncLeaseHandle)
            assert lease.resource == "r/1"
            assert lease.holder == "a"
            assert lease.intent is not None
            assert lease.intent.reason == "checkout"
            assert lease.parent_task == "p1"
            # Lease dataclass accessible via .lease
            assert lease.lease.lease_id == lease.lease_id


async def test_async_reentrant_acquire_increments_count(in_process_client):
    async with in_process_client:
        async with await in_process_client.lease(
            resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
        ) as outer:
            assert outer.acquisition_count == 1
            # Re-enter with same trace_id — should be reentrant
            async with await in_process_client.lease(
                resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
            ) as inner:
                assert inner.reentrant is True
                assert inner.acquisition_count == 2
                assert inner.fencing_token == outer.fencing_token


async def test_async_lease_raises_resource_held_on_contention(in_process_client):
    async with in_process_client:
        async with await in_process_client.lease(
            resource="r/1", holder="a", ttl_seconds=60,
        ):
            with pytest.raises(ResourceHeldError) as exc_info:
                async with await in_process_client.lease(
                    resource="r/1", holder="b", ttl_seconds=60, wait="fail",
                ):
                    pass
            assert exc_info.value.code == "RESOURCE_HELD"
            assert exc_info.value.current_holder == "a"


async def test_async_on_released_callback_fires(in_process_client):
    callback_results: list = []

    def on_released(lease):
        callback_results.append(("sync", lease.lease_id))

    async with in_process_client:
        async with await in_process_client.lease(
            resource="r/1", holder="a", ttl_seconds=60, on_released=on_released,
        ) as lease:
            lease_id = lease.lease_id
        # After context exit
        assert callback_results == [("sync", lease_id)]


async def test_async_on_released_callback_async(in_process_client):
    callback_results: list = []

    async def on_released(lease):
        callback_results.append(lease.lease_id)

    async with in_process_client:
        async with await in_process_client.lease(
            resource="r/1", holder="a", ttl_seconds=60, on_released=on_released,
        ):
            pass
    assert len(callback_results) == 1


# ─────────────────────────────────────────────────────────────
# Sync context manager
# ─────────────────────────────────────────────────────────────

def test_sync_context_manager_acquires_and_releases(in_process_client):
    with in_process_client:
        with in_process_client.lease_sync(
            resource="r/1", holder="a", ttl_seconds=60,
        ) as lease:
            assert lease.lease_id
            assert lease.fencing_token == 1
            assert lease.acquisition_count == 1
            assert isinstance(lease, LeaseHandle)
        # After exit, lease should be released
        import asyncio
        result = asyncio.run(in_process_client.inspect(InspectRequest(resource="r/1")))
        assert result.status == "none"


def test_sync_reentrant_acquire_increments_count(in_process_client):
    with in_process_client:
        with in_process_client.lease_sync(
            resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
        ) as outer:
            assert outer.acquisition_count == 1
            with in_process_client.lease_sync(
                resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
            ) as inner:
                assert inner.reentrant is True
                assert inner.acquisition_count == 2


def test_sync_lease_raises_resource_held_on_contention(in_process_client):
    with in_process_client:
        with in_process_client.lease_sync(
            resource="r/1", holder="a", ttl_seconds=60,
        ):
            with pytest.raises(ResourceHeldError):
                with in_process_client.lease_sync(
                    resource="r/1", holder="b", ttl_seconds=60, wait="fail",
                ):
                    pass


def test_sync_on_released_callback_fires(in_process_client):
    callback_results: list = []
    def on_released(lease):
        callback_results.append(lease.lease_id)

    with in_process_client:
        with in_process_client.lease_sync(
            resource="r/1", holder="a", ttl_seconds=60, on_released=on_released,
        ) as lease:
            lease_id = lease.lease_id
        assert callback_results == [lease_id]


# ─────────────────────────────────────────────────────────────
# Background heartbeat
# ─────────────────────────────────────────────────────────────

async def test_async_background_heartbeat_keeps_lease_alive(in_process_client):
    """Long-running task: heartbeat keeps the lease beyond its original TTL."""
    async with in_process_client:
        async with await in_process_client.lease(
            resource="r/1", holder="a", ttl_seconds=2,
            heartbeat_interval=0.5,
        ) as lease:
            # Sleep past original TTL — heartbeat should renew it
            await asyncio.sleep(2.5)
            # Inspect: lease should still be held
            ins = await in_process_client.inspect(InspectRequest(resource="r/1"))
            assert ins.status == "found"
            assert ins.lease_id == lease.lease_id
            # Fencing token unchanged (heartbeats don't bump it)
            assert ins.fencing_token == lease.fencing_token


def test_sync_background_heartbeat_keeps_lease_alive(in_process_client):
    with in_process_client:
        with in_process_client.lease_sync(
            resource="r/1", holder="a", ttl_seconds=2,
            heartbeat_interval=0.5,
        ):
            time.sleep(2.5)
            ins = asyncio.run(in_process_client.inspect(InspectRequest(resource="r/1")))
            assert ins.status == "found"


async def test_async_heartbeat_detects_lease_loss(in_process_client):
    """If the lease is revoked externally, heartbeat raises LeaseLostError at exit."""
    raised: list[Exception] = []
    async with in_process_client:
        try:
            async with await in_process_client.lease(
                resource="r/1", holder="a", ttl_seconds=2,
                heartbeat_interval=0.3, trace_id="t1",
                intent=Intent(reason="x", parent_task="p1"),
            ):
                # Sleep enough for one heartbeat
                await asyncio.sleep(0.5)
                # Externally revoke all leases for parent_task
                rv = await in_process_client.revoke_all(RevokeAllRequest(
                    parent_task="p1", reason="parent died", admin_token="sekret",
                ))
                assert rv.revoked_count >= 1
                # Wait for heartbeat to detect loss (next renew will fail)
                await asyncio.sleep(1.0)
        except LeaseLostError as e:
            raised.append(e)
    assert len(raised) == 1
    assert isinstance(raised[0], LeaseLostError)


# ─────────────────────────────────────────────────────────────
# Low-level verb passthroughs
# ─────────────────────────────────────────────────────────────

async def test_low_level_acquire(in_process_client):
    async with in_process_client:
        result = await in_process_client.acquire(AcquireRequest(
            resource="r/1", holder="a", ttl_seconds=60,
        ))
        assert result.is_acquired
        assert result.lease.fencing_token == 1


async def test_low_level_renew(in_process_client):
    async with in_process_client:
        result = await in_process_client.acquire(AcquireRequest(
            resource="r/1", holder="a", ttl_seconds=60,
        ))
        renewed = await in_process_client.renew(RenewRequest(
            lease_id=result.lease.lease_id, holder="a", extend_by_seconds=120,
        ))
        assert renewed.status == "renewed"


async def test_low_level_release(in_process_client):
    async with in_process_client:
        result = await in_process_client.acquire(AcquireRequest(
            resource="r/1", holder="a", ttl_seconds=60,
        ))
        rel = await in_process_client.release(ReleaseRequest(
            lease_id=result.lease.lease_id, holder="a", reason="done",
        ))
        assert rel.status == "released"


async def test_low_level_inspect(in_process_client):
    async with in_process_client:
        await in_process_client.acquire(AcquireRequest(
            resource="r/1", holder="a", ttl_seconds=60,
        ))
        ins = await in_process_client.inspect(InspectRequest(resource="r/1"))
        assert ins.status == "found"


async def test_low_level_list(in_process_client):
    async with in_process_client:
        await in_process_client.acquire(AcquireRequest(
            resource="orders/cart-1", holder="a", ttl_seconds=60,
        ))
        await in_process_client.acquire(AcquireRequest(
            resource="orders/cart-2", holder="b", ttl_seconds=60,
        ))
        lst = await in_process_client.list(ListRequest())
        assert lst.count == 2


async def test_low_level_history(in_process_client):
    async with in_process_client:
        result = await in_process_client.acquire(AcquireRequest(
            resource="r/1", holder="a", ttl_seconds=60,
        ))
        await in_process_client.release(ReleaseRequest(
            lease_id=result.lease.lease_id, holder="a", reason="done",
        ))
        hist = await in_process_client.history(HistoryRequest(resource="r/1"))
        events = [e.event for e in hist.events]
        assert "acquired" in events
        assert "released" in events


async def test_low_level_steal(in_process_client):
    async with in_process_client:
        await in_process_client.acquire(AcquireRequest(
            resource="r/1", holder="a", ttl_seconds=1,
        ))
        await asyncio.sleep(1.1)
        result = await in_process_client.steal(StealRequest(
            resource="r/1", new_holder="b", reason="recovery",
            admin_token="sekret",
        ))
        assert result.status == "stolen"


async def test_low_level_revoke_all(in_process_client):
    async with in_process_client:
        await in_process_client.acquire(AcquireRequest(
            resource="r/1", holder="a", ttl_seconds=60,
            intent=Intent(reason="x", parent_task="p1"),
        ))
        await in_process_client.acquire(AcquireRequest(
            resource="r/2", holder="a", ttl_seconds=60,
            intent=Intent(reason="x", parent_task="p1"),
        ))
        rv = await in_process_client.revoke_all(RevokeAllRequest(
            parent_task="p1", reason="cleanup", admin_token="sekret",
        ))
        assert rv.revoked_count == 2


# ─────────────────────────────────────────────────────────────
# Refresh
# ─────────────────────────────────────────────────────────────

async def test_async_refresh_updates_lease(in_process_client):
    async with in_process_client:
        async with await in_process_client.lease(
            resource="r/1", holder="a", ttl_seconds=60,
        ) as lease:
            original_expires = lease.expires_at
            # Manually renew via backend to bump expires_at
            await in_process_client.renew(RenewRequest(
                lease_id=lease.lease_id, holder="a", extend_by_seconds=300,
            ))
            refreshed = await lease.refresh()
            assert refreshed.expires_at > original_expires


def test_sync_refresh_updates_lease(in_process_client):
    with in_process_client:
        with in_process_client.lease_sync(
            resource="r/1", holder="a", ttl_seconds=60,
        ) as lease:
            original_expires = lease.expires_at
            asyncio.run(in_process_client.renew(RenewRequest(
                lease_id=lease.lease_id, holder="a", extend_by_seconds=300,
            )))
            refreshed = lease.refresh()
            assert refreshed.expires_at > original_expires


# ─────────────────────────────────────────────────────────────
# Cross-backend SDK equivalence
# ─────────────────────────────────────────────────────────────

async def test_sdk_works_on_all_backends(any_backend_client):
    """Acquire/release cycle works the same on InProcess/File/Redis."""
    sl = any_backend_client
    async with sl:
        async with await sl.lease(
            resource="r/1", holder="a", ttl_seconds=60,
        ) as lease:
            assert lease.fencing_token == 1
            assert lease.acquisition_count == 1
            assert lease.reentrant is False


async def test_sdk_reentrant_works_on_all_backends(any_backend_client):
    sl = any_backend_client
    async with sl:
        async with await sl.lease(
            resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
        ) as outer:
            async with await sl.lease(
                resource="r/1", holder="a", ttl_seconds=60, trace_id="t1",
            ) as inner:
                assert inner.reentrant is True
                assert inner.acquisition_count == 2
                assert inner.fencing_token == outer.fencing_token


# ─────────────────────────────────────────────────────────────
# Error handling
# ─────────────────────────────────────────────────────────────

async def test_unknown_backend_string_raises_value_error():
    with pytest.raises(ValueError, match="Unknown backend"):
        Swarmlock(backend="bogus")


async def test_async_lease_provides_intent_metadata(in_process_client):
    async with in_process_client:
        async with await in_process_client.lease(
            resource="r/1", holder="a", ttl_seconds=60,
            intent=Intent(reason="checkout", parent_task="flow-7", trace_id="t7"),
        ) as lease:
            assert lease.intent.reason == "checkout"
            assert lease.intent.parent_task == "flow-7"
            assert lease.intent.trace_id == "t7"


async def test_async_custom_heartbeat_interval(in_process_client):
    async with in_process_client:
        async with await in_process_client.lease(
            resource="r/1", holder="a", ttl_seconds=60,
            heartbeat_interval=0.2,
        ) as lease:
            assert lease.lease_id
            # Wait long enough for several heartbeats
            await asyncio.sleep(0.7)
            ins = await in_process_client.inspect(InspectRequest(resource="r/1"))
            assert ins.status == "found"


def test_sync_lease_in_background_thread_cleanup(in_process_client):
    """Verify the heartbeat thread is daemon and cleans up on context exit."""
    with in_process_client:
        with in_process_client.lease_sync(
            resource="r/1", holder="a", ttl_seconds=60, heartbeat_interval=0.1,
        ) as lease:
            assert lease.lease_id
            # Heartbeat thread should be running
            assert lease._heartbeat_thread is not None
            assert lease._heartbeat_thread.is_alive()
        # After exit, thread should be stopped (daemon=True so it dies with process)
        # We give it a moment to react to stop_event
        time.sleep(0.5)
        # Daemon thread — may or may not be alive depending on cleanup timing.
        # We just assert that subsequent acquires work (no deadlock from leaked state)
        with in_process_client.lease_sync(
            resource="r/2", holder="b", ttl_seconds=60,
        ):
            pass


# ─────────────────────────────────────────────────────────────
# Multi-tenant / concurrent SDK use
# ─────────────────────────────────────────────────────────────

async def test_two_clients_can_share_backend(in_process_client, file_client):
    """Two Swarmlock clients with the same backend (or distinct) should not interfere."""
    sl1 = in_process_client
    sl2 = Swarmlock(backend="in_process", admin_token="sekret")
    async with sl1:
        async with sl2:
            async with await sl1.lease(
                resource="r/1", holder="a", ttl_seconds=60,
            ) as l1:
                async with await sl2.lease(
                    resource="r/2", holder="b", ttl_seconds=60,
                ) as l2:
                    assert l1.lease_id != l2.lease_id
                    assert l1.fencing_token == 1
                    assert l2.fencing_token == 1
