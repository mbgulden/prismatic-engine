"""Tests for InProcessBackend (SWL-1.4).

Covers happy-path verbs: acquire, renew, release, inspect, list, history.
Failure-mode tests live in tests/test_failure_modes.py.
"""
from __future__ import annotations


import pytest

from swarmlock.backends.in_process import InProcessBackend
from swarmlock.errors import ResourceHeldError
from swarmlock.types import (
    AcquireRequest, Intent,
    InspectRequest, ListRequest, HistoryRequest,
    RenewRequest, ReleaseRequest,
)


@pytest.fixture
def backend():
    return InProcessBackend(admin_token="test-admin-token")


def make_acquire(resource="r", holder="h", ttl=300, trace_id="t", **kwargs):
    return AcquireRequest(
        resource=resource,
        holder=holder,
        ttl_seconds=ttl,
        trace_id=trace_id,
        intent=Intent(reason="test", trace_id=trace_id),
        **kwargs,
    )


# ─── acquire ──────────────────────────────────────────────────────

class TestAcquire:
    async def test_fresh_acquire(self, backend):
        result = await backend.acquire(make_acquire())
        assert result.status == "acquired"
        assert result.lease is not None
        assert result.lease.holder == "h"
        assert result.lease.fencing_token == 1
        assert result.lease.acquisition_count == 1
        assert result.lease.reentrant is False

    async def test_second_acquire_same_resource_fails(self, backend):
        await backend.acquire(make_acquire(holder="alice"))
        with pytest.raises(ResourceHeldError) as exc_info:
            await backend.acquire(make_acquire(holder="bob", wait="fail"))
        assert exc_info.value.code == "RESOURCE_HELD"
        assert exc_info.value.current_holder == "alice"
        assert exc_info.value.current_fencing_token == 1
        assert exc_info.value.retry_after_ms == 250

    async def test_reentrant_acquire_same_holder_same_trace(self, backend):
        first = await backend.acquire(make_acquire(trace_id="abc"))
        second = await backend.acquire(make_acquire(trace_id="abc"))
        assert second.status == "acquired"
        assert second.lease.lease_id == first.lease.lease_id
        assert second.lease.fencing_token == first.lease.fencing_token  # unchanged
        assert second.lease.acquisition_count == 2
        assert second.lease.reentrant is True

    async def test_reentrant_does_not_reset_ttl(self, backend):
        first = await backend.acquire(make_acquire(trace_id="abc"))
        # Wait a tiny bit, then reentrant acquire
        import asyncio
        await asyncio.sleep(0.05)
        second = await backend.acquire(make_acquire(trace_id="abc"))
        # expires_at must be the SAME, not later (no TTL reset)
        assert second.lease.expires_at == first.lease.expires_at

    async def test_fencing_token_monotonically_increases(self, backend):
        r1 = await backend.acquire(make_acquire(resource="r", holder="a", trace_id="t1"))
        await backend.release(ReleaseRequest(lease_id=r1.lease.lease_id, holder="a"))
        r2 = await backend.acquire(make_acquire(resource="r", holder="b", trace_id="t2"))
        assert r2.lease.fencing_token == 2
        assert r2.lease.fencing_token > r1.lease.fencing_token


# ─── renew ────────────────────────────────────────────────────────

class TestRenew:
    async def test_renew_extends_ttl(self, backend):
        result = await backend.acquire(make_acquire(ttl=10))
        original_expires = result.lease.expires_at
        renew = await backend.renew(RenewRequest(
            lease_id=result.lease.lease_id, holder="h", extend_by_seconds=60,
        ))
        assert renew.status == "renewed"
        assert renew.expires_at > original_expires

    async def test_renew_wrong_holder_lost(self, backend):
        result = await backend.acquire(make_acquire())
        renew = await backend.renew(RenewRequest(
            lease_id=result.lease.lease_id, holder="other", extend_by_seconds=60,
        ))
        assert renew.status == "lost"

    async def test_renew_after_expiry_lost(self, backend):
        # Use a tiny TTL and sleep past it
        result = await backend.acquire(make_acquire(ttl=1))
        import asyncio
        await asyncio.sleep(1.2)
        renew = await backend.renew(RenewRequest(
            lease_id=result.lease.lease_id, holder="h", extend_by_seconds=60,
        ))
        assert renew.status == "lost"
        assert "expired" in renew.error.lower()


# ─── release ──────────────────────────────────────────────────────

class TestRelease:
    async def test_release_full(self, backend):
        result = await backend.acquire(make_acquire())
        release = await backend.release(ReleaseRequest(
            lease_id=result.lease.lease_id, holder="h",
        ))
        assert release.status == "released"
        # Subsequent acquire gets fresh state
        next_acq = await backend.acquire(make_acquire())
        assert next_acq.status == "acquired"
        assert next_acq.lease.lease_id != result.lease.lease_id

    async def test_reentrant_release_decrements_only(self, backend):
        await backend.acquire(make_acquire(trace_id="abc"))  # count=1
        r2 = await backend.acquire(make_acquire(trace_id="abc"))  # count=2
        # First release: noop, count drops to 1
        rel1 = await backend.release(ReleaseRequest(
            lease_id=r2.lease.lease_id, holder="h",
        ))
        assert rel1.status == "noop"
        assert rel1.remaining_acquisitions == 1
        # Second release: actually released
        rel2 = await backend.release(ReleaseRequest(
            lease_id=r2.lease.lease_id, holder="h",
        ))
        assert rel2.status == "released"

    async def test_release_wrong_holder(self, backend):
        result = await backend.acquire(make_acquire())
        rel = await backend.release(ReleaseRequest(
            lease_id=result.lease.lease_id, holder="other",
        ))
        assert rel.status == "lost"


# ─── inspect ──────────────────────────────────────────────────────

class TestInspect:
    async def test_inspect_held(self, backend):
        await backend.acquire(make_acquire(holder="alice"))
        result = await backend.inspect(InspectRequest(resource="r"))
        assert result.status == "found"
        assert result.holder == "alice"
        assert result.state == "HELD"
        assert result.ttl_remaining_seconds > 0
        assert result.fencing_token == 1

    async def test_inspect_none(self, backend):
        result = await backend.inspect(InspectRequest(resource="r"))
        assert result.status == "none"

    async def test_inspect_redacts_intent_when_disabled(self, backend):
        await backend.acquire(make_acquire())
        result = await backend.inspect(InspectRequest(resource="r", include_intent=False))
        assert result.intent is None

    async def test_inspect_includes_intent_when_enabled(self, backend):
        await backend.acquire(make_acquire())
        result = await backend.inspect(InspectRequest(resource="r", include_intent=True))
        assert result.intent is not None


# ─── list ─────────────────────────────────────────────────────────

class TestList:
    async def test_list_empty(self, backend):
        result = await backend.list(ListRequest())
        assert result.count == 0
        assert result.leases == []

    async def test_list_multiple(self, backend):
        await backend.acquire(make_acquire(resource="a", trace_id="t1"))
        await backend.acquire(make_acquire(resource="b", trace_id="t2"))
        result = await backend.list(ListRequest())
        assert result.count == 2
        resources = {l.resource for l in result.leases}
        assert resources == {"a", "b"}

    async def test_list_with_prefix(self, backend):
        await backend.acquire(make_acquire(resource="orders/cart-7", trace_id="t1"))
        await backend.acquire(make_acquire(resource="users/alice", trace_id="t2"))
        result = await backend.list(ListRequest(resource_prefix="orders/"))
        assert result.count == 1
        assert result.leases[0].resource == "orders/cart-7"


# ─── history ──────────────────────────────────────────────────────

class TestHistory:
    async def test_history_records_acquire(self, backend):
        await backend.acquire(make_acquire())
        result = await backend.history(HistoryRequest(resource="r"))
        assert len(result.events) >= 1
        assert result.events[0].event == "acquired"

    async def test_history_records_renew(self, backend):
        result = await backend.acquire(make_acquire())
        await backend.renew(RenewRequest(
            lease_id=result.lease.lease_id, holder="h", extend_by_seconds=60,
        ))
        hist = await backend.history(HistoryRequest(resource="r"))
        events = [e.event for e in hist.events]
        assert "acquired" in events
        assert "renewed" in events

    async def test_history_records_release(self, backend):
        result = await backend.acquire(make_acquire())
        await backend.release(ReleaseRequest(
            lease_id=result.lease.lease_id, holder="h",
        ))
        hist = await backend.history(HistoryRequest(resource="r"))
        events = [e.event for e in hist.events]
        assert "released" in events
