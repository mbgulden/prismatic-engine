"""Failure-mode integration tests (SWL-3.x).

These are the 3 mandatory + 3 bonus failure-mode tests per Gemini's directive
and George's scope decision. All run against InProcessBackend (Redis variant
deferred to SWL-3.6).

Spec sections tested:
  SWL-3.1 — Lock-Holder Death (§7.1) — TTL elapses without renew, lease auto-expires
  SWL-3.2 — Stale Lease & Fencing (§13, §7.3) — TTL-outliving reasoning delay;
              downstream wrapper rejects stale write
  SWL-3.3 — Background Heartbeat (§9.2, §5.2) — lease stays HELD via SDK auto-renewal
  SWL-3.4 — Self-Deadlock / Reentrancy (§14, §7.4) — sub-tool re-acquires same lock
  SWL-3.5 — Cascade Revocation (§5.8, §15) — parent-task revoke_all
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass

import pytest

from swarmlock.backends.in_process import InProcessBackend
from swarmlock.errors import ResourceHeldError, StaleFencingTokenError
from swarmlock.types import (
    AcquireRequest, Intent,
    ReleaseRequest, RenewRequest,
    RevokeAllRequest, StealRequest,
)


# ─────────────────────────────────────────────────────────────
# Test fixtures
# ─────────────────────────────────────────────────────────────

@pytest.fixture
def backend():
    return InProcessBackend(admin_token="test-admin-token")


def make_acquire(resource="r", holder="h", ttl=300, trace_id="t", parent_task=None, **kwargs):
    intent = Intent(reason="test", trace_id=trace_id, parent_task=parent_task)
    return AcquireRequest(
        resource=resource, holder=holder, ttl_seconds=ttl,
        trace_id=trace_id, intent=intent, **kwargs,
    )


# ─────────────────────────────────────────────────────────────
# Test 1 (MANDATORY): Lock-Holder Death
# ─────────────────────────────────────────────────────────────

class TestHolderDeath:
    """§7.1 — kill acquiring process mid-execution; verify EXPIRED transition
    + supervisor STOLEN succeeds.
    """

    async def test_lease_auto_expires_after_ttl(self, backend):
        # Simulate: holder acquires with tiny TTL, then "dies" (no renew).
        result = await backend.acquire(make_acquire(ttl=1))
        assert result.status == "acquired"
        # Before TTL: still HELD
        early = await backend.inspect(__import__("swarmlock").types.InspectRequest(resource="r"))
        assert early.status == "found"
        assert early.state == "HELD"
        # Wait past TTL
        await asyncio.sleep(1.2)
        # After TTL: auto-EXPIRED on next inspect
        late = await backend.inspect(__import__("swarmlock").types.InspectRequest(resource="r"))
        assert late.status == "none"

    async def test_supervisor_steal_succeeds_after_expiry(self, backend):
        """§5.6 v0.3 — steal succeeds on EXPIRED lease."""
        result = await backend.acquire(make_acquire(ttl=1))
        await asyncio.sleep(1.2)
        # Supervisor steals with new holder
        steal = await backend.steal(StealRequest(
            resource="r", new_holder="supervisor-1",
            reason="holder death detected", admin_token="test-admin-token",
        ))
        assert steal.status == "stolen"
        assert steal.old_holder == "h"
        assert steal.new_holder == "supervisor-1"
        assert steal.new_fencing_token > result.lease.fencing_token

    async def test_steal_on_held_lease_returns_409(self, backend):
        """§5.6 v0.3 — steal fails with error_code='RESOURCE_HELD' when HELD."""
        await backend.acquire(make_acquire(ttl=300))  # long TTL — stays HELD
        steal = await backend.steal(StealRequest(
            resource="r", new_holder="supervisor-1",
            reason="premature", admin_token="test-admin-token",
        ))
        assert steal.status == "denied"
        assert steal.error_code == "RESOURCE_HELD"

    async def test_steal_requires_admin_token(self, backend):
        """§5.6 — without admin_token, steal raises AdminRequiredError."""
        await backend.acquire(make_acquire(ttl=1))
        await asyncio.sleep(1.2)
        with pytest.raises(Exception) as excinfo:  # AdminRequiredError
            await backend.steal(StealRequest(
                resource="r", new_holder="x",
                reason="test", admin_token="WRONG",
            ))
        assert "admin_token" in str(excinfo.value).lower() or "ADMIN_REQUIRED" in str(excinfo.value)


# ─────────────────────────────────────────────────────────────
# Test 2 (MANDATORY): Stale Lease & Fencing
# ─────────────────────────────────────────────────────────────

@dataclass
class ProtectedStore:
    """A test fixture simulating a downstream datastore that validates fencing tokens."""
    _latest_token: dict[str, int] = None

    def __post_init__(self):
        if self._latest_token is None:
            self._latest_token = {}

    def write(self, key: str, value, fencing_token: int):
        latest = self._latest_token.get(key, 0)
        if fencing_token < latest:
            raise StaleFencingTokenError(
                f"fencing_token={fencing_token} < latest={latest} for key={key}",
                details={"resource": key, "received_token": fencing_token, "latest_token": latest},
            )
        self._latest_token[key] = fencing_token
        return value


class TestStaleLeaseFencing:
    """§13 — acquire with TTL=2s, sleep 3s without renewing, original holder's
    write is rejected by downstream because its fencing_token is stale.
    """

    async def test_stale_write_rejected_by_downstream(self, backend):
        store = ProtectedStore()

        # Holder A acquires with short TTL
        a = await backend.acquire(make_acquire(holder="alice", ttl=2, trace_id="alice-trace"))
        token_a = a.lease.fencing_token
        assert token_a == 1

        # Holder A attempts to write immediately — accepted
        store.write("orders/cart-7", "data-A", fencing_token=token_a)

        # TTL elapses without renew (simulating long reasoning)
        await asyncio.sleep(2.5)

        # Holder B acquires — gets fresh state with HIGHER fencing token
        b = await backend.acquire(make_acquire(holder="bob", ttl=300, trace_id="bob-trace"))
        token_b = b.lease.fencing_token
        assert token_b > token_a

        # Holder B writes — accepted
        store.write("orders/cart-7", "data-B", fencing_token=token_b)

        # NOW — Holder A finishes reasoning, attempts to write with STALE token
        with pytest.raises(StaleFencingTokenError) as excinfo:
            store.write("orders/cart-7", "data-A-stale", fencing_token=token_a)
        assert excinfo.value.received_token == token_a
        assert excinfo.value.latest_token == token_b
        # Final state in store is data-B
        assert store._latest_token["orders/cart-7"] == token_b

    async def test_fencing_token_incremented_after_release(self, backend):
        r1 = await backend.acquire(make_acquire(holder="a", trace_id="ta"))
        await backend.release(ReleaseRequest(lease_id=r1.lease.lease_id, holder="a"))
        r2 = await backend.acquire(make_acquire(holder="b", trace_id="tb"))
        assert r2.lease.fencing_token == r1.lease.fencing_token + 1


# ─────────────────────────────────────────────────────────────
# Test 3 (MANDATORY): Background Heartbeat
# ─────────────────────────────────────────────────────────────

class TestBackgroundHeartbeat:
    """§9.2 — background heartbeat task keeps lease alive during long blocking work.
    Here we simulate the SDK's heartbeat behavior at the backend level: the holder
    keeps renewing every (ttl/5) seconds during a long operation.
    """

    async def test_active_renewal_keeps_lease_alive(self, backend):
        # Acquire with short TTL
        result = await backend.acquire(make_acquire(ttl=2, trace_id="abc"))
        original_expires = result.lease.expires_at

        # Simulate the SDK heartbeat: renew every 0.5s for 3s (well past original TTL)
        for _ in range(6):
            await asyncio.sleep(0.5)
            renew = await backend.renew(RenewRequest(
                lease_id=result.lease.lease_id, holder="h", extend_by_seconds=2,
            ))
            assert renew.status == "renewed"

        # Lease still HELD with extended TTL
        inspect = await backend.inspect(__import__("swarmlock").types.InspectRequest(resource="r"))
        assert inspect.status == "found"
        assert inspect.state == "HELD"
        assert inspect.expires_at > original_expires

    async def test_no_renewal_leases_expire(self, backend):
        # Contrast: no renewal -> TTL expires
        result = await backend.acquire(make_acquire(ttl=1))
        await asyncio.sleep(1.5)
        renew = await backend.renew(RenewRequest(
            lease_id=result.lease.lease_id, holder="h", extend_by_seconds=60,
        ))
        assert renew.status == "lost"


# ─────────────────────────────────────────────────────────────
# Test 4 (BONUS): Self-Deadlock / Reentrancy
# ─────────────────────────────────────────────────────────────

class TestReentrancy:
    """§14 — sub-tool re-acquiring same lock does not block.
    Verified via acquisition_count=2 and same lease_id returned.
    """

    async def test_sub_tool_re_acquires_without_blocking(self, backend):
        # Parent acquires
        outer = await backend.acquire(make_acquire(trace_id="parent-flow"))
        assert outer.lease.acquisition_count == 1

        # Sub-tool re-acquires with same trace_id
        t0 = time.monotonic()
        inner = await backend.acquire(make_acquire(trace_id="parent-flow"))
        elapsed = time.monotonic() - t0

        # Should be immediate (no block)
        assert elapsed < 0.5, f"reentrant acquire blocked for {elapsed:.2f}s"

        # Same lease, incremented count
        assert inner.lease.lease_id == outer.lease.lease_id
        assert inner.lease.fencing_token == outer.lease.fencing_token  # unchanged
        assert inner.lease.acquisition_count == 2
        assert inner.lease.reentrant is True

    async def test_distinct_trace_ids_do_not_reenter(self, backend):
        """§14.3 — two sibling sub-agents with different trace_ids do NOT reenter."""
        await backend.acquire(make_acquire(trace_id="parent-flow"))
        # Distinct trace_id -> contention (raises ResourceHeldError)
        with pytest.raises(ResourceHeldError) as exc_info:
            await backend.acquire(make_acquire(trace_id="sibling-flow", wait="fail"))
        assert exc_info.value.code == "RESOURCE_HELD"
        assert exc_info.value.current_holder == "h"

    async def test_reentrant_does_not_reset_ttl(self, backend):
        outer = await backend.acquire(make_acquire(ttl=2, trace_id="parent"))
        await asyncio.sleep(0.3)
        inner = await backend.acquire(make_acquire(ttl=2, trace_id="parent"))
        # expires_at should be the same — TTL was NOT reset on reentry
        assert inner.lease.expires_at == outer.lease.expires_at


# ─────────────────────────────────────────────────────────────
# Test 5 (BONUS): Cascade Revocation
# ─────────────────────────────────────────────────────────────

class TestCascadeRevocation:
    """§5.8 + §15 — parent dies; all child leases revoked atomically.
    """

    async def test_revoke_all_releases_every_child_lease(self, backend):
        # Spawn 3 "sub-agents" each acquiring a different resource under same parent_task
        for i, resource in enumerate(["r1", "r2", "r3"]):
            result = await backend.acquire(make_acquire(
                resource=resource, holder=f"sub-{i}",
                ttl=300, trace_id=f"trace-{i}",
                parent_task="checkout-flow-9912",
            ))
            assert result.status == "acquired"

        # Verify all are HELD
        for resource in ["r1", "r2", "r3"]:
            inspect = await backend.inspect(__import__("swarmlock").types.InspectRequest(resource=resource))
            assert inspect.status == "found"

        # Parent dies — supervisor calls revoke_all
        revoke = await backend.revoke_all(RevokeAllRequest(
            parent_task="checkout-flow-9912",
            reason="parent process died",
            admin_token="test-admin-token",
        ))
        assert revoke.status == "revoked"
        assert revoke.revoked_count == 3
        assert len(revoke.revoked_lease_ids) == 3

        # All resources are now NONE
        for resource in ["r1", "r2", "r3"]:
            inspect = await backend.inspect(__import__("swarmlock").types.InspectRequest(resource=resource))
            assert inspect.status == "none"

    async def test_revoke_all_with_no_matches_returns_zero(self, backend):
        revoke = await backend.revoke_all(RevokeAllRequest(
            parent_task="nonexistent-parent",
            reason="test", admin_token="test-admin-token",
        ))
        assert revoke.status == "ok"
        assert revoke.revoked_count == 0

    async def test_revoke_all_requires_admin_token(self, backend):
        with pytest.raises(Exception) as excinfo:
            await backend.revoke_all(RevokeAllRequest(
                parent_task="x", reason="test", admin_token="WRONG",
            ))
        assert "admin" in str(excinfo.value).lower() or "ADMIN_REQUIRED" in str(excinfo.value)

    async def test_revoked_lease_can_be_re_acquired_freshly(self, backend):
        # Acquire + revoke + re-acquire
        result = await backend.acquire(make_acquire(
            parent_task="p1", trace_id="t1", holder="h",
        ))
        await backend.revoke_all(RevokeAllRequest(
            parent_task="p1", reason="test", admin_token="test-admin-token",
        ))
        # Fresh acquire should succeed with HIGHER fencing token
        re = await backend.acquire(make_acquire(
            parent_task=None, trace_id="t2", holder="h2",
        ))
        assert re.status == "acquired"
        assert re.lease.fencing_token > result.lease.fencing_token
        assert re.lease.acquisition_count == 1
