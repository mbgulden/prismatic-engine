"""
swarmlock.backends.redis_backend — Redis-backed Swarmlock coordinator.

Implements the same 8-verb protocol (spec §3, §8) as InProcessBackend and
FileBackend, but coordinates across processes / machines via a shared Redis.

Atomicity model:
- Every state mutation runs as a single Lua script (server-side atomic).
  Lua scripts execute atomically inside Redis — no other commands interleave.
- This is preferred over WATCH/MULTI/EXEC because:
  (a) Lua is one round-trip per op; WATCH/MULTI needs retries on contention.
  (b) Lua handles conditional logic + incrementing counters + writing history
      stream entries in a single atomic step.
- The lease hash lives at ``swarmlock:lease:<resource>``.
- The fencing counter at ``swarmlock:counter:<resource>``.
- Acquisition counts at ``swarmlock:acq:<reentry_key>``.
- Parent index at ``swarmlock:parent:<parent_task>`` (Redis Set).
- History at ``swarmlock:history`` (Redis Stream, append-only).

Design notes:
- All timestamps stored as ISO 8601 UTC strings (Redis string).
- Intent stored as JSON in ``intent_json`` hash field.
- ``inspect()`` computes actual state from ``expires_at`` (lazy expiration).
- ``list()`` scans keys (production should use SCAN, not KEYS — but for
  moderate-scale coordinator usage, KEYS is acceptable; we cap with MATCH
  prefix to avoid scanning unrelated keys).
"""
from __future__ import annotations

import json
import secrets
from dataclasses import asdict
from swarmlock._compat import datetime, UTC, timedelta
from typing import Any

from ..errors import (
    AdminRequiredError, ResourceHeldError,
)
from ..protocol import verify_backend
from ..types import (
    AcquireRequest, AcquireResult, HistoryEvent, HistoryRequest, HistoryResult,
    InspectRequest, InspectResult, Intent,
    Lease, LeaseSummary, ListRequest, ListResult,
    ReleaseRequest, ReleaseResult,
    RenewRequest, RenewResult,
    RevokeAllRequest, RevokeAllResult,
    StealRequest, StealResult,
)


# ─────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────

LEASE_KEY = "swarmlock:lease:"           # <resource>
COUNTER_KEY = "swarmlock:counter:"       # <resource>
ACQ_KEY = "swarmlock:acq:"               # <reentry_key>
PARENT_KEY = "swarmlock:parent:"         # <parent_task>
HISTORY_STREAM = "swarmlock:history"


def _now() -> datetime:
    return datetime.now(UTC)


def _iso(dt: datetime) -> str:
    return dt.isoformat()


def _parse(s: str) -> datetime:
    return datetime.fromisoformat(s)


def _reentry_key(resource: str, holder: str, trace_id: str | None) -> str:
    return f"{resource}||{holder}||{trace_id or ''}"


def _lease_key(resource: str) -> str:
    return f"{LEASE_KEY}{resource}"


def _counter_key(resource: str) -> str:
    return f"{COUNTER_KEY}{resource}"


def _acq_redis_key(reentry_key: str) -> str:
    return f"{ACQ_KEY}{reentry_key}"


def _parent_redis_key(parent_task: str) -> str:
    return f"{PARENT_KEY}{parent_task}"


def _decode_lease(h: dict[bytes | str, bytes | str]) -> dict[str, Any] | None:
    """Decode a Redis hash (bytes or str values) into a lease dict."""
    if not h:
        return None
    out: dict[str, Any] = {}
    for k, v in h.items():
        key = k.decode() if isinstance(k, bytes) else k
        val = v.decode() if isinstance(v, bytes) else v
        if key in ("acquired_at", "expires_at"):
            out[key] = _parse(val)
        elif key in ("ttl_seconds", "fencing_token", "acquisition_count"):
            out[key] = int(val)
        elif key == "intent_json":
            out["intent"] = Intent(**json.loads(val)) if val else None
        else:
            out[key] = val
    return out


def _record_to_lease(record: dict[str, Any], reentrant: bool = False) -> Lease:
    return Lease(
        lease_id=record["lease_id"],
        resource=record["resource"],
        holder=record["holder"],
        acquired_at=record["acquired_at"],
        expires_at=record["expires_at"],
        ttl_seconds=record["ttl_seconds"],
        fencing_token=record["fencing_token"],
        acquisition_count=record["acquisition_count"],
        reentrant=reentrant,
        intent=record.get("intent"),
        parent_task=record.get("parent_task") or None,
    )


def _new_lease_id() -> str:
    return f"lease_{secrets.token_hex(4)}"


# ─────────────────────────────────────────────────────────────
# Lua scripts (loaded on start)
# ─────────────────────────────────────────────────────────────

# ACQUIRE_SCRIPT: atomically check expiration, grant or reject.
# KEYS[1] = lease_key, KEYS[2] = counter_key, KEYS[3] = acq_key,
# KEYS[4] = parent_key (may be empty string for no parent)
# ARGV[1] = lease_id
# ARGV[2] = now_iso, ARGV[3] = expires_iso, ARGV[4] = ttl_seconds
# ARGV[5] = holder, ARGV[6] = trace_id, ARGV[7] = intent_json
# ARGV[8] = parent_task (may be empty)
# ARGV[9] = wait_mode ("queue" or "fail" or "steal-after=N")
# ARGV[10] = resource
# ARGV[11] = reentrant_holder_match ("1" or "0")
# Returns: {"acquired", lease_id, fencing_token, acq_count}
#          {"queued", current_lease_id, current_holder, current_token, retry_after_ms}
#          {"held", current_lease_id, current_holder, current_token}  (fail mode)
ACQUIRE_SCRIPT = """
local existing = redis.call('HGETALL', KEYS[1])
local now_iso = ARGV[2]
local expires_iso = ARGV[3]
local ttl_seconds = ARGV[4]
local holder = ARGV[5]
local trace_id = ARGV[6]
local intent_json = ARGV[7]
local parent_task = ARGV[8]
local wait_mode = ARGV[9]
local resource = ARGV[10]
local reentrant = ARGV[11]
local lease_id = ARGV[1]

if #existing > 0 then
    -- Decode existing lease
    local ex = {}
    for i = 1, #existing, 2 do
        ex[existing[i]] = existing[i+1]
    end
    local ex_expires = ex['expires_at']
    local ex_holder = ex['holder']
    local ex_token = ex['fencing_token']
    local ex_lease_id = ex['lease_id']
    local ex_acq_count = tonumber(ex['acquisition_count'] or '1')
    local ex_trace_id = ex['trace_id'] or ''

    -- Check expiration
    if now_iso < ex_expires then
        -- Still held. Check reentrancy.
        if reentrant == '1' and ex_holder == holder and
           (ex_trace_id == '' or trace_id == '' or ex_trace_id == trace_id) then
            ex_acq_count = ex_acq_count + 1
            redis.call('HSET', KEYS[1], 'acquisition_count', tostring(ex_acq_count))
            redis.call('INCR', KEYS[3])
            redis.call('XADD', 'swarmlock:history', '*',
                'event', 'renewed', 'at', now_iso,
                'lease_id', ex_lease_id, 'holder', ex_holder,
                'extend_by_seconds', '0')
            return {'acquired', ex_lease_id, ex_token, tostring(ex_acq_count), '1'}
        end
        -- Contention
        if wait_mode == 'queue' then
            return {'queued', ex_lease_id, ex_holder, ex_token, '100', '1'}
        elseif wait_mode == 'fail' then
            return {'held', ex_lease_id, ex_holder, ex_token, '0'}
        else
            return {'held', ex_lease_id, ex_holder, ex_token, '0'}
        end
    end
    -- Expired — clean up old lease entries
    redis.call('DEL', KEYS[1])
    if ex['parent_task'] and ex['parent_task'] ~= '' then
        redis.call('SREM', 'swarmlock:parent:' .. ex['parent_task'], ex_lease_id)
    end
end

-- Fresh grant
local new_token = redis.call('INCR', KEYS[2])
redis.call('HSET', KEYS[1],
    'lease_id', lease_id,
    'resource', resource,
    'holder', holder,
    'trace_id', trace_id,
    'acquired_at', now_iso,
    'expires_at', expires_iso,
    'ttl_seconds', ttl_seconds,
    'fencing_token', tostring(new_token),
    'acquisition_count', '1',
    'parent_task', parent_task,
    'intent_json', intent_json)
redis.call('SET', KEYS[3], '1')
if parent_task ~= '' then
    redis.call('SADD', 'swarmlock:parent:' .. parent_task, lease_id)
end
redis.call('XADD', 'swarmlock:history', '*',
    'event', 'acquired', 'at', now_iso,
    'lease_id', lease_id, 'holder', holder,
    'intent_json', intent_json)
return {'acquired', lease_id, tostring(new_token), '1', '0'}
"""

# RENEW_SCRIPT: extend a held lease's expiry.
# KEYS[1] = lease_key
# ARGV[1] = now_iso, ARGV[2] = new_expires_iso, ARGV[3] = holder, ARGV[4] = extend_by
# Returns: {'renewed', lease_id, new_expires} | {'lost', reason}
RENEW_SCRIPT = """
local existing = redis.call('HGETALL', KEYS[1])
if #existing == 0 then
    return {'lost', 'lease not found'}
end
local ex = {}
for i = 1, #existing, 2 do
    ex[existing[i]] = existing[i+1]
end
if ex['holder'] ~= ARGV[3] then
    return {'lost', 'holder mismatch'}
end
if ARGV[1] >= ex['expires_at'] then
    redis.call('DEL', KEYS[1])
    if ex['parent_task'] and ex['parent_task'] ~= '' then
        redis.call('SREM', 'swarmlock:parent:' .. ex['parent_task'], ex['lease_id'])
    end
    redis.call('XADD', 'swarmlock:history', '*',
        'event', 'expired', 'at', ARGV[1],
        'lease_id', ex['lease_id'], 'holder', ex['holder'])
    return {'lost', 'expired'}
end
redis.call('HSET', KEYS[1], 'expires_at', ARGV[2])
redis.call('XADD', 'swarmlock:history', '*',
    'event', 'renewed', 'at', ARGV[1],
    'lease_id', ex['lease_id'], 'holder', ex['holder'],
    'extend_by_seconds', ARGV[4])
return {'renewed', ex['lease_id'], ARGV[2]}
"""

# RELEASE_SCRIPT: decrement acq count or fully release.
# KEYS[1] = lease_key, KEYS[2] = acq_key
# ARGV[1] = holder, ARGV[2] = now_iso, ARGV[3] = reason
# Returns: {'released', lease_id} | {'noop', remaining_count} | {'lost', reason}
RELEASE_SCRIPT = """
local existing = redis.call('HGETALL', KEYS[1])
if #existing == 0 then
    return {'noop', '0'}
end
local ex = {}
for i = 1, #existing, 2 do
    ex[existing[i]] = existing[i+1]
end
if ex['holder'] ~= ARGV[1] then
    return {'lost', 'holder mismatch'}
end
local current_count = tonumber(redis.call('GET', KEYS[2]) or '1')
if current_count > 1 then
    redis.call('DECR', KEYS[2])
    redis.call('HSET', KEYS[1], 'acquisition_count', tostring(current_count - 1))
    return {'noop', tostring(current_count - 1)}
end
redis.call('DEL', KEYS[1])
redis.call('DEL', KEYS[2])
if ex['parent_task'] and ex['parent_task'] ~= '' then
    redis.call('SREM', 'swarmlock:parent:' .. ex['parent_task'], ex['lease_id'])
end
redis.call('XADD', 'swarmlock:history', '*',
    'event', 'released', 'at', ARGV[2],
    'lease_id', ex['lease_id'], 'holder', ex['holder'],
    'reason', ARGV[3])
return {'released', ex['lease_id']}
"""

# STEAL_SCRIPT: only succeeds when lease is EXPIRED (v0.3).
# KEYS[1] = lease_key, KEYS[2] = counter_key, KEYS[3] = new_acq_key
# ARGV[1] = now_iso, ARGV[2] = expires_iso, ARGV[3] = ttl_seconds,
# ARGV[4] = new_holder, ARGV[5] = intent_json, ARGV[6] = admin_reason,
# ARGV[7] = new_lease_id, ARGV[8] = resource
# Returns: {'stolen', old_lease_id, new_lease_id, new_token, new_expires}
#          {'denied', current_lease_id, current_holder, current_token}
STEAL_SCRIPT = """
local existing = redis.call('HGETALL', KEYS[1])
if #existing > 0 then
    local ex = {}
    for i = 1, #existing, 2 do
        ex[existing[i]] = existing[i+1]
    end
    if ARGV[1] < ex['expires_at'] then
        return {'denied', ex['lease_id'], ex['holder'], ex['fencing_token']}
    end
    -- Expired — clean up old entries
    redis.call('DEL', KEYS[1])
    if ex['parent_task'] and ex['parent_task'] ~= '' then
        redis.call('SREM', 'swarmlock:parent:' .. ex['parent_task'], ex['lease_id'])
    end
end
local new_token = redis.call('INCR', KEYS[2])
local new_lease_id = ARGV[7]
redis.call('HSET', KEYS[1],
    'lease_id', new_lease_id,
    'resource', ARGV[8],
    'holder', ARGV[4],
    'trace_id', '',
    'acquired_at', ARGV[1],
    'expires_at', ARGV[2],
    'ttl_seconds', ARGV[3],
    'fencing_token', tostring(new_token),
    'acquisition_count', '1',
    'parent_task', '',
    'intent_json', ARGV[5])
redis.call('SET', KEYS[3], '1')
redis.call('XADD', 'swarmlock:history', '*',
    'event', 'stolen', 'at', ARGV[1],
    'new_lease_id', new_lease_id,
    'holder', ARGV[4],
    'admin_reason', ARGV[6])
return {'stolen', '', new_lease_id, tostring(new_token), ARGV[2]}
"""

# REVOKE_ALL_SCRIPT: revoke every lease under a parent_task.
# KEYS[1] = parent_key
# ARGV[1] = now_iso, ARGV[2] = admin_reason
# Returns: list of revoked lease_ids (may be empty)
REVOKE_ALL_SCRIPT = """
local ids = redis.call('SMEMBERS', KEYS[1])
local revoked = {}
for i = 1, #ids do
    local lid = ids[i]
    -- Find lease by scanning for matching lease_id (single-machine scale).
    -- For large-scale production, add a lease_id → resource reverse index.
    local cursor = '0'
    repeat
        local result = redis.call('SCAN', cursor, 'MATCH', 'swarmlock:lease:*', 'COUNT', 100)
        cursor = result[1]
        local keys = result[2]
        for j = 1, #keys do
            local h = redis.call('HGETALL', keys[j])
            if #h > 0 then
                local found_lid = nil
                local holder = nil
                for k = 1, #h, 2 do
                    if h[k] == 'lease_id' then found_lid = h[k+1] end
                    if h[k] == 'holder' then holder = h[k+1] end
                end
                if found_lid == lid then
                    redis.call('DEL', keys[j])
                    redis.call('DEL', 'swarmlock:acq:' .. keys[j]:sub(20))
                    redis.call('XADD', 'swarmlock:history', '*',
                        'event', 'revoked', 'at', ARGV[1],
                        'lease_id', lid, 'holder', holder or '',
                        'admin_reason', ARGV[2])
                    table.insert(revoked, lid)
                    break
                end
            end
        end
    until cursor == '0'
end
redis.call('DEL', KEYS[1])
return revoked
"""


# ─────────────────────────────────────────────────────────────
# RedisBackend
# ─────────────────────────────────────────────────────────────

class RedisBackend:
    """Redis-backed Swarmlock coordinator.

    Parameters
    ----------
    client : redis.asyncio.Redis | None
        Pre-built async Redis client. If None, ``url`` is required.
    url : str | None
        Redis connection URL (e.g. ``redis://localhost:6379/0``). Used only
        when ``client`` is None.
    admin_token : str | None
        Token required for ``steal()`` and ``revoke_all()``.
    key_prefix : str
        Prefix for all keys (default ``swarmlock:``). Useful for isolating
        multiple Swarmlock instances on the same Redis.
    """

    def __init__(
        self,
        client: Any | None = None,
        url: str | None = None,
        admin_token: str | None = None,
        key_prefix: str = "swarmlock:",
    ) -> None:
        if client is None and url is None:
            raise ValueError("RedisBackend requires either `client` or `url`")
        self._external_client = client is not None
        self._admin_token = admin_token
        self._key_prefix = key_prefix
        self._client = client  # may be None until start()
        self._url = url
        self._scripts: dict[str, Any] = {}
        verify_backend(self)

    # ─── Lifecycle ────────────────────────────────────────────

    async def start(self) -> None:
        if self._client is None:
            import redis.asyncio as aioredis
            self._client = aioredis.from_url(self._url, decode_responses=False)
        # Load Lua scripts (cache SHA1s for EVALSHA)
        self._scripts = {
            "acquire": await self._client.script_load(ACQUIRE_SCRIPT),
            "renew": await self._client.script_load(RENEW_SCRIPT),
            "release": await self._client.script_load(RELEASE_SCRIPT),
            "steal": await self._client.script_load(STEAL_SCRIPT),
            "revoke_all": await self._client.script_load(REVOKE_ALL_SCRIPT),
        }

    async def stop(self) -> None:
        if self._client is not None and not self._external_client:
            await self._client.aclose()
            self._client = None

    # ─── Helpers ──────────────────────────────────────────────

    def _check_admin(self, token: str) -> None:
        # Constant-time comparison defends against timing side-channels
        # (Audit 5 hardening recommendation). `secrets.compare_digest`
        # takes equal time regardless of prefix match length.
        if (
            self._admin_token is None
            or not isinstance(token, str)
            or not secrets.compare_digest(token, self._admin_token)
        ):
            raise AdminRequiredError(
                "admin_token required for this operation",
                details={"verb": "steal or revoke_all"},
            )

    async def _evalsha(self, name: str, keys: list[str], args: list[str]) -> Any:
        try:
            return await self._client.evalsha(self._scripts[name], len(keys), *keys, *args)
        except Exception as e:
            # Reload scripts if Redis flushed them
            if "NOSCRIPT" in str(e):
                self._scripts[name] = await self._client.script_load(
                    {"acquire": ACQUIRE_SCRIPT, "renew": RENEW_SCRIPT,
                     "release": RELEASE_SCRIPT, "steal": STEAL_SCRIPT,
                     "revoke_all": REVOKE_ALL_SCRIPT}[name]
                )
                return await self._client.evalsha(
                    self._scripts[name], len(keys), *keys, *args
                )
            raise

    # ─── acquire (spec §5.1, §13, §14) ────────────────────────

    async def acquire(self, request: AcquireRequest) -> AcquireResult:
        now = _now()
        expires = now + timedelta(seconds=request.ttl_seconds)
        trace_id = request.trace_id or (
            request.intent.trace_id if request.intent else None
        )
        intent_json = json.dumps(asdict(request.intent)) if request.intent else ""
        parent_task = (request.intent.parent_task if request.intent else "") or ""
        lease_id = _new_lease_id()
        reentry_key = _reentry_key(request.resource, request.holder, trace_id)
        # Determine reentrant match: check current holder + trace_id BEFORE
        # calling Lua. We pre-fetch HGETALL to decide.
        existing = await self._client.hgetall(_lease_key(request.resource))
        existing_decoded = _decode_lease(existing) if existing else None
        is_reentrant = bool(
            existing_decoded
            and existing_decoded["holder"] == request.holder
            and now < existing_decoded["expires_at"]
            and (existing_decoded.get("trace_id") is None
                 or trace_id is None
                 or existing_decoded["trace_id"] == trace_id)
        )

        result = await self._evalsha(
            "acquire",
            [
                _lease_key(request.resource),
                _counter_key(request.resource),
                _acq_redis_key(reentry_key),
                _parent_redis_key(parent_task) if parent_task else "",
            ],
            [
                lease_id,
                _iso(now),
                _iso(expires),
                str(request.ttl_seconds),
                request.holder,
                trace_id or "",
                intent_json,
                parent_task,
                request.wait,
                request.resource,
                "1" if is_reentrant else "0",
            ],
        )
        # Result shape: [status, lease_id, token, acq_count, reentrant_flag]
        status = result[0].decode() if isinstance(result[0], bytes) else result[0]
        if status == "acquired":
            reentrant = (result[4] == b"1" or result[4] == "1")
            # Re-fetch lease hash to get full record
            h = await self._client.hgetall(_lease_key(request.resource))
            record = _decode_lease(h)
            assert record is not None
            return AcquireResult(
                status="acquired",
                lease=_record_to_lease(record, reentrant=reentrant),
            )
        elif status == "queued":
            cur_lease = result[1].decode() if isinstance(result[1], bytes) else result[1]
            cur_holder = result[2].decode() if isinstance(result[2], bytes) else result[2]
            cur_token = int(result[3])
            retry_ms = int(result[4])
            queue_pos = int(result[5])
            return AcquireResult(
                status="queued",
                current_lease_id=cur_lease,
                current_holder=cur_holder,
                current_fencing_token=cur_token,
                retry_after_ms=retry_ms,
                queue_position=queue_pos,
                error="resource is held; queued behind current holder",
            )
        else:  # held / fail
            cur_lease = result[1].decode() if isinstance(result[1], bytes) else result[1]
            cur_holder = result[2].decode() if isinstance(result[2], bytes) else result[2]
            cur_token = int(result[3])
            raise ResourceHeldError(
                "resource is held",
                details={
                    "resource": request.resource,
                    "current_lease_id": cur_lease,
                    "current_holder": cur_holder,
                    "current_fencing_token": cur_token,
                    "retry_after_ms": 100,
                },
            )

    # ─── renew (spec §5.2) ────────────────────────────────────

    async def renew(self, request: RenewRequest) -> RenewResult:
        now = _now()
        new_expires = now + timedelta(seconds=request.extend_by_seconds)
        # Find lease by id — scan prefix.
        lease_record = None
        lease_key = None
        async for key in self._client.scan_iter(match=f"{LEASE_KEY}*", count=100):
            h = await self._client.hgetall(key)
            if not h:
                continue
            decoded = _decode_lease(h)
            if decoded and decoded["lease_id"] == request.lease_id:
                lease_record = decoded
                lease_key = key.decode() if isinstance(key, bytes) else key
                break
        if lease_record is None:
            return RenewResult(
                status="lost",
                error=f"lease {request.lease_id} not found",
            )
        result = await self._evalsha(
            "renew",
            [lease_key],
            [
                _iso(now),
                _iso(new_expires),
                request.holder,
                str(request.extend_by_seconds),
            ],
        )
        status = result[0].decode() if isinstance(result[0], bytes) else result[0]
        if status == "renewed":
            return RenewResult(
                status="renewed",
                lease_id=request.lease_id,
                expires_at=new_expires,
            )
        else:
            reason = result[1].decode() if isinstance(result[1], bytes) else result[1]
            return RenewResult(status="lost", error=reason)

    # ─── release (spec §5.3) ──────────────────────────────────

    async def release(self, request: ReleaseRequest) -> ReleaseResult:
        now = _now()
        # Find lease by id
        lease_record = None
        lease_key = None
        async for key in self._client.scan_iter(match=f"{LEASE_KEY}*", count=100):
            h = await self._client.hgetall(key)
            if not h:
                continue
            decoded = _decode_lease(h)
            if decoded and decoded["lease_id"] == request.lease_id:
                lease_record = decoded
                lease_key = key.decode() if isinstance(key, bytes) else key
                break
        if lease_record is None:
            return ReleaseResult(status="noop", lease_id=request.lease_id)
        resource = lease_record["resource"]
        reentry_key = _reentry_key(
            resource,
            lease_record["holder"],
            lease_record.get("trace_id"),
        )
        result = await self._evalsha(
            "release",
            [lease_key, _acq_redis_key(reentry_key)],
            [
                request.holder,
                _iso(now),
                request.reason or "done",
            ],
        )
        status = result[0].decode() if isinstance(result[0], bytes) else result[0]
        if status == "released":
            return ReleaseResult(
                status="released",
                lease_id=request.lease_id,
                released_at=now,
                remaining_acquisitions=0,
            )
        elif status == "noop":
            remaining = int(result[1])
            return ReleaseResult(
                status="noop",
                lease_id=request.lease_id,
                remaining_acquisitions=remaining,
            )
        else:
            return ReleaseResult(status="lost", lease_id=request.lease_id)

    # ─── inspect (spec §5.4) ──────────────────────────────────

    async def inspect(self, request: InspectRequest) -> InspectResult:
        h = await self._client.hgetall(_lease_key(request.resource))
        record = _decode_lease(h) if h else None
        if record is None:
            return InspectResult(status="none", resource=request.resource)
        now = _now()
        if now >= record["expires_at"]:
            return InspectResult(status="none", resource=request.resource)
        ttl_remaining = max(0, int((record["expires_at"] - now).total_seconds()))
        return InspectResult(
            status="found",
            resource=request.resource,
            lease_id=record["lease_id"],
            holder=record["holder"],
            state="HELD",
            acquired_at=record["acquired_at"],
            expires_at=record["expires_at"],
            ttl_remaining_seconds=ttl_remaining,
            fencing_token=record["fencing_token"],
            acquisition_count=record["acquisition_count"],
            intent=record.get("intent") if request.include_intent else None,
        )

    # ─── list (spec §5.5) ─────────────────────────────────────

    async def list(self, request: ListRequest) -> ListResult:
        summaries: list[LeaseSummary] = []
        async for key in self._client.scan_iter(
            match=f"{LEASE_KEY}*", count=100
        ):
            k = key.decode() if isinstance(key, bytes) else key
            resource = k[len(LEASE_KEY):]
            if request.resource_prefix and not resource.startswith(request.resource_prefix):
                continue
            h = await self._client.hgetall(key)
            if not h:
                continue
            record = _decode_lease(h)
            if record is None:
                continue
            now = _now()
            if now >= record["expires_at"]:
                continue
            summaries.append(LeaseSummary(
                lease_id=record["lease_id"],
                resource=resource,
                holder=record["holder"],
                state="HELD",
            ))
            if len(summaries) >= request.limit:
                break
        return ListResult(count=len(summaries), leases=summaries)

    # ─── steal (spec §5.6 v0.3) ───────────────────────────────

    async def steal(self, request: StealRequest) -> StealResult:
        self._check_admin(request.admin_token)
        now = _now()
        new_lease_id = _new_lease_id()
        intent = Intent(reason=f"stolen: {request.reason}")
        result = await self._evalsha(
            "steal",
            [
                _lease_key(request.resource),
                _counter_key(request.resource),
                _acq_redis_key(_reentry_key(request.resource, request.new_holder, None)),
            ],
            [
                _iso(now),
                _iso(now + timedelta(seconds=60)),
                "60",
                request.new_holder,
                json.dumps(asdict(intent)),
                request.reason,
                new_lease_id,
                request.resource,
            ],
        )
        status = result[0].decode() if isinstance(result[0], bytes) else result[0]
        if status == "stolen":
            old_lease = result[1].decode() if isinstance(result[1], bytes) else result[1]
            new_lease = result[2].decode() if isinstance(result[2], bytes) else result[2]
            new_token = int(result[3])
            new_expires = _parse(result[4].decode() if isinstance(result[4], bytes) else result[4])
            return StealResult(
                status="stolen",
                old_lease_id=old_lease or None,
                new_lease_id=new_lease,
                new_holder=request.new_holder,
                stolen_at=now,
                new_expires_at=new_expires,
                new_fencing_token=new_token,
            )
        else:
            cur_lease = result[1].decode() if isinstance(result[1], bytes) else result[1]
            cur_holder = result[2].decode() if isinstance(result[2], bytes) else result[2]
            cur_token = int(result[3])
            return StealResult(
                status="denied",
                error="resource is currently HELD; use revoke_all() or wait for expiration",
                error_code="RESOURCE_HELD",
                old_lease_id=cur_lease,
                old_holder=cur_holder,
                new_fencing_token=cur_token,
            )

    # ─── history (spec §5.7) ──────────────────────────────────

    async def history(self, request: HistoryRequest) -> HistoryResult:
        events: list[HistoryEvent] = []
        # Stream entries are <id, {field: value, ...}> tuples
        start = "-"
        end = "+"
        if request.since:
            # Convert datetime to stream ID (ms timestamp)
            ms = int(request.since.timestamp() * 1000)
            start = f"{ms}-0"
        entries = await self._client.xrange(HISTORY_STREAM, start, end, count=request.limit)
        for entry_id, fields in entries:
            decoded_fields: dict[str, str] = {}
            # Fields may be a dict (fakeredis) or list of [k, v, k, v] (real redis)
            if isinstance(fields, dict):
                items = list(fields.items())
            else:
                items = []
                i = 0
                while i + 1 < len(fields):
                    items.append((fields[i], fields[i + 1]))
                    i += 2
            for raw_k, raw_v in items:
                k = raw_k.decode() if isinstance(raw_k, bytes) else raw_k
                v = raw_v.decode() if isinstance(raw_v, bytes) else raw_v
                decoded_fields[k] = v
            events.append(HistoryEvent(
                event=decoded_fields.get("event", "unknown"),
                at=_parse(decoded_fields.get("at", _iso(_now()))),
                lease_id=decoded_fields.get("lease_id"),
                holder=decoded_fields.get("holder"),
                extend_by_seconds=int(decoded_fields["extend_by_seconds"]) if "extend_by_seconds" in decoded_fields else None,
                old_lease_id=decoded_fields.get("old_lease_id"),
                new_lease_id=decoded_fields.get("new_lease_id"),
                admin_reason=decoded_fields.get("admin_reason"),
                intent=Intent(**json.loads(decoded_fields["intent_json"])) if "intent_json" in decoded_fields and decoded_fields["intent_json"] else None,
            ))
        return HistoryResult(events=events[:request.limit])

    # ─── revoke_all (spec §5.8) ───────────────────────────────

    async def revoke_all(self, request: RevokeAllRequest) -> RevokeAllResult:
        self._check_admin(request.admin_token)
        now = _now()
        revoked = await self._evalsha(
            "revoke_all",
            [_parent_redis_key(request.parent_task)],
            [_iso(now), request.reason],
        )
        revoked_ids = [
            (r.decode() if isinstance(r, bytes) else r) for r in revoked
        ]
        return RevokeAllResult(
            status="revoked",
            parent_task=request.parent_task,
            revoked_count=len(revoked_ids),
            revoked_lease_ids=revoked_ids,
            revoked_at=now,
        )


__all__ = ["RedisBackend"]
