"""
swarmlock.backends.file — File-based Swarmlock backend (spec §8.2).

Single-machine production backend. Implements all 8 verbs (spec §3, §8) with
the same reentrancy / fencing-token / cascade-revocation semantics as
InProcessBackend, but persists state to disk for crash recovery.

Concurrency model:
- One `fcntl.flock(LOCK_EX)` covers every state mutation. Multiple processes
  on the same machine serialize naturally; cross-process acquire contention
  is observed as expected.
- Each call opens the lock file fresh (per-fd locks) so a single process
  can recursively call backend methods without self-deadlock.

Storage layout (all under ``root`` directory, default ~/.swarmlock):
- ``state.json``  — live leases (atomic write: tempfile + os.replace)
- ``history.jsonl`` — append-only event log (one event per line, fcntl-locked)
- ``.lock`` — fcntl.flock target file (created lazily)

Design notes:
- Lazy expiration: ``inspect()`` and ``acquire()`` prune stale leases inline.
  There is no background reaper — leases expire on next inspection.
- History archive: events from released/expired/revoked/stolen leases are
  preserved in ``history.jsonl`` so ``history()`` can return the full log.
"""
from __future__ import annotations

import fcntl
import json
import os
import secrets
import tempfile
import threading
from collections import defaultdict
from dataclasses import asdict as _asdict
from swarmlock._compat import datetime, UTC, timedelta
from pathlib import Path
from typing import Any

from ..errors import (
    AdminRequiredError, InvalidRequestError, ResourceHeldError,
)
from ..protocol import verify_backend
from ..types import (
    AcquireRequest, AcquireResult, HistoryEvent, HistoryRequest, HistoryResult,
    InspectRequest, InspectResult, Intent,
    Lease, LeaseSummary, ListRequest, ListResult,
    ReleaseRequest, ReleaseResult,
    RenewRequest, RenewResult,
    RevokeAllRequest, RevokeAllResult,
    StealRequest, StealResult,
)


# ─────────────────────────────────────────────────────────────
# On-disk schemas
# ─────────────────────────────────────────────────────────────

# state.json shape:
# {
#   "version": 1,
#   "resources": {
#     "<resource_name>": {
#       "lease_id": str,
#       "resource": str,
#       "holder": str,
#       "trace_id": str | None,
#       "acquired_at": iso8601,
#       "expires_at": iso8601,
#       "ttl_seconds": int,
#       "fencing_token": int,
#       "acquisition_count": int,
#       "parent_task": str | None,
#       "intent": {...} | None,
#     }
#   },
#   "parent_to_leases": {"<parent_task>": ["<lease_id>", ...]},
#   "acq_counts": {"<resource>||<holder>||<trace_id>": int},
#   "fencing_counters": {"<resource>": int},
# }

SCHEMA_VERSION = 1


def _reentry_key(resource: str, holder: str, trace_id: str | None) -> str:
    """Stable dict key for acquisition_count tracking."""
    return f"{resource}||{holder}||{trace_id or ''}"


def _now() -> datetime:
    return datetime.now(UTC)


def _iso(dt: datetime) -> str:
    return dt.isoformat()


def _parse(s: str) -> datetime:
    return datetime.fromisoformat(s)


def _serialize_lease(record: dict[str, Any]) -> dict[str, Any]:
    """Ensure datetimes are iso strings for JSON."""
    out = dict(record)
    out["acquired_at"] = _iso(record["acquired_at"])
    out["expires_at"] = _iso(record["expires_at"])
    if record.get("intent"):
        intent = record["intent"]
        if hasattr(intent, "__dataclass_fields__"):
            out["intent"] = _asdict(intent)
        else:
            out["intent"] = dict(intent)
    return out


def _deserialize_lease(record: dict[str, Any]) -> dict[str, Any]:
    """Inverse of _serialize_lease — convert iso strings to datetimes."""
    out = dict(record)
    out["acquired_at"] = _parse(record["acquired_at"])
    out["expires_at"] = _parse(record["expires_at"])
    return out


def _empty_state() -> dict[str, Any]:
    return {
        "version": SCHEMA_VERSION,
        "resources": {},
        "parent_to_leases": {},
        "acq_counts": {},
        "fencing_counters": {},
    }


# ─────────────────────────────────────────────────────────────
# FileBackend
# ─────────────────────────────────────────────────────────────

class FileBackend:
    """Filesystem-based Swarmlock backend.

    Parameters
    ----------
    root : str | Path | None
        Directory for state files. Defaults to ``~/.swarmlock``.
    admin_token : str | None
        Token required for ``steal()`` and ``revoke_all()``. If None, these
        operations are rejected.
    """

    def __init__(
        self,
        root: str | Path | None = None,
        admin_token: str | None = None,
    ) -> None:
        self.root = Path(root) if root else Path.home() / ".swarmlock"
        self.root.mkdir(parents=True, exist_ok=True)
        self.state_path = self.root / "state.json"
        self.history_path = self.root / "history.jsonl"
        self.lock_path = self.root / ".lock"
        self._admin_token = admin_token
        # Per-thread fd so the same thread can re-enter methods safely.
        self._local = threading.local()
        verify_backend(self)

    # ─── Lifecycle ────────────────────────────────────────────

    async def start(self) -> None:
        # Ensure state file exists with empty schema; idempotent.
        self._read_state()

    async def stop(self) -> None:
        # Release any cached fd on this thread.
        fd = getattr(self._local, "fd", None)
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
            self._local.fd = None

    # ─── Helpers ──────────────────────────────────────────────

    def _acquire_file_lock(self):
        """Open .lock file and acquire exclusive flock for this critical section."""
        fd = os.open(str(self.lock_path), os.O_RDWR | os.O_CREAT, 0o644)
        fcntl.flock(fd, fcntl.LOCK_EX)
        return fd

    def _release_file_lock(self, fd: int) -> None:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)

    def _read_state(self) -> dict[str, Any]:
        if not self.state_path.exists():
            return _empty_state()
        try:
            with open(self.state_path) as f:
                data = json.load(f)
            if not isinstance(data, dict) or data.get("version") != SCHEMA_VERSION:
                # Schema mismatch — treat as empty (callers will overwrite).
                return _empty_state()
            # Convert lease dicts back to datetime objects
            for resource, rec in data.get("resources", {}).items():
                data["resources"][resource] = _deserialize_lease(rec)
            # Convert parent_to_leases lists back to sets for in-memory ops
            data["parent_to_leases"] = {
                k: set(v) for k, v in data.get("parent_to_leases", {}).items()
            }
            # Make sure all top-level keys exist
            for key in ("parent_to_leases", "acq_counts", "fencing_counters"):
                data.setdefault(key, {} if key != "parent_to_leases" else defaultdict(set))
            return data
        except (json.JSONDecodeError, KeyError, ValueError):
            return _empty_state()

    def _write_state(self, state: dict[str, Any]) -> None:
        """Atomic write: tmp file + os.replace."""
        # Serialise leases with iso strings, coerce sets to lists.
        serialised = {
            "version": SCHEMA_VERSION,
            "resources": {
                k: _serialize_lease(v) for k, v in state["resources"].items()
            },
            "parent_to_leases": {
                k: sorted(v) for k, v in state["parent_to_leases"].items()
            },
            "acq_counts": state["acq_counts"],
            "fencing_counters": state["fencing_counters"],
        }
        # Write to temp file in same directory, then rename atomically.
        tmp_fd, tmp_path = tempfile.mkstemp(
            dir=str(self.root), prefix=".state_", suffix=".json.tmp"
        )
        try:
            with os.fdopen(tmp_fd, "w") as f:
                json.dump(serialised, f, indent=2)
            os.replace(tmp_path, self.state_path)
        except Exception:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    def _append_history(self, event: HistoryEvent) -> None:
        """Append an event to history.jsonl under the same flock."""
        fd = self._acquire_file_lock()
        try:
            payload = {
                "event": event.event,
                "at": _iso(event.at),
                "lease_id": event.lease_id,
                "holder": event.holder,
                "extend_by_seconds": event.extend_by_seconds,
                "old_lease_id": event.old_lease_id,
                "new_lease_id": event.new_lease_id,
                "admin_reason": event.admin_reason,
                "intent": event.intent and {
                    "reason": event.intent.reason,
                    "parent_task": event.intent.parent_task,
                    "trace_id": event.intent.trace_id,
                    "metadata": event.intent.metadata,
                },
            }
            line = json.dumps(payload, separators=(",", ":")) + "\n"
            with open(self.history_path, "a") as f:
                f.write(line)
        finally:
            self._release_file_lock(fd)

    def _load_history(self, resource: str, since: datetime | None, limit: int) -> list[HistoryEvent]:
        events: list[HistoryEvent] = []
        if not self.history_path.exists():
            return events
        try:
            with open(self.history_path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    evt_at = _parse(rec["at"])
                    # Match by resource: events carry resource via intent or
                    # lease_id correlation. Since file backend doesn't
                    # denormalise resource into history events, we read all
                    # and filter in-memory. For a single-machine tool this is
                    # acceptable; large-scale users should use Redis.
                    if since and evt_at < since:
                        continue
                    events.append(HistoryEvent(
                        event=rec["event"],
                        at=evt_at,
                        lease_id=rec.get("lease_id"),
                        holder=rec.get("holder"),
                        extend_by_seconds=rec.get("extend_by_seconds"),
                        old_lease_id=rec.get("old_lease_id"),
                        new_lease_id=rec.get("new_lease_id"),
                        admin_reason=rec.get("admin_reason"),
                        intent=rec.get("intent") and Intent(
                            reason=rec["intent"]["reason"],
                            parent_task=rec["intent"].get("parent_task"),
                            trace_id=rec["intent"].get("trace_id"),
                            metadata=rec["intent"].get("metadata", {}),
                        ),
                    ))
        except OSError:
            return events
        # Sort by time, descending
        events.sort(key=lambda e: e.at, reverse=True)
        return events[:limit]

    def _check_admin(self, token: str) -> None:
        # Constant-time comparison defends against timing side-channels
        # (Audit 5 hardening recommendation). `secrets.compare_digest`
        # takes equal time regardless of prefix match length.
        if (
            self._admin_token is None
            or not isinstance(token, str)
            or not secrets.compare_digest(token, self._admin_token)
        ):
            raise AdminRequiredError(
                "admin_token required for this operation",
                details={"verb": "steal or revoke_all"},
            )

    def _new_lease_id(self) -> str:
        return f"lease_{secrets.token_hex(4)}"

    # ─── Critical section helper ──────────────────────────────

    def _critical(self, mutate):
        """Run ``mutate(state)`` under flock, persisting the result.

        ``mutate`` receives a fresh copy of the state and may mutate it in
        place (or return a new dict). After it returns, the (possibly
        modified) state is persisted via atomic write.
        """
        fd = self._acquire_file_lock()
        try:
            state = self._read_state()
            result = mutate(state)
            self._write_state(state)
            return result
        finally:
            self._release_file_lock(fd)

    # ─── Internal helpers ─────────────────────────────────────

    @staticmethod
    def _record_to_lease(record: dict[str, Any], reentrant: bool = False) -> Lease:
        return Lease(
            lease_id=record["lease_id"],
            resource=record["resource"],
            holder=record["holder"],
            acquired_at=record["acquired_at"],
            expires_at=record["expires_at"],
            ttl_seconds=record["ttl_seconds"],
            fencing_token=record["fencing_token"],
            acquisition_count=record["acquisition_count"],
            reentrant=reentrant,
            intent=record.get("intent"),
            parent_task=record.get("parent_task"),
        )

    def _prune_expired(self, state: dict[str, Any], now: datetime) -> list[HistoryEvent]:
        """Mark any expired leases as expired and emit history events."""
        events: list[HistoryEvent] = []
        expired_resources = []
        for resource, rec in state["resources"].items():
            if now >= rec["expires_at"]:
                expired_resources.append(resource)
                events.append(HistoryEvent(
                    event="expired",
                    at=now,
                    lease_id=rec["lease_id"],
                    holder=rec["holder"],
                ))
        for resource in expired_resources:
            rec = state["resources"].pop(resource)
            # Drop from parent index and acq counts
            if rec.get("parent_task") and rec["parent_task"] in state["parent_to_leases"]:
                state["parent_to_leases"][rec["parent_task"]].discard(rec["lease_id"])
            key = _reentry_key(rec["resource"], rec["holder"], rec.get("trace_id"))
            state["acq_counts"].pop(key, None)
        return events

    def _grant_fresh(
        self,
        state: dict[str, Any],
        request: AcquireRequest,
        reentry_key: str,
        now: datetime,
    ) -> tuple[dict[str, Any], list[HistoryEvent]]:
        """Allocate a new lease on a free resource. Returns (record, events)."""
        events: list[HistoryEvent] = []
        # Bump fencing token (per-resource monotonic counter)
        state["fencing_counters"][request.resource] = (
            state["fencing_counters"].get(request.resource, 0) + 1
        )
        token = state["fencing_counters"][request.resource]
        lease_id = self._new_lease_id()
        intent = request.intent
        parent_task = intent.parent_task if intent else None
        record = {
            "lease_id": lease_id,
            "resource": request.resource,
            "holder": request.holder,
            "trace_id": request.trace_id,
            "acquired_at": now,
            "expires_at": now + timedelta(seconds=request.ttl_seconds),
            "ttl_seconds": request.ttl_seconds,
            "fencing_token": token,
            "acquisition_count": 1,
            "parent_task": parent_task,
            "intent": intent,
        }
        state["resources"][request.resource] = record
        state["acq_counts"][reentry_key] = 1
        if parent_task:
            state["parent_to_leases"].setdefault(parent_task, set()).add(lease_id)
        events.append(HistoryEvent(
            event="acquired",
            at=now,
            lease_id=lease_id,
            holder=request.holder,
            intent=intent,
        ))
        return record, events

    # ─── acquire (spec §5.1, §13, §14) ────────────────────────

    async def acquire(self, request: AcquireRequest) -> AcquireResult:
        now = _now()
        trace_id = request.trace_id or (
            request.intent.trace_id if request.intent else None
        )
        reentry_key = _reentry_key(request.resource, request.holder, trace_id)

        def _mutate(state: dict[str, Any]) -> AcquireResult:
            # Lazy expiration: prune any stale lease first
            existing = state["resources"].get(request.resource)
            all_events: list[HistoryEvent] = []
            if existing is not None and now >= existing["expires_at"]:
                all_events.extend(self._prune_expired(state, now))
                existing = None

            # Fresh acquire (resource free)
            if existing is None:
                record, events = self._grant_fresh(state, request, reentry_key, now)
                all_events.extend(events)
                result = AcquireResult(
                    status="acquired",
                    lease=self._record_to_lease(record, reentrant=False),
                )
            # Reentrant acquire (matching holder + trace_id)
            elif (
                existing["holder"] == request.holder
                and (existing["trace_id"] is None or trace_id is None
                     or existing["trace_id"] == trace_id)
            ):
                existing["acquisition_count"] += 1
                state["acq_counts"][reentry_key] = existing["acquisition_count"]
                # TTL is NOT reset on reentrant acquire (§14.2)
                all_events.append(HistoryEvent(
                    event="renewed",  # reentrant increments, conceptually a renewal
                    at=now,
                    lease_id=existing["lease_id"],
                    holder=existing["holder"],
                    extend_by_seconds=0,
                ))
                result = AcquireResult(
                    status="acquired",
                    lease=self._record_to_lease(existing, reentrant=True),
                )
            # Contention — handle by wait mode
            else:
                # v0.3 spec: wait="queue" returns queued status with retry_after_ms
                if request.wait == "queue":
                    result = AcquireResult(
                        status="queued",
                        current_lease_id=existing["lease_id"],
                        current_holder=existing["holder"],
                        current_fencing_token=existing["fencing_token"],
                        retry_after_ms=100,
                        queue_position=1,
                        error="resource is held; queued behind current holder",
                    )
                elif request.wait == "fail":
                    raise ResourceHeldError(
                        "resource is held",
                        details={
                            "resource": request.resource,
                            "current_lease_id": existing["lease_id"],
                            "current_holder": existing["holder"],
                            "current_fencing_token": existing["fencing_token"],
                            "retry_after_ms": 100,
                        },
                    )
                else:
                    raise InvalidRequestError(
                        f"unsupported wait mode: {request.wait}",
                        details={"wait": request.wait},
                    )

            # Persist any history events (acquired/renewed/expired) generated
            # inside the critical section by re-acquiring the lock briefly.
            for evt in all_events:
                self._append_history_unlocked(evt)
            return result

        return self._critical(_mutate)

    # ─── renew (spec §5.2) ────────────────────────────────────

    async def renew(self, request: RenewRequest) -> RenewResult:
        def _mutate(state: dict[str, Any]) -> RenewResult:
            now = _now()
            # Find lease by id (could iterate but state["resources"] is per-resource)
            lease_record = None
            for rec in state["resources"].values():
                if rec["lease_id"] == request.lease_id:
                    lease_record = rec
                    break
            if lease_record is None:
                return RenewResult(
                    status="lost",
                    error=f"lease {request.lease_id} not found or already released",
                )
            if lease_record["holder"] != request.holder:
                return RenewResult(
                    status="lost",
                    error="holder mismatch",
                )
            if now >= lease_record["expires_at"]:
                # Already expired — prune and report lost
                self._prune_expired(state, now)
                return RenewResult(
                    status="lost",
                    error="lease has expired",
                )
            lease_record["expires_at"] = now + timedelta(seconds=request.extend_by_seconds)
            self._append_history_unlocked(HistoryEvent(
                event="renewed",
                at=now,
                lease_id=lease_record["lease_id"],
                holder=lease_record["holder"],
                extend_by_seconds=request.extend_by_seconds,
            ))
            return RenewResult(
                status="renewed",
                lease_id=lease_record["lease_id"],
                expires_at=lease_record["expires_at"],
            )

        return self._critical(_mutate)

    # ─── release (spec §5.3) ──────────────────────────────────

    async def release(self, request: ReleaseRequest) -> ReleaseResult:
        def _mutate(state: dict[str, Any]) -> ReleaseResult:
            lease_record = None
            for resource, rec in state["resources"].items():
                if rec["lease_id"] == request.lease_id:
                    lease_record = rec
                    break
            if lease_record is None:
                return ReleaseResult(
                    status="noop",
                    lease_id=request.lease_id,
                )
            if lease_record["holder"] != request.holder:
                return ReleaseResult(
                    status="lost",
                    lease_id=request.lease_id,
                )
            key = _reentry_key(
                lease_record["resource"],
                lease_record["holder"],
                lease_record.get("trace_id"),
            )
            current_count = state["acq_counts"].get(key, lease_record["acquisition_count"])
            if current_count > 1:
                # Reentrant release — decrement, don't remove
                state["acq_counts"][key] = current_count - 1
                lease_record["acquisition_count"] = current_count - 1
                return ReleaseResult(
                    status="noop",
                    lease_id=request.lease_id,
                    remaining_acquisitions=current_count - 1,
                )
            # Final release
            now = _now()
            resource = lease_record["resource"]
            state["resources"].pop(resource, None)
            if lease_record.get("parent_task"):
                idx = state["parent_to_leases"].get(lease_record["parent_task"])
                if idx is not None:
                    idx.discard(lease_record["lease_id"])
            state["acq_counts"].pop(key, None)
            self._append_history_unlocked(HistoryEvent(
                event="released",
                at=now,
                lease_id=lease_record["lease_id"],
                holder=lease_record["holder"],
            ))
            return ReleaseResult(
                status="released",
                lease_id=request.lease_id,
                released_at=now,
                remaining_acquisitions=0,
            )

        return self._critical(_mutate)

    # ─── inspect (spec §5.4) ──────────────────────────────────

    async def inspect(self, request: InspectRequest) -> InspectResult:
        def _mutate(state: dict[str, Any]) -> InspectResult:
            now = _now()
            rec = state["resources"].get(request.resource)
            if rec is None:
                return InspectResult(
                    status="none",
                    resource=request.resource,
                )
            if now >= rec["expires_at"]:
                # Expired — prune and report none
                self._prune_expired(state, now)
                return InspectResult(
                    status="none",
                    resource=request.resource,
                )
            ttl_remaining = max(0, int((rec["expires_at"] - now).total_seconds()))
            return InspectResult(
                status="found",
                resource=request.resource,
                lease_id=rec["lease_id"],
                holder=rec["holder"],
                state="HELD",
                acquired_at=rec["acquired_at"],
                expires_at=rec["expires_at"],
                ttl_remaining_seconds=ttl_remaining,
                fencing_token=rec["fencing_token"],
                acquisition_count=rec["acquisition_count"],
                intent=rec.get("intent") if request.include_intent else None,
            )

        return self._critical(_mutate)

    # ─── list (spec §5.5) ─────────────────────────────────────

    async def list(self, request: ListRequest) -> ListResult:
        def _mutate(state: dict[str, Any]) -> ListResult:
            now = _now()
            self._prune_expired(state, now)
            summaries: list[LeaseSummary] = []
            for resource, rec in state["resources"].items():
                if request.resource_prefix and not resource.startswith(request.resource_prefix):
                    continue
                summaries.append(LeaseSummary(
                    lease_id=rec["lease_id"],
                    resource=resource,
                    holder=rec["holder"],
                    state="HELD",
                ))
                if len(summaries) >= request.limit:
                    break
            return ListResult(count=len(summaries), leases=summaries)

        return self._critical(_mutate)

    # ─── steal (spec §5.6 v0.3) ───────────────────────────────

    async def steal(self, request: StealRequest) -> StealResult:
        self._check_admin(request.admin_token)

        def _mutate(state: dict[str, Any]) -> StealResult:
            now = _now()
            existing = state["resources"].get(request.resource)
            # v0.3 simplification: steal only succeeds when lease is EXPIRED.
            # On HELD, return denied (caller should wait or use revoke_all).
            if existing is not None and now < existing["expires_at"]:
                return StealResult(
                    status="denied",
                    error="resource is currently HELD; use revoke_all() or wait for expiration",
                    error_code="RESOURCE_HELD",
                    old_lease_id=existing["lease_id"],
                    old_holder=existing["holder"],
                    new_fencing_token=existing["fencing_token"],
                )
            # Resource is free or expired — grant new lease to new_holder
            if existing is not None and now >= existing["expires_at"]:
                # Prune the expired lease
                self._prune_expired(state, now)
                existing = None
            reentry_key = _reentry_key(request.resource, request.new_holder, None)
            record, _events = self._grant_fresh(state, AcquireRequest(
                resource=request.resource,
                holder=request.new_holder,
                ttl_seconds=60,  # default for stolen leases; SDK may renew
                intent=Intent(reason=f"stolen: {request.reason}"),
            ), reentry_key, now)
            self._append_history_unlocked(HistoryEvent(
                event="stolen",
                at=now,
                old_lease_id=existing["lease_id"] if existing else None,
                new_lease_id=record["lease_id"],
                holder=request.new_holder,
                admin_reason=request.reason,
            ))
            return StealResult(
                status="stolen",
                old_lease_id=existing["lease_id"] if existing else None,
                old_holder=existing["holder"] if existing else None,
                new_lease_id=record["lease_id"],
                new_holder=request.new_holder,
                stolen_at=now,
                new_expires_at=record["expires_at"],
                new_fencing_token=record["fencing_token"],
            )

        return self._critical(_mutate)

    # ─── history (spec §5.7) ──────────────────────────────────

    async def history(self, request: HistoryRequest) -> HistoryResult:
        # Read history file (no lock needed for read; append-only log is
        # crash-safe via flock'd writes that complete or don't).
        events = self._load_history(request.resource, request.since, request.limit)
        # Also include any live-lease events still in state (acquired/renewed
        # that haven't been released). We do this by reading state under lock.
        def _mutate(state: dict[str, Any]) -> HistoryResult:
            for resource, rec in state["resources"].items():
                if resource != request.resource:
                    continue
                events.append(HistoryEvent(
                    event="acquired",
                    at=rec["acquired_at"],
                    lease_id=rec["lease_id"],
                    holder=rec["holder"],
                    intent=rec.get("intent"),
                ))
            return HistoryResult(events=events)
        return self._critical(_mutate)

    # ─── revoke_all (spec §5.8) ───────────────────────────────

    async def revoke_all(self, request: RevokeAllRequest) -> RevokeAllResult:
        self._check_admin(request.admin_token)

        def _mutate(state: dict[str, Any]) -> RevokeAllResult:
            now = _now()
            lease_ids = list(state["parent_to_leases"].get(request.parent_task, set()))
            revoked_ids: list[str] = []
            for lid in lease_ids:
                # Find the lease by id
                for resource, rec in list(state["resources"].items()):
                    if rec["lease_id"] == lid:
                        key = _reentry_key(resource, rec["holder"], rec.get("trace_id"))
                        state["resources"].pop(resource, None)
                        state["acq_counts"].pop(key, None)
                        revoked_ids.append(lid)
                        self._append_history_unlocked(HistoryEvent(
                            event="revoked",
                            at=now,
                            lease_id=lid,
                            holder=rec["holder"],
                            admin_reason=request.reason,
                        ))
                        break
            # Clean the parent index
            state["parent_to_leases"].pop(request.parent_task, None)
            return RevokeAllResult(
                status="revoked",
                parent_task=request.parent_task,
                revoked_count=len(revoked_ids),
                revoked_lease_ids=revoked_ids,
                revoked_at=now,
            )

        return self._critical(_mutate)

    # ─── Internal: append history without re-acquiring flock ──

    def _append_history_unlocked(self, event: HistoryEvent) -> None:
        """Append history event. Caller MUST hold the flock."""
        payload = {
            "event": event.event,
            "at": _iso(event.at),
            "lease_id": event.lease_id,
            "holder": event.holder,
            "extend_by_seconds": event.extend_by_seconds,
            "old_lease_id": event.old_lease_id,
            "new_lease_id": event.new_lease_id,
            "admin_reason": event.admin_reason,
            "intent": event.intent and {
                "reason": event.intent.reason,
                "parent_task": event.intent.parent_task,
                "trace_id": event.intent.trace_id,
                "metadata": event.intent.metadata,
            },
        }
        line = json.dumps(payload, separators=(",", ":")) + "\n"
        with open(self.history_path, "a") as f:
            f.write(line)


__all__ = ["FileBackend"]
