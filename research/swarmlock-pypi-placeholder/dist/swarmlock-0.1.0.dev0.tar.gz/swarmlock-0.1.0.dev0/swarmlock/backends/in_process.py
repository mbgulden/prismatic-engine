"""
swarmlock.backends.in_process — In-process Swarmlock backend.

Single-process, asyncio-based backend for testing and small-scale use.
Implements all 8 verbs (spec §3, §8) with full reentrancy, fencing tokens,
cascade revocation, and the simplified v0.3 steal semantics.

Concurrency model:
- One asyncio.Lock protects all internal dict mutations.
- Thread-safe via the same lock — sync callers acquire it synchronously.
- Lazy expiration: `inspect()` and `acquire()` prune stale leases inline.
  There is no background reaper.

Storage layout (in-memory):
    _resources: dict[resource_name, LeaseRecord]
    _parent_to_leases: dict[parent_task, set[lease_id]]   # for revoke_all cascade
    _acquisition_counts: dict[(resource, holder, trace_id), int]

Design notes:
- acquisition_counts is keyed by reentrancy triple (§14). When the counter
  reaches 0, the lease is released. revoke_all force-zeros regardless.
- Fencing token is a per-resource monotonic counter (§13), incremented atomically
  with each fresh grant. Reentrant acquires return the same token.
- `inspect()` computes the actual state from expires_at (does not trust cached
  state) so callers always see ground truth.
"""
from __future__ import annotations

import asyncio
import secrets
from collections import defaultdict
from dataclasses import dataclass, field
from swarmlock._compat import datetime, UTC, timedelta

from ..errors import (
    AdminRequiredError, ResourceHeldError,
)
from ..protocol import verify_backend
from ..types import (
    AcquireRequest, AcquireResult, HistoryEvent, HistoryRequest, HistoryResult,
    InspectRequest, InspectResult, Intent,
    Lease, LeaseSummary, ListRequest, ListResult,
    ReleaseRequest, ReleaseResult,
    RenewRequest, RenewResult,
    RevokeAllRequest, RevokeAllResult,
    StealRequest, StealResult,
)


# ─────────────────────────────────────────────────────────────
# Internal record
# ─────────────────────────────────────────────────────────────

@dataclass
class _LeaseRecord:
    """Internal representation of a held lease."""
    lease_id: str
    resource: str
    holder: str
    trace_id: str | None
    acquired_at: datetime
    expires_at: datetime
    ttl_seconds: int
    fencing_token: int
    acquisition_count: int
    parent_task: str | None
    intent: Intent | None
    events: list[HistoryEvent] = field(default_factory=list)

    def to_lease(self) -> Lease:
        return Lease(
            lease_id=self.lease_id,
            resource=self.resource,
            holder=self.holder,
            acquired_at=self.acquired_at,
            expires_at=self.expires_at,
            ttl_seconds=self.ttl_seconds,
            fencing_token=self.fencing_token,
            acquisition_count=self.acquisition_count,
            reentrant=False,  # set by caller if needed
            intent=self.intent,
            parent_task=self.parent_task,
        )

    def is_expired(self, now: datetime | None = None) -> bool:
        now = now or datetime.now(UTC)
        return now >= self.expires_at


# ─────────────────────────────────────────────────────────────
# Backend implementation
# ─────────────────────────────────────────────────────────────

ADMIN_TOKEN_ENV = "SWARMLOCK_ADMIN_TOKEN"  # default admin token source


class InProcessBackend:
    """Single-process asyncio-based backend.

    Both async and sync callers may use this — sync methods are provided as
    thin wrappers that acquire the internal lock synchronously.
    """

    def __init__(self, admin_token: str | None = None) -> None:
        self._admin_token = admin_token
        self._lock = asyncio.Lock()
        # Use a plain dict for sync access; protected by threading.Lock.
        import threading
        self._sync_lock = threading.Lock()
        self._resources: dict[str, _LeaseRecord] = {}
        self._parent_to_leases: dict[str, set[str]] = defaultdict(set)
        self._acq_counts: dict[tuple[str, str, str | None], int] = {}
        self._fencing_counters: dict[str, int] = {}
        # History archive: events from released/expired/revoked/stolen leases
        # keyed by resource, so history() can return the full event log.
        self._history_archive: dict[str, list[HistoryEvent]] = defaultdict(list)
        # Verify protocol shape on construction (catches incomplete backends early)
        verify_backend(self)

    # ─── Lifecycle (spec §16) ──────────────────────────────────

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None

    # ─── Helpers ───────────────────────────────────────────────

    @staticmethod
    def _now() -> datetime:
        return datetime.now(UTC)

    def _new_lease_id(self) -> str:
        return f"lease_{secrets.token_hex(4)}"

    def _check_admin(self, token: str) -> None:
        # Constant-time comparison defends against timing side-channels
        # (Audit 5 hardening recommendation). `secrets.compare_digest`
        # takes equal time regardless of prefix match length.
        if (
            self._admin_token is None
            or not isinstance(token, str)
            or not secrets.compare_digest(token, self._admin_token)
        ):
            raise AdminRequiredError(
                "admin_token required for this operation",
                details={"verb": "steal or revoke_all"},
            )

    def _acquire_lock_sync(self):
        """Acquire the asyncio lock from a sync context.

        If we're already inside an event loop, this would deadlock — so we
        check and raise. Otherwise we run the lock acquire in a fresh loop.
        """
        try:
            asyncio.get_running_loop()
            in_loop = True
        except RuntimeError:
            in_loop = False

        if in_loop:
            raise RuntimeError(
                "Cannot call sync method from within an async event loop. "
                "Use the async variant (e.g. backend.acquire(...) instead of acquire_sync(...))."
            )
        return self._sync_lock

    # ─── acquire (spec §5.1, §13, §14) ────────────────────────

    async def acquire(self, request: AcquireRequest) -> AcquireResult:
        async with self._lock:
            return self._acquire_locked(request)

    def _acquire_locked(self, request: AcquireRequest) -> AcquireResult:
        now = self._now()
        # Lazy expiration: prune any stale lease first
        existing = self._resources.get(request.resource)
        if existing is not None and existing.is_expired(now):
            self._release_locked_internal(existing, reason="expired")
            existing = None

        trace_id = request.trace_id or (request.intent.trace_id if request.intent else None)
        reentry_key = (request.resource, request.holder, trace_id)

        # §14.1 step 1: resource is NONE -> fresh acquire
        if existing is None:
            return self._grant_fresh(request, reentry_key, now)

        # §14.1 step 2: HELD + matching reentry key -> reentrant acquire
        if existing.holder == request.holder and (
            trace_id is None or existing.trace_id == trace_id
        ):
            # Reentrancy requires explicit trace_id match (§14.3) — but allow
            # same (resource, holder) with no trace_id as a degenerate reentry.
            if existing.trace_id is None or trace_id is None or existing.trace_id == trace_id:
                existing.acquisition_count += 1
                self._acq_counts[reentry_key] = existing.acquisition_count
                # TTL is NOT reset (§14.2)
                lease = existing.to_lease()
                lease = Lease(
                    **{
                        **lease.__dict__,
                        "reentrant": True,
                        "acquisition_count": existing.acquisition_count,
                    }
                )
                # Record history
                existing.events.append(HistoryEvent(
                    event="acquired", lease_id=existing.lease_id,
                    holder=request.holder, at=now,
                    intent=request.intent,
                ))
                return AcquireResult(status="acquired", lease=lease)

        # §14.1 step 3: HELD + non-matching key -> contention
        if request.wait == "fail":
            # Raise ResourceHeldError to match File/Redis backends
            # (canonical error body via §17). Callers can also accept
            # the AcquireResult(status="contended") form by catching
            # ResourceHeldError and inspecting the result fields.
            raise ResourceHeldError(
                "resource is held",
                details={
                    "resource": request.resource,
                    "current_lease_id": existing.lease_id,
                    "current_holder": existing.holder,
                    "current_fencing_token": existing.fencing_token,
                    "retry_after_ms": 250,
                },
            )
        # wait == "queue" — for in-process we just return denied; full
        # queue semantics require a coordinator with pubsub. We surface this
        # honestly rather than implementing a half-baked queue.
        return AcquireResult(
            status="queued",
            current_holder=existing.holder,
            current_lease_id=existing.lease_id,
            current_fencing_token=existing.fencing_token,
            queue_position=1,
            error="in-process backend does not implement wait='queue'; use Redis backend or wait='fail'",
        )

    def _grant_fresh(
        self, request: AcquireRequest,
        reentry_key: tuple[str, str, str | None], now: datetime,
    ) -> AcquireResult:
        # §13: bump fencing counter atomically with grant
        new_token = self._fencing_counters.get(request.resource, 0) + 1
        self._fencing_counters[request.resource] = new_token

        trace_id = request.trace_id or (request.intent.trace_id if request.intent else None)
        parent_task = request.intent.parent_task if request.intent else None
        expires_at = now + timedelta(seconds=request.ttl_seconds)

        record = _LeaseRecord(
            lease_id=self._new_lease_id(),
            resource=request.resource,
            holder=request.holder,
            trace_id=trace_id,
            acquired_at=now,
            expires_at=expires_at,
            ttl_seconds=request.ttl_seconds,
            fencing_token=new_token,
            acquisition_count=1,
            parent_task=parent_task,
            intent=request.intent,
        )
        self._resources[request.resource] = record
        self._acq_counts[reentry_key] = 1
        if parent_task:
            self._parent_to_leases[parent_task].add(record.lease_id)

        record.events.append(HistoryEvent(
            event="acquired", lease_id=record.lease_id,
            holder=request.holder, at=now, intent=request.intent,
        ))

        return AcquireResult(status="acquired", lease=record.to_lease())

    # ─── renew (spec §5.2) ─────────────────────────────────────

    async def renew(self, request: RenewRequest) -> RenewResult:
        async with self._lock:
            return self._renew_locked(request)

    def _renew_locked(self, request: RenewRequest) -> RenewResult:
        now = self._now()
        for rec in self._resources.values():
            if rec.lease_id == request.lease_id:
                if rec.holder != request.holder:
                    return RenewResult(status="lost", error="holder mismatch")
                if rec.is_expired(now):
                    # Already expired; clean up
                    self._release_locked_internal(rec, reason="expired")
                    return RenewResult(status="lost", error="lease expired")
                rec.expires_at = now + timedelta(seconds=request.extend_by_seconds)
                rec.ttl_seconds = request.extend_by_seconds
                rec.events.append(HistoryEvent(
                    event="renewed", lease_id=rec.lease_id,
                    holder=request.holder, at=now,
                    extend_by_seconds=request.extend_by_seconds,
                ))
                return RenewResult(
                    status="renewed",
                    lease_id=rec.lease_id,
                    expires_at=rec.expires_at,
                )
        return RenewResult(status="lost", error="lease not found")

    # ─── release (spec §5.3, §14.2) ────────────────────────────

    async def release(self, request: ReleaseRequest) -> ReleaseResult:
        async with self._lock:
            return self._release_locked(request)

    def _release_locked(self, request: ReleaseRequest) -> ReleaseResult:
        now = self._now()
        for rec in list(self._resources.values()):
            if rec.lease_id == request.lease_id:
                if rec.holder != request.holder:
                    return ReleaseResult(
                        status="lost", lease_id=request.lease_id,
                    )
                # §14.2: decrement counter; only fully release at 0
                key = (rec.resource, rec.holder, rec.trace_id)
                count = self._acq_counts.get(key, 1)
                if count > 1:
                    self._acq_counts[key] = count - 1
                    rec.acquisition_count = count - 1
                    return ReleaseResult(
                        status="noop", lease_id=request.lease_id,
                        remaining_acquisitions=count - 1,
                    )
                # count == 1: full release
                self._release_locked_internal(rec, reason=request.reason or "done")
                return ReleaseResult(
                    status="released", lease_id=request.lease_id,
                    released_at=now,
                )
        return ReleaseResult(status="noop", lease_id=request.lease_id)

    def _release_locked_internal(self, rec: _LeaseRecord, reason: str) -> None:
        """Fully release a lease — used by both `release` and internal cleanup."""
        rec.events.append(HistoryEvent(
            event="released" if reason == "done" else "expired",
            lease_id=rec.lease_id, holder=rec.holder,
            at=self._now(),
        ))
        # Archive events before removing the record, so history() can still return them.
        self._history_archive[rec.resource].extend(rec.events)
        self._resources.pop(rec.resource, None)
        key = (rec.resource, rec.holder, rec.trace_id)
        self._acq_counts.pop(key, None)
        if rec.parent_task:
            s = self._parent_to_leases.get(rec.parent_task)
            if s is not None:
                s.discard(rec.lease_id)
                if not s:
                    del self._parent_to_leases[rec.parent_task]

    # ─── inspect (spec §5.4) ───────────────────────────────────

    async def inspect(self, request: InspectRequest) -> InspectResult:
        async with self._lock:
            return self._inspect_locked(request)

    def _inspect_locked(self, request: InspectRequest) -> InspectResult:
        rec = self._resources.get(request.resource)
        if rec is None:
            # Distinguish: was it ever held?
            # In-process backend doesn't track history of released leases, so
            # we return "not_found" if we never saw it, "none" if it's free.
            # For simplicity, return none (it IS free).
            return InspectResult(status="none", resource=request.resource)
        now = self._now()
        if rec.is_expired(now):
            self._release_locked_internal(rec, reason="expired")
            return InspectResult(status="none", resource=request.resource)
        ttl_remaining = max(0, int((rec.expires_at - now).total_seconds()))
        return InspectResult(
            status="found",
            resource=request.resource,
            lease_id=rec.lease_id,
            holder=rec.holder,
            state="HELD",
            acquired_at=rec.acquired_at,
            expires_at=rec.expires_at,
            ttl_remaining_seconds=ttl_remaining,
            fencing_token=rec.fencing_token,
            acquisition_count=rec.acquisition_count,
            intent=rec.intent if request.include_intent else None,
        )

    # ─── list (spec §5.5) ──────────────────────────────────────

    async def list(self, request: ListRequest) -> ListResult:
        async with self._lock:
            now = self._now()
            summaries: list[LeaseSummary] = []
            for resource, rec in self._resources.items():
                if rec.is_expired(now):
                    self._release_locked_internal(rec, reason="expired")
                    continue
                if request.resource_prefix and not resource.startswith(request.resource_prefix):
                    continue
                summaries.append(LeaseSummary(
                    lease_id=rec.lease_id,
                    resource=resource,
                    holder=rec.holder,
                    state="HELD",
                ))
                if len(summaries) >= request.limit:
                    break
            return ListResult(count=len(summaries), leases=summaries)

    # ─── steal (spec §5.6 v0.3 simplified) ─────────────────────

    async def steal(self, request: StealRequest) -> StealResult:
        self._check_admin(request.admin_token)
        async with self._lock:
            rec = self._resources.get(request.resource)
            if rec is None:
                return StealResult(
                    status="denied", error="resource not held",
                    error_code="RESOURCE_NOT_FOUND",
                )
            # §5.6 v0.3: HELD -> 409 Conflict. Use revoke_all for HELD recovery.
            if not rec.is_expired(self._now()):
                return StealResult(
                    status="denied",
                    error="lease is HELD; use revoke_all(parent_task=...) instead",
                    error_code="RESOURCE_HELD",
                )
            # Lease is EXPIRED — transfer to new holder with fresh TTL + new token
            new_token = self._fencing_counters.get(request.resource, rec.fencing_token) + 1
            self._fencing_counters[request.resource] = new_token
            now = self._now()
            old_lease_id = rec.lease_id
            old_holder = rec.holder
            new_lease_id = self._new_lease_id()
            new_rec = _LeaseRecord(
                lease_id=new_lease_id,
                resource=request.resource,
                holder=request.new_holder,
                trace_id=None,
                acquired_at=now,
                expires_at=now + timedelta(seconds=rec.ttl_seconds),
                ttl_seconds=rec.ttl_seconds,
                fencing_token=new_token,
                acquisition_count=1,
                parent_task=rec.parent_task,
                intent=rec.intent,
            )
            # Move history
            new_rec.events = rec.events + [HistoryEvent(
                event="stolen",
                lease_id=old_lease_id, at=now,
                old_lease_id=old_lease_id, new_lease_id=new_lease_id,
                admin_reason=request.reason,
            )]
            # Archive old lease events before replacing
            self._history_archive[request.resource].extend(rec.events)
            # Replace
            self._resources[request.resource] = new_rec
            # Decrement old acq count
            old_key = (rec.resource, old_holder, rec.trace_id)
            self._acq_counts.pop(old_key, None)
            # Add new acq count
            self._acq_counts[(request.resource, request.new_holder, None)] = 1

            return StealResult(
                status="stolen",
                old_lease_id=old_lease_id,
                old_holder=old_holder,
                new_lease_id=new_lease_id,
                new_holder=request.new_holder,
                stolen_at=now,
                new_expires_at=new_rec.expires_at,
                new_fencing_token=new_token,
            )

    # ─── history (spec §5.7) ───────────────────────────────────

    async def history(self, request: HistoryRequest) -> HistoryResult:
        async with self._lock:
            events: list[HistoryEvent] = []
            # Active leases
            for rec in self._resources.values():
                if rec.resource != request.resource:
                    continue
                events.extend(rec.events)
            # Archived (released/expired/revoked/stolen) leases
            events.extend(self._history_archive.get(request.resource, []))
            # Sort by timestamp
            events.sort(key=lambda e: e.at)
            if request.since is not None:
                events = [e for e in events if e.at >= request.since]
            if request.limit:
                events = events[:request.limit]
            return HistoryResult(events=events)

    # ─── revoke_all (spec §5.8, §15) ──────────────────────────

    async def revoke_all(self, request: RevokeAllRequest) -> RevokeAllResult:
        self._check_admin(request.admin_token)
        async with self._lock:
            now = self._now()
            ids = list(self._parent_to_leases.get(request.parent_task, set()))
            revoked: list[str] = []
            for lease_id in ids:
                for rec in list(self._resources.values()):
                    if rec.lease_id == lease_id:
                        rec.events.append(HistoryEvent(
                            event="revoked", lease_id=lease_id,
                            holder=rec.holder, at=now,
                            admin_reason=request.reason,
                        ))
                        self._release_locked_internal(rec, reason=request.reason)
                        revoked.append(lease_id)
                        break
            return RevokeAllResult(
                status="revoked" if revoked else "ok",
                parent_task=request.parent_task,
                revoked_count=len(revoked),
                revoked_lease_ids=revoked,
                revoked_at=now,
            )


__all__ = ["InProcessBackend"]
