"""Backend implementations for Swarmlock."""
from .in_process import InProcessBackend
from .file import FileBackend

# RedisBackend is implemented in SWL-1.5 (separate module); import lazily
# to avoid making `redis` a hard dependency for in-process-only users.

__all__ = ["InProcessBackend", "FileBackend"]


def __getattr__(name):
    """Lazy import for RedisBackend — only triggers if `redis` is installed."""
    if name == "RedisBackend":
        from .redis_backend import RedisBackend
        return RedisBackend
    raise AttributeError(f"module 'swarmlock.backends' has no attribute {name!r}")
