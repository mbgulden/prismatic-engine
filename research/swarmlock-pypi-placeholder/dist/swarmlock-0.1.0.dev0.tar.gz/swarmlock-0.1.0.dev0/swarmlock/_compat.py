"""
swarmlock._compat — Python version compatibility shims.

Python 3.11 introduced `datetime.UTC` as a shortcut for `datetime.timezone.utc`.
On 3.9 / 3.10, this name does not exist. We provide a single import location
so the rest of the codebase can use ``from swarmlock._compat import UTC``
without worrying about the runtime Python version.
"""
from datetime import datetime, timedelta  # noqa: F401  Re-exported for callers.

try:
    from datetime import UTC  # type: ignore[attr-defined]  # 3.11+
except ImportError:  # 3.9, 3.10
    from datetime import timezone as _timezone

    UTC = _timezone.utc  # type: ignore[assignment]


__all__ = ["datetime", "timedelta", "UTC"]
