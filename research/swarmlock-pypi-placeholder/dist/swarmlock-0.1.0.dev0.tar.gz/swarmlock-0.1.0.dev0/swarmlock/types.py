"""
swarmlock.types — Core dataclasses for the Swarmlock protocol.

Implements the wire-format types from spec §3 (verbs), §5 (message format),
§13 (fencing tokens), §14 (reentrancy), §17 (error body schema).

Design notes:
- Use frozen dataclasses where possible to prevent accidental mutation.
- Use field(default_factory=...) for mutable defaults (dicts, lists).
- datetime fields are timezone-aware UTC; use `datetime.now(UTC)`.
- All request types mirror the JSON shape in spec §5; response types mirror
  the canonical body in spec §17.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from swarmlock._compat import datetime, UTC
from typing import Any, Literal


# ─────────────────────────────────────────────────────────────
# Spec §2 Glossary — re-exported as type aliases
# ─────────────────────────────────────────────────────────────

# Lease state machine (spec §4.1)
LeaseState = Literal["NONE", "HELD", "EXPIRED", "STOLEN", "RELEASED", "REVOKED"]

# Wait modes for acquire (spec §5.1)
WaitMode = Literal["queue", "fail", "steal-after=N"]

# Verb names (spec §3 — The Eight Verbs)
Verb = Literal[
    "acquire", "renew", "release", "inspect", "list", "steal", "history", "revoke_all",
]


# ─────────────────────────────────────────────────────────────
# Intent metadata (spec §5.1 + §2)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class Intent:
    """Structured context attached to a lease.
    See spec §5.1 acquire request and §2 (Intent metadata).
    """
    reason: str
    parent_task: str | None = None
    trace_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


# ─────────────────────────────────────────────────────────────
# Lease (spec §5.1 success response, §5.4 inspect response)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class Lease:
    """A held lease on a resource.
    Returned to the holder on successful acquire, reentrant acquire, and inspect.
    """
    lease_id: str
    resource: str
    holder: str
    acquired_at: datetime
    expires_at: datetime
    ttl_seconds: int
    fencing_token: int                           # spec §13 — v0.2+
    acquisition_count: int = 1                   # spec §14 — v0.2+
    reentrant: bool = False                      # spec §14 — v0.2+
    intent: Intent | None = None
    parent_task: str | None = None               # redundant with intent.parent_task but convenient

    @property
    def ttl_remaining_seconds(self) -> float:
        """Seconds until expiration (negative if already expired)."""
        delta = self.expires_at - datetime.now(UTC)
        return delta.total_seconds()

    @property
    def state(self) -> LeaseState:
        """Current state derived from TTL. Does NOT contact the coordinator —
        for client-side display. For authoritative state, use `inspect()`."""
        if self.ttl_remaining_seconds > 0:
            return "HELD"
        return "EXPIRED"


# ─────────────────────────────────────────────────────────────
# Acquire — request (spec §5.1) and result (spec §5.1 + §14)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class AcquireRequest:
    """Request shape for `acquire` verb (spec §5.1)."""
    resource: str
    holder: str
    ttl_seconds: int
    wait: WaitMode = "queue"
    trace_id: str | None = None           # REQUIRED for reentrancy (§14); promoted from intent in v0.2
    intent: Intent | None = None


# Status values for acquire responses (spec §5.1)
AcquireStatus = Literal["acquired", "contended", "denied", "queued", "unavailable"]


@dataclass(frozen=True)
class AcquireResult:
    """Result of an `acquire` call. status='acquired' is the only success path;
    the others carry diagnostic info for queueing/failure handling.
    """
    status: AcquireStatus
    lease: Lease | None = None
    error: str | None = None
    retry_after_ms: int | None = None
    queue_position: int | None = None          # spec §5.1 contended/queued response
    current_lease_id: str | None = None        # for contention diagnostics
    current_fencing_token: int | None = None   # spec §5.1 — current holder's token
    current_holder: str | None = None

    @property
    def is_acquired(self) -> bool:
        return self.status == "acquired" and self.lease is not None


# ─────────────────────────────────────────────────────────────
# Renew — request/response (spec §5.2)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class RenewRequest:
    lease_id: str
    holder: str
    extend_by_seconds: int


RenewStatus = Literal["renewed", "lost"]


@dataclass(frozen=True)
class RenewResult:
    status: RenewStatus
    lease_id: str | None = None
    expires_at: datetime | None = None
    error: str | None = None         # populated when status='lost'


# ─────────────────────────────────────────────────────────────
# Release — request/response (spec §5.3)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ReleaseRequest:
    lease_id: str
    holder: str
    reason: Literal["done", "abandoned", "error"] | None = None


ReleaseStatus = Literal["released", "lost", "noop"]


@dataclass(frozen=True)
class ReleaseResult:
    status: ReleaseStatus
    lease_id: str
    released_at: datetime | None = None
    remaining_acquisitions: int = 0   # >0 means reentrant release was a no-op


# ─────────────────────────────────────────────────────────────
# Inspect — request/response (spec §5.4)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class InspectRequest:
    resource: str
    include_intent: bool = True


InspectStatus = Literal["found", "none", "not_found"]


@dataclass(frozen=True)
class InspectResult:
    status: InspectStatus
    resource: str
    lease_id: str | None = None
    holder: str | None = None
    state: LeaseState | None = None
    acquired_at: datetime | None = None
    expires_at: datetime | None = None
    ttl_remaining_seconds: int | None = None
    fencing_token: int | None = None
    acquisition_count: int | None = None
    intent: Intent | None = None


# ─────────────────────────────────────────────────────────────
# List — request/response (spec §5.5)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ListRequest:
    resource_prefix: str | None = None
    include_intent: bool = False
    limit: int = 100


@dataclass(frozen=True)
class LeaseSummary:
    lease_id: str
    resource: str
    holder: str
    state: LeaseState


@dataclass(frozen=True)
class ListResult:
    count: int
    leases: list[LeaseSummary]


# ─────────────────────────────────────────────────────────────
# Steal — request/response (spec §5.6 v0.3 simplified)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class StealRequest:
    resource: str
    new_holder: str
    reason: str
    admin_token: str


StealStatus = Literal["stolen", "denied"]


@dataclass(frozen=True)
class StealResult:
    status: StealStatus
    old_lease_id: str | None = None
    old_holder: str | None = None
    new_lease_id: str | None = None
    new_holder: str | None = None
    stolen_at: datetime | None = None
    new_expires_at: datetime | None = None
    new_fencing_token: int | None = None
    error: str | None = None
    error_code: str | None = None         # e.g. RESOURCE_HELD (§17)


# ─────────────────────────────────────────────────────────────
# History — request/response (spec §5.7)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class HistoryRequest:
    resource: str
    since: datetime | None = None
    limit: int = 100


@dataclass(frozen=True)
class HistoryEvent:
    event: Literal["acquired", "renewed", "released", "expired", "stolen", "revoked"]
    at: datetime
    lease_id: str | None = None
    holder: str | None = None
    extend_by_seconds: int | None = None
    old_lease_id: str | None = None
    new_lease_id: str | None = None
    admin_reason: str | None = None
    intent: Intent | None = None


@dataclass(frozen=True)
class HistoryResult:
    events: list[HistoryEvent]


# ─────────────────────────────────────────────────────────────
# RevokeAll — request/response (spec §5.8 v0.2)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class RevokeAllRequest:
    parent_task: str
    reason: str
    admin_token: str


RevokeAllStatus = Literal["revoked", "ok"]


@dataclass(frozen=True)
class RevokeAllResult:
    status: RevokeAllStatus
    parent_task: str
    revoked_count: int
    revoked_lease_ids: list[str]
    revoked_at: datetime | None = None


# ─────────────────────────────────────────────────────────────
# LeaseEvent — for streaming transports (spec §16.2 gRPC, §16.3 WS)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class LeaseEvent:
    """Push notification emitted by streaming transports when a subscribed lease changes."""
    resource: str
    lease_id: str | None
    holder: str | None
    event_type: Literal["acquired", "renewed", "released", "expired", "stolen", "revoked"]
    fencing_token: int
    at: datetime
    intent: Intent | None = None


# ─────────────────────────────────────────────────────────────
# WatchRequest — for streaming subscriptions (spec §16.2 gRPC)
# ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class WatchRequest:
    resource_patterns: list[str] = field(default_factory=list)  # e.g. ["orders/checkout/*"]
    parent_tasks: list[str] = field(default_factory=list)       # e.g. ["checkout-flow-9912"]
    include_intent: bool = False
