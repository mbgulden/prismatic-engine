"""
swarmlock.errors — Exception hierarchy per spec §17 (Error Codes).

Canonical error body (§17.1):
    {
      "error": {
        "code": "RESOURCE_HELD",
        "message": "...",
        "details": {...},
        "trace_id": "..."
      }
    }

The base SwarmlockError carries `code`, `message`, `details`, `trace_id`.
Concrete subclasses pre-set `code` and may add convenience attributes
(e.g. ResourceHeldError.current_holder) per spec §17.5.
"""
from __future__ import annotations

from typing import Any


class SwarmlockError(Exception):
    """Base exception for all Swarmlock errors. Carries the canonical body fields."""
    code: str = "SWARMLOCK_ERROR"
    http_status: int = 500
    grpc_status: str | None = "INTERNAL"

    def __init__(
        self,
        message: str = "",
        *,
        details: dict[str, Any] | None = None,
        trace_id: str | None = None,
    ) -> None:
        super().__init__(message or self.code)
        self.message = message or self.code
        self.details: dict[str, Any] = details or {}
        self.trace_id = trace_id

    def to_body(self) -> dict[str, Any]:
        """Render the canonical error body per spec §17.1."""
        body = {
            "code": self.code,
            "message": self.message,
            "details": self.details,
        }
        if self.trace_id is not None:
            body["trace_id"] = self.trace_id
        return {"error": body}

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(code={self.code!r}, message={self.message!r})"


# ─────────────────────────────────────────────────────────────
# Spec §17.2 — Error code → exception mapping
# ─────────────────────────────────────────────────────────────

class ResourceHeldError(SwarmlockError):
    """409 Conflict — acquire(wait='fail') and resource is HELD."""
    code = "RESOURCE_HELD"
    http_status = 409
    grpc_status = "FAILED_PRECONDITION"

    @property
    def resource(self) -> str | None:
        return self.details.get("resource")

    @property
    def current_lease_id(self) -> str | None:
        return self.details.get("current_lease_id")

    @property
    def current_fencing_token(self) -> int | None:
        return self.details.get("current_fencing_token")

    @property
    def current_holder(self) -> str | None:
        return self.details.get("current_holder")

    @property
    def retry_after_ms(self) -> int | None:
        return self.details.get("retry_after_ms")


class LeaseLostError(SwarmlockError):
    """410 Gone — renew or release against EXPIRED / STOLEN / REVOKED lease."""
    code = "LEASE_LOST"
    http_status = 410
    grpc_status = "FAILED_PRECONDITION"

    @property
    def lease_id(self) -> str | None:
        return self.details.get("lease_id")

    @property
    def last_known_state(self) -> str | None:
        return self.details.get("last_known_state")

    @property
    def lost_at(self) -> str | None:
        return self.details.get("lost_at")


class ResourceQueuedError(SwarmlockError):
    """423 Locked — acquire(wait='queue') succeeded in enqueuing the waiter.
    NOTE: not strictly an error — the HTTP status is 423 because the resource
    is logically locked. Body includes queue_position so the client can distinguish
    from a granted acquire.
    """
    code = "RESOURCE_QUEUED"
    http_status = 423
    grpc_status = "FAILED_PRECONDITION"

    @property
    def queue_position(self) -> int | None:
        return self.details.get("queue_position")

    @property
    def wait_url(self) -> str | None:
        return self.details.get("wait_url")


class AdminRequiredError(SwarmlockError):
    """403 Forbidden — steal or revoke_all without a valid admin_token."""
    code = "ADMIN_REQUIRED"
    http_status = 403
    grpc_status = "PERMISSION_DENIED"

    @property
    def verb(self) -> str | None:
        return self.details.get("verb")


class InvalidRequestError(SwarmlockError):
    """400 Bad Request — malformed payload, unknown verb, schema violation."""
    code = "INVALID_REQUEST"
    http_status = 400
    grpc_status = "INVALID_ARGUMENT"

    @property
    def field(self) -> str | None:
        return self.details.get("field")

    @property
    def reason(self) -> str | None:
        return self.details.get("reason")


class ResourceNotFoundError(SwarmlockError):
    """404 Not Found — inspect/list/history for a resource that has never been acquired."""
    code = "RESOURCE_NOT_FOUND"
    http_status = 404
    grpc_status = "NOT_FOUND"


class CoordinatorUnavailableError(SwarmlockError):
    """503 Service Unavailable — coordinator unreachable (fail-closed per spec §7.5)."""
    code = "COORDINATOR_UNAVAILABLE"
    http_status = 503
    grpc_status = "UNAVAILABLE"


class BackendError(SwarmlockError):
    """500 Internal Server Error — unexpected backend failure."""
    code = "BACKEND_ERROR"
    http_status = 500
    grpc_status = "INTERNAL"

    @property
    def backend(self) -> str | None:
        return self.details.get("backend")


class StaleFencingTokenError(SwarmlockError):
    """409 Conflict — returned by DOWNSTREAM, not by Swarmlock.
    Downstream wrapper rejected a write because the holder's fencing_token
    was lower than the latest observed token.
    """
    code = "STALE_FENCING_TOKEN"
    http_status = 409
    grpc_status: str | None = None  # not applicable — raised outside Swarmlock

    @property
    def resource(self) -> str | None:
        return self.details.get("resource")

    @property
    def received_token(self) -> int | None:
        return self.details.get("received_token")

    @property
    def latest_token(self) -> int | None:
        return self.details.get("latest_token")


# ─────────────────────────────────────────────────────────────
# Mapping helpers
# ─────────────────────────────────────────────────────────────

# Code → exception class. Used by backends to translate wire errors.
CODE_TO_EXCEPTION: dict[str, type[SwarmlockError]] = {
    cls.code: cls
    for cls in [
        ResourceHeldError, LeaseLostError, ResourceQueuedError,
        AdminRequiredError, InvalidRequestError, ResourceNotFoundError,
        CoordinatorUnavailableError, BackendError, StaleFencingTokenError,
    ]
}


def exception_from_code(
    code: str,
    message: str = "",
    *,
    details: dict[str, Any] | None = None,
    trace_id: str | None = None,
) -> SwarmlockError:
    """Build the right exception subclass from a wire-level error code.
    Falls back to SwarmlockError base if code is unknown.
    """
    cls = CODE_TO_EXCEPTION.get(code, SwarmlockError)
    return cls(message, details=details, trace_id=trace_id)


__all__ = [
    "SwarmlockError",
    "ResourceHeldError",
    "LeaseLostError",
    "ResourceQueuedError",
    "AdminRequiredError",
    "InvalidRequestError",
    "ResourceNotFoundError",
    "CoordinatorUnavailableError",
    "BackendError",
    "StaleFencingTokenError",
    "CODE_TO_EXCEPTION",
    "exception_from_code",
]
