"""
swarmlock.utils — Reserved for future shared helpers.

Currently empty. This module exists as a placeholder for cross-cutting
utilities (e.g. fencing-token validation helpers, retry helpers, clock
abstractions) that may be added in later releases without affecting the
public API surface.
"""
