"""
swarmlock.protocol — Backend Protocol defining the 8 verbs (spec §3, §8).

Every backend implementation (InProcessBackend, RedisBackend, FileBackend)
MUST provide all 8 methods. Each method MUST be atomic (spec §8).

Design:
- Use typing.Protocol for structural typing; concrete backends don't need to inherit.
- All methods are async — sync wrappers in client.py adapt by running on a private loop
  or by using thread-safe backends (InProcess supports both).
- Return *Result objects (not exceptions) so the client layer can decide how to surface
  failures. Exceptions are reserved for transport-level errors (e.g. Redis unreachable).
- acquire() returns AcquireResult with status='acquired'/'contended'/'denied'/'queued'.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

from .types import (
    AcquireRequest,
    AcquireResult,
    HistoryRequest,
    HistoryResult,
    InspectRequest,
    InspectResult,
    ListRequest,
    ListResult,
    ReleaseRequest,
    ReleaseResult,
    RenewRequest,
    RenewResult,
    RevokeAllRequest,
    RevokeAllResult,
    StealRequest,
    StealResult,
)


@runtime_checkable
class Backend(Protocol):
    """The 8-verb protocol every Swarmlock backend implements (spec §3, §8)."""

    async def acquire(self, request: AcquireRequest) -> AcquireResult: ...
    async def renew(self, request: RenewRequest) -> RenewResult: ...
    async def release(self, request: ReleaseRequest) -> ReleaseResult: ...
    async def inspect(self, request: InspectRequest) -> InspectResult: ...
    async def list(self, request: ListRequest) -> ListResult: ...
    async def steal(self, request: StealRequest) -> StealResult: ...
    async def history(self, request: HistoryRequest) -> HistoryResult: ...
    async def revoke_all(self, request: RevokeAllRequest) -> RevokeAllResult: ...

    # Optional lifecycle hooks (spec §16 — transport-agnostic).
    # Backends MAY override these; default = no-op.

    async def start(self) -> None:
        """Initialize backend resources (Redis pool, file locks, etc.)."""
        ...

    async def stop(self) -> None:
        """Release backend resources on shutdown."""
        ...

    async def watch(self, request) -> object:
        """Subscribe to lease events for the given resource patterns / parent tasks.
        Returns an async iterator yielding LeaseEvent objects (spec §16.2 / §16.3).
        Default = raises NotImplementedError — only streaming backends implement this.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement watch() — use a streaming backend"
        )


def verify_backend(obj: object) -> None:
    """Runtime structural check — raises TypeError if `obj` doesn't satisfy Backend.

    Use in backend constructors to fail fast on incomplete implementations:
        class InProcessBackend:
            ...
        verify_backend(InProcessBackend())  # raises if any verb is missing

    Note: isinstance() against @runtime_checkable Protocol is unreliable in
    Python 3.12+ when method signatures differ even slightly. We do a manual
    check of method presence + callability, which is more reliable.
    """
    missing = []
    for verb in [
        "acquire", "renew", "release", "inspect",
        "list", "steal", "history", "revoke_all",
    ]:
        if not hasattr(obj, verb) or not callable(getattr(obj, verb, None)):
            missing.append(verb)
    if missing:
        raise TypeError(
            f"{type(obj).__name__} does not satisfy Backend protocol. "
            f"Missing or non-callable: {', '.join(missing)}"
        )


__all__ = ["Backend", "verify_backend"]
