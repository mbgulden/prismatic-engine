"""
swarmlock.client — High-level Python SDK (spec §9).

Provides:
- ``Swarmlock`` — top-level client with backend factory + lifecycle
- ``AsyncLease`` — ``async with`` context manager with auto-heartbeat
- ``SyncLease``  — ``with`` context manager with auto-heartbeat daemon thread
- Low-level verb passthroughs (``.acquire()``, ``.renew()``, etc.)

Usage (spec §9.1):

    from swarmlock import Swarmlock

    sl = Swarmlock(backend="in_process")
    async with sl:
        async with await sl.lease(
            resource="orders/checkout/cart-7",
            holder="agent-42",
            ttl_seconds=300,
            trace_id="abc123",
            intent=Intent(reason="applying discount"),
        ) as lease:
            # lease.fencing_token is available for protected downstream writes
            await downstream.write(payload, fencing_token=lease.fencing_token)
            # background task auto-renews; no manual renew() needed
        # automatic release on context exit

Usage (sync, §9.2):

    with Swarmlock(backend="file") as sl:
        with sl.lease_sync(...) as lease:
            ...
"""
from __future__ import annotations

import asyncio
import threading
from swarmlock._compat import datetime, UTC
from typing import Any

from . import errors as swarmlock_errors
from .backends.file import FileBackend
from .backends.in_process import InProcessBackend
from .protocol import Backend
from .types import (
    AcquireRequest,
    AcquireResult,
    HistoryRequest,
    HistoryResult,
    Intent,
    InspectRequest,
    InspectResult,
    Lease,
    ListRequest,
    ListResult,
    ReleaseRequest,
    ReleaseResult,
    RenewRequest,
    RenewResult,
    RevokeAllRequest,
    RevokeAllResult,
    StealRequest,
    StealResult,
    WaitMode,
)


# ─────────────────────────────────────────────────────────────
# Backend factory
# ─────────────────────────────────────────────────────────────

def _resolve_backend(spec: str | Backend, **kwargs: Any) -> Backend:
    """Resolve a backend from a string identifier or pass through an instance.

    String identifiers:
    - "in_process" → InProcessBackend
    - "file"       → FileBackend (root=~/.swarmlock by default)
    - "redis"      → RedisBackend (requires url=... in kwargs)
    """
    if not isinstance(spec, str):
        return spec
    if spec == "in_process":
        return InProcessBackend(**kwargs)
    if spec == "file":
        return FileBackend(**kwargs)
    if spec == "redis":
        # Lazy import — only triggers if redis is installed.
        from .backends.redis_backend import RedisBackend
        return RedisBackend(**kwargs)
    raise ValueError(
        f"Unknown backend {spec!r}; expected 'in_process', 'file', 'redis', or a Backend instance"
    )


# ─────────────────────────────────────────────────────────────
# Heartbeat task
# ─────────────────────────────────────────────────────────────

DEFAULT_HEARTBEAT_DIVISOR = 5  # heartbeat every TTL/5 seconds by default


async def _async_heartbeat_loop(
    backend: Backend,
    lease_id: str,
    holder: str,
    interval_seconds: float,
    stop_event: asyncio.Event,
    lost_event: asyncio.Event,
    lost_error_holder: dict[str, Any],
) -> None:
    """Async heartbeat coroutine.

    Calls backend.renew(extend_by_seconds=3*interval) every
    ``interval_seconds`` seconds. The 3x multiplier is conservative:
    if one heartbeat is delayed (network blip, GC pause), the lease
    doesn't immediately expire. If renew returns status='lost', sets
    lost_event and stores the error in lost_error_holder, then exits.
    """
    extend_by = max(1, int(interval_seconds * 3))
    try:
        while not stop_event.is_set():
            # Sleep first so we don't immediately renew on entry
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=interval_seconds)
                return  # stop_event was set during sleep
            except asyncio.TimeoutError:
                pass
            # Send heartbeat
            try:
                result = await backend.renew(RenewRequest(
                    lease_id=lease_id,
                    holder=holder,
                    extend_by_seconds=extend_by,
                ))
                if result.status == "lost":
                    lost_error_holder["error"] = swarmlock_errors.LeaseLostError(
                        "heartbeat lost lease",
                        details={
                            "lease_id": lease_id,
                            "last_known_state": "EXPIRED",
                            "lost_at": datetime.now(UTC).isoformat(),
                            "renew_error": result.error,
                        },
                    )
                    lost_event.set()
                    return
            except Exception as e:  # noqa: BLE001 — surface any heartbeat error
                lost_error_holder["error"] = swarmlock_errors.BackendError(
                    f"heartbeat raised: {e!r}",
                    details={"lease_id": lease_id, "error": repr(e)},
                )
                lost_event.set()
                return
    finally:
        pass


def _sync_heartbeat_loop(
    backend: Backend,
    lease_id: str,
    holder: str,
    interval_seconds: float,
    stop_event: threading.Event,
    lost_event: threading.Event,
    lost_error_holder: dict[str, Any],
) -> None:
    """Sync heartbeat thread body. Mirrors async_heartbeat_loop."""
    extend_by = max(1, int(interval_seconds * 3))
    while not stop_event.is_set():
        if stop_event.wait(timeout=interval_seconds):
            return
        try:
            # Drive the async backend from a private loop.
            coro = backend.renew(RenewRequest(
                lease_id=lease_id,
                holder=holder,
                extend_by_seconds=extend_by,
            ))
            result = _run_coro_sync(coro)
            if result.status == "lost":
                lost_error_holder["error"] = swarmlock_errors.LeaseLostError(
                    "heartbeat lost lease",
                    details={
                        "lease_id": lease_id,
                        "last_known_state": "EXPIRED",
                        "lost_at": datetime.now(UTC).isoformat(),
                        "renew_error": result.error,
                    },
                )
                lost_event.set()
                return
        except Exception as e:  # noqa: BLE001
            lost_error_holder["error"] = swarmlock_errors.BackendError(
                f"heartbeat raised: {e!r}",
                details={"lease_id": lease_id, "error": repr(e)},
            )
            lost_event.set()
            return


def _run_coro_sync(coro):
    """Run an async coroutine to completion from sync context.

    Uses asyncio.run() in a worker thread to avoid event-loop conflicts.
    """
    result_box: list[Any] = []
    err_box: list[BaseException] = []

    def runner():
        try:
            result_box.append(asyncio.run(coro))
        except BaseException as e:  # noqa: BLE001
            err_box.append(e)

    t = threading.Thread(target=runner, daemon=True)
    t.start()
    t.join()
    if err_box:
        raise err_box[0]
    return result_box[0]


# ─────────────────────────────────────────────────────────────
# Lease handle objects (returned by context managers)
# ─────────────────────────────────────────────────────────────

class LeaseHandle:
    """Synchronous handle exposing the held lease.

    Returned by ``Swarmlock.lease_sync()``'s context manager.
    Provides ``lease.fencing_token``, ``lease.lease_id``, ``lease.acquisition_count``.
    """

    def __init__(
        self,
        lease: Lease,
        client: "Swarmlock",
        heartbeat_stop: threading.Event,
        heartbeat_lost: threading.Event,
        heartbeat_error_holder: dict[str, Any],
        heartbeat_thread: threading.Thread | None,
    ) -> None:
        self._lease = lease
        self._client = client
        self._heartbeat_stop = heartbeat_stop
        self._heartbeat_lost = heartbeat_lost
        self._heartbeat_error_holder = heartbeat_error_holder
        self._heartbeat_thread = heartbeat_thread
        self._released = False

    # Expose Lease fields as attributes
    @property
    def lease_id(self) -> str:
        return self._lease.lease_id

    @property
    def resource(self) -> str:
        return self._lease.resource

    @property
    def holder(self) -> str:
        return self._lease.holder

    @property
    def acquired_at(self) -> datetime:
        return self._lease.acquired_at

    @property
    def expires_at(self) -> datetime:
        return self._lease.expires_at

    @property
    def ttl_seconds(self) -> int:
        return self._lease.ttl_seconds

    @property
    def fencing_token(self) -> int:
        return self._lease.fencing_token

    @property
    def acquisition_count(self) -> int:
        return self._lease.acquisition_count

    @property
    def reentrant(self) -> bool:
        return self._lease.reentrant

    @property
    def intent(self) -> Intent | None:
        return self._lease.intent

    @property
    def parent_task(self) -> str | None:
        return self._lease.parent_task

    @property
    def lease(self) -> Lease:
        """The underlying Lease dataclass."""
        return self._lease

    def check_lost(self) -> None:
        """Raise LeaseLostError if the heartbeat detected the lease was lost."""
        if self._heartbeat_lost.is_set():
            err = self._heartbeat_error_holder.get("error") or swarmlock_errors.LeaseLostError(
                "lease lost",
                details={"lease_id": self._lease.lease_id},
            )
            raise err

    def refresh(self) -> Lease:
        """Re-fetch lease state from the coordinator (sync).

        Useful when the lease may have changed externally (e.g. another
        agent stole or revoked it).
        """
        async def _refresh_async() -> InspectResult:
            return await self._client.inspect(InspectRequest(
                resource=self._lease.resource, include_intent=True,
            ))

        result = _run_coro_sync(_refresh_async())
        if result.status == "found" and result.lease_id == self._lease.lease_id:
            assert result.lease_id is not None
            assert result.holder is not None
            assert result.acquired_at is not None
            assert result.expires_at is not None
            assert result.fencing_token is not None
            assert result.acquisition_count is not None
            self._lease = Lease(
                lease_id=result.lease_id,
                resource=result.resource,
                holder=result.holder,
                acquired_at=result.acquired_at,
                expires_at=result.expires_at,
                ttl_seconds=self._lease.ttl_seconds,
                fencing_token=result.fencing_token,
                acquisition_count=result.acquisition_count,
                reentrant=False,
                intent=result.intent,
                parent_task=self._lease.parent_task,
            )
        return self._lease


class AsyncLeaseHandle:
    """Async handle exposing the held lease. Mirror of LeaseHandle for async."""

    def __init__(
        self,
        lease: Lease,
        client: "Swarmlock",
        heartbeat_task: asyncio.Task | None,
        heartbeat_stop: asyncio.Event,
        heartbeat_lost: asyncio.Event,
        heartbeat_error_holder: dict[str, Any],
    ) -> None:
        self._lease = lease
        self._client = client
        self._heartbeat_task = heartbeat_task
        self._heartbeat_stop = heartbeat_stop
        self._heartbeat_lost = heartbeat_lost
        self._heartbeat_error_holder = heartbeat_error_holder
        self._released = False

    @property
    def lease_id(self) -> str:
        return self._lease.lease_id

    @property
    def resource(self) -> str:
        return self._lease.resource

    @property
    def holder(self) -> str:
        return self._lease.holder

    @property
    def acquired_at(self) -> datetime:
        return self._lease.acquired_at

    @property
    def expires_at(self) -> datetime:
        return self._lease.expires_at

    @property
    def ttl_seconds(self) -> int:
        return self._lease.ttl_seconds

    @property
    def fencing_token(self) -> int:
        return self._lease.fencing_token

    @property
    def acquisition_count(self) -> int:
        return self._lease.acquisition_count

    @property
    def reentrant(self) -> bool:
        return self._lease.reentrant

    @property
    def intent(self) -> Intent | None:
        return self._lease.intent

    @property
    def parent_task(self) -> str | None:
        return self._lease.parent_task

    @property
    def lease(self) -> Lease:
        return self._lease

    def check_lost(self) -> None:
        if self._heartbeat_lost.is_set():
            err = self._heartbeat_error_holder.get("error") or swarmlock_errors.LeaseLostError(
                "lease lost",
                details={"lease_id": self._lease.lease_id},
            )
            raise err

    async def refresh(self) -> Lease:
        result = await self._client.inspect(InspectRequest(
            resource=self._lease.resource, include_intent=True,
        ))
        if result.status == "found" and result.lease_id == self._lease.lease_id:
            assert result.lease_id is not None
            assert result.holder is not None
            assert result.acquired_at is not None
            assert result.expires_at is not None
            assert result.fencing_token is not None
            assert result.acquisition_count is not None
            self._lease = Lease(
                lease_id=result.lease_id,
                resource=result.resource,
                holder=result.holder,
                acquired_at=result.acquired_at,
                expires_at=result.expires_at,
                ttl_seconds=self._lease.ttl_seconds,
                fencing_token=result.fencing_token,
                acquisition_count=result.acquisition_count,
                reentrant=False,
                intent=result.intent,
                parent_task=self._lease.parent_task,
            )
        return self._lease


# ─────────────────────────────────────────────────────────────
# Main Swarmlock client
# ─────────────────────────────────────────────────────────────

class Swarmlock:
    """High-level Swarmlock coordinator client (spec §9).

    Parameters
    ----------
    backend : str | Backend
        Either a string identifier ("in_process", "file", "redis") or a
        pre-built backend instance.
    **kwargs
        Forwarded to the backend constructor when ``backend`` is a string.
        Common: ``admin_token``, ``url`` (Redis), ``root`` (File).

    Examples
    --------
    Async::

        async with Swarmlock(backend="in_process") as sl:
            async with await sl.lease(resource="r/1", holder="a", ttl_seconds=60) as lease:
                ...

    Sync::

        with Swarmlock(backend="file") as sl:
            with sl.lease_sync(resource="r/1", holder="a", ttl_seconds=60) as lease:
                ...

    Low-level::

        sl = Swarmlock(backend="in_process")
        await sl.start()
        result = await sl.acquire(AcquireRequest(...))
        ...
        await sl.stop()
    """

    def __init__(self, backend: str | Backend, **kwargs: Any) -> None:
        self._backend: Backend = _resolve_backend(backend, **kwargs)
        self._started = False
        self._owns_backend = isinstance(backend, str)

    # ─── Lifecycle ────────────────────────────────────────────

    async def start(self) -> None:
        """Initialize the backend (Redis pool, file locks, etc.)."""
        if not self._started:
            await self._backend.start()
            self._started = True

    async def stop(self) -> None:
        """Release backend resources on shutdown."""
        if self._started:
            await self._backend.stop()
            self._started = False

    async def __aenter__(self) -> "Swarmlock":
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.stop()

    def __enter__(self) -> "Swarmlock":
        # Sync lifecycle: run start/stop in worker threads.
        if not self._started:
            _run_coro_sync(self._backend.start())
            self._started = True
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self._started:
            _run_coro_sync(self._backend.stop())
            self._started = False

    # ─── Low-level verb passthroughs (spec §9.3) ──────────────

    async def acquire(self, request: AcquireRequest) -> AcquireResult:
        return await self._backend.acquire(request)

    async def renew(self, request: RenewRequest) -> RenewResult:
        return await self._backend.renew(request)

    async def release(self, request: ReleaseRequest) -> ReleaseResult:
        return await self._backend.release(request)

    async def inspect(self, request: InspectRequest) -> InspectResult:
        return await self._backend.inspect(request)

    async def list(self, request: ListRequest) -> ListResult:
        return await self._backend.list(request)

    async def steal(self, request: StealRequest) -> StealResult:
        return await self._backend.steal(request)

    async def history(self, request: HistoryRequest) -> HistoryResult:
        return await self._backend.history(request)

    async def revoke_all(self, request: RevokeAllRequest) -> RevokeAllResult:
        return await self._backend.revoke_all(request)

    # ─── Async context manager: high-level (spec §9.1) ────────

    async def lease(
        self,
        resource: str,
        holder: str,
        ttl_seconds: int,
        *,
        trace_id: str | None = None,
        wait: WaitMode = "queue",
        intent: Intent | None = None,
        heartbeat_interval: float | None = None,
        on_released: Any = None,
        acquire_kwargs: dict[str, Any] | None = None,
    ) -> "AsyncLeaseContext":
        """Return an async context manager that acquires a lease with auto-heartbeat.

        Usage per spec §9.1::

            async with await sl.lease(
                resource="orders/checkout/cart-7",
                holder="agent-42",
                ttl_seconds=300,
                trace_id="abc123",
                intent=Intent(reason="applying discount"),
            ) as lease:
                ...

        Parameters
        ----------
        resource : str
        holder : str
        ttl_seconds : int
        trace_id : str | None
            Required for reentrant acquire (same trace_id re-enters safely).
        wait : WaitMode
            "queue" (default), "fail", or "steal-after=N".
        intent : Intent | None
            Audit metadata for observability.
        heartbeat_interval : float | None
            Seconds between renewals. Defaults to ``ttl_seconds / 5``.
        on_released : Any
            Optional async or sync callback invoked when the lease is
            released (or lost). Receives the lease handle.
        """
        ctx = AsyncLeaseContext(
            client=self,
            resource=resource,
            holder=holder,
            ttl_seconds=ttl_seconds,
            trace_id=trace_id,
            wait=wait,
            intent=intent,
            heartbeat_interval=heartbeat_interval,
            on_released=on_released,
            acquire_kwargs=acquire_kwargs or {},
        )
        # Eagerly call __aenter__ so we return an already-acquired handle.
        # Caller still writes `async with await sl.lease(...) as lease:`
        # which makes this fit the spec example exactly.
        await ctx.__aenter__()
        ctx._eagerly_acquired = True
        return ctx

    # ─── Sync context manager: high-level (spec §9.2) ─────────

    def lease_sync(
        self,
        resource: str,
        holder: str,
        ttl_seconds: int,
        *,
        trace_id: str | None = None,
        wait: WaitMode = "queue",
        intent: Intent | None = None,
        heartbeat_interval: float | None = None,
        on_released: Any = None,
        acquire_kwargs: dict[str, Any] | None = None,
    ) -> "SyncLeaseContext":
        """Return a sync context manager that acquires a lease with auto-heartbeat.

        Identical to ``lease()`` but uses a daemon ``threading.Thread`` for
        the heartbeat, suitable for synchronous code.
        """
        return SyncLeaseContext(
            client=self,
            resource=resource,
            holder=holder,
            ttl_seconds=ttl_seconds,
            trace_id=trace_id,
            wait=wait,
            intent=intent,
            heartbeat_interval=heartbeat_interval,
            on_released=on_released,
            acquire_kwargs=acquire_kwargs or {},
        )


# ─────────────────────────────────────────────────────────────
# Context managers
# ─────────────────────────────────────────────────────────────

class AsyncLeaseContext:
    """Async context manager returned by Swarmlock.lease()."""

    def __init__(
        self,
        client: Swarmlock,
        resource: str,
        holder: str,
        ttl_seconds: int,
        trace_id: str | None,
        wait: WaitMode,
        intent: Intent | None,
        heartbeat_interval: float | None,
        on_released: Any,
        acquire_kwargs: dict[str, Any],
    ) -> None:
        self._client = client
        self._request = AcquireRequest(
            resource=resource,
            holder=holder,
            ttl_seconds=ttl_seconds,
            trace_id=trace_id,
            wait=wait,
            intent=intent,
        )
        self._acquire_kwargs = acquire_kwargs
        self._heartbeat_interval = (
            heartbeat_interval
            if heartbeat_interval is not None
            else max(0.1, ttl_seconds / DEFAULT_HEARTBEAT_DIVISOR)
        )
        self._on_released = on_released
        self._handle: AsyncLeaseHandle | None = None
        self._heartbeat_task: asyncio.Task | None = None
        self._heartbeat_stop: asyncio.Event | None = None
        self._heartbeat_lost: asyncio.Event | None = None
        self._heartbeat_error_holder: dict[str, Any] = {}
        self._eagerly_acquired: bool = False

    async def __aenter__(self) -> AsyncLeaseHandle:
        # If Swarmlock.lease() already entered the context (eagerly),
        # just return the existing handle.
        if self._eagerly_acquired and self._handle is not None:
            return self._handle
        if not self._client._started:
            await self._client.start()
        result = await self._client._backend.acquire(self._request)
        if not result.is_acquired:
            # Surface the failure as the canonical exception
            if result.status == "queued":
                raise swarmlock_errors.ResourceQueuedError(
                    "resource held by another holder; queued",
                    details={
                        "resource": result.current_lease_id or "",
                        "queue_position": result.queue_position or 0,
                        "retry_after_ms": result.retry_after_ms,
                    },
                )
            raise swarmlock_errors.ResourceHeldError(
                f"acquire failed: {result.status}",
                details={
                    "resource": self._request.resource,
                    "status": result.status,
                    "current_lease_id": result.current_lease_id,
                    "current_holder": result.current_holder,
                    "current_fencing_token": result.current_fencing_token,
                    "retry_after_ms": result.retry_after_ms,
                },
            )
        assert result.lease is not None
        # Spin up heartbeat task
        self._heartbeat_stop = asyncio.Event()
        self._heartbeat_lost = asyncio.Event()
        loop = asyncio.get_running_loop()
        self._heartbeat_task = loop.create_task(_async_heartbeat_loop(
            backend=self._client._backend,
            lease_id=result.lease.lease_id,
            holder=result.lease.holder,
            interval_seconds=self._heartbeat_interval,
            stop_event=self._heartbeat_stop,
            lost_event=self._heartbeat_lost,
            lost_error_holder=self._heartbeat_error_holder,
        ))
        self._handle = AsyncLeaseHandle(
            lease=result.lease,
            client=self._client,
            heartbeat_task=self._heartbeat_task,
            heartbeat_stop=self._heartbeat_stop,
            heartbeat_lost=self._heartbeat_lost,
            heartbeat_error_holder=self._heartbeat_error_holder,
        )
        return self._handle

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> bool:
        if self._handle is None:
            return False
        # If we eagerly acquired on behalf of the caller, the `async with`
        # is what releases us. Always release on exit.
        # Stop heartbeat first
        if self._heartbeat_stop is not None:
            self._heartbeat_stop.set()
        if self._heartbeat_task is not None:
            try:
                await asyncio.wait_for(
                    asyncio.shield(self._heartbeat_task),
                    timeout=self._heartbeat_interval * 2,
                )
            except (asyncio.TimeoutError, asyncio.CancelledError, Exception):  # noqa: BLE001
                self._heartbeat_task.cancel()
        # If heartbeat detected loss, surface it
        if self._heartbeat_lost is not None and self._heartbeat_lost.is_set():
            err = self._heartbeat_error_holder.get("error")
            if err is not None:
                # Run callback if given
                if self._on_released is not None:
                    try:
                        if asyncio.iscoroutinefunction(self._on_released):
                            await self._on_released(self._handle)
                        else:
                            self._on_released(self._handle)
                    except Exception:  # noqa: BLE001
                        pass
                # Don't suppress — caller sees the error
                raise err
        # Normal release path
        try:
            await self._client._backend.release(ReleaseRequest(
                lease_id=self._handle.lease_id,
                holder=self._handle.holder,
                reason="done" if exc_type is None else "error",
            ))
            self._handle._released = True
        finally:
            if self._on_released is not None:
                try:
                    if asyncio.iscoroutinefunction(self._on_released):
                        await self._on_released(self._handle)
                    else:
                        self._on_released(self._handle)
                except Exception:  # noqa: BLE001
                    pass
        # Don't suppress original exception
        return False


class SyncLeaseContext:
    """Sync context manager returned by Swarmlock.lease_sync()."""

    def __init__(
        self,
        client: Swarmlock,
        resource: str,
        holder: str,
        ttl_seconds: int,
        trace_id: str | None,
        wait: WaitMode,
        intent: Intent | None,
        heartbeat_interval: float | None,
        on_released: Any,
        acquire_kwargs: dict[str, Any],
    ) -> None:
        self._client = client
        self._request = AcquireRequest(
            resource=resource,
            holder=holder,
            ttl_seconds=ttl_seconds,
            trace_id=trace_id,
            wait=wait,
            intent=intent,
        )
        self._acquire_kwargs = acquire_kwargs
        self._heartbeat_interval = (
            heartbeat_interval
            if heartbeat_interval is not None
            else max(0.1, ttl_seconds / DEFAULT_HEARTBEAT_DIVISOR)
        )
        self._on_released = on_released
        self._handle: LeaseHandle | None = None
        self._heartbeat_thread: threading.Thread | None = None
        self._heartbeat_stop: threading.Event | None = None
        self._heartbeat_lost: threading.Event | None = None
        self._heartbeat_error_holder: dict[str, Any] = {}

    def __enter__(self) -> LeaseHandle:
        if not self._client._started:
            _run_coro_sync(self._client._backend.start())
            self._client._started = True
        # Acquire
        result = _run_coro_sync(self._client._backend.acquire(self._request))
        if not result.is_acquired:
            if result.status == "queued":
                raise swarmlock_errors.ResourceQueuedError(
                    "resource held by another holder; queued",
                    details={
                        "resource": result.current_lease_id or "",
                        "queue_position": result.queue_position or 0,
                        "retry_after_ms": result.retry_after_ms,
                    },
                )
            raise swarmlock_errors.ResourceHeldError(
                f"acquire failed: {result.status}",
                details={
                    "resource": self._request.resource,
                    "status": result.status,
                    "current_lease_id": result.current_lease_id,
                    "current_holder": result.current_holder,
                    "current_fencing_token": result.current_fencing_token,
                    "retry_after_ms": result.retry_after_ms,
                },
            )
        assert result.lease is not None
        # Spin up heartbeat thread
        self._heartbeat_stop = threading.Event()
        self._heartbeat_lost = threading.Event()
        self._heartbeat_thread = threading.Thread(
            target=_sync_heartbeat_loop,
            args=(
                self._client._backend,
                result.lease.lease_id,
                result.lease.holder,
                self._heartbeat_interval,
                self._heartbeat_stop,
                self._heartbeat_lost,
                self._heartbeat_error_holder,
            ),
            daemon=True,
        )
        self._heartbeat_thread.start()
        self._handle = LeaseHandle(
            lease=result.lease,
            client=self._client,
            heartbeat_stop=self._heartbeat_stop,
            heartbeat_lost=self._heartbeat_lost,
            heartbeat_error_holder=self._heartbeat_error_holder,
            heartbeat_thread=self._heartbeat_thread,
        )
        return self._handle

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        if self._handle is None:
            return False
        # Stop heartbeat first
        if self._heartbeat_stop is not None:
            self._heartbeat_stop.set()
        if self._heartbeat_thread is not None:
            self._heartbeat_thread.join(timeout=self._heartbeat_interval * 2 + 1)
        # If heartbeat detected loss, surface it
        if self._heartbeat_lost is not None and self._heartbeat_lost.is_set():
            err = self._heartbeat_error_holder.get("error")
            if err is not None:
                if self._on_released is not None:
                    try:
                        self._on_released(self._handle)
                    except Exception:  # noqa: BLE001
                        pass
                raise err
        # Normal release path
        try:
            _run_coro_sync(self._client._backend.release(ReleaseRequest(
                lease_id=self._handle.lease_id,
                holder=self._handle.holder,
                reason="done" if exc_type is None else "error",
            )))
            self._handle._released = True
        finally:
            if self._on_released is not None:
                try:
                    self._on_released(self._handle)
                except Exception:  # noqa: BLE001
                    pass
        return False


__all__ = [
    "Swarmlock",
    "AsyncLeaseHandle",
    "LeaseHandle",
    "AsyncLeaseContext",
    "SyncLeaseContext",
]
