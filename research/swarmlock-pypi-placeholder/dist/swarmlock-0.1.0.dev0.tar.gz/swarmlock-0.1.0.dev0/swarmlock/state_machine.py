"""
swarmlock.state_machine — Pure functions for the §4 lease lifecycle state machine.

Used by backends to validate transitions before mutating storage.
The state machine is intentionally pure (no I/O, no time) so it can be tested
deterministically. Time-dependent logic (TTL expiry, reaping) lives in the
backends, which call these functions to validate each proposed transition.

Spec §4.1 — States: NONE, HELD, EXPIRED, STOLEN, RELEASED, REVOKED
Spec §4.2 — Transitions
Spec §14 — Acquisition counter semantics
"""
from __future__ import annotations

from .types import LeaseState

# ─────────────────────────────────────────────────────────────
# Allowed transitions (from §4.2)
# ─────────────────────────────────────────────────────────────

# Map of (from_state, trigger) -> to_state
# Triggers: acquire, renew, release, steal, revoke_all, expire
_ALLOWED: dict[tuple[LeaseState, str], LeaseState] = {
    # NONE -> HELD via fresh acquire
    ("NONE", "acquire"): "HELD",
    # HELD -> HELD via renew OR reentrant acquire
    ("HELD", "renew"): "HELD",
    ("HELD", "acquire"): "HELD",       # reentrant — counter++, same state
    # HELD -> RELEASED via release (only when acquisition_count reaches 0)
    ("HELD", "release"): "RELEASED",
    # HELD -> REVOKED via revoke_all (force-zero counter)
    ("HELD", "revoke_all"): "REVOKED",
    # HELD -> EXPIRED via TTL elapsing
    ("HELD", "expire"): "EXPIRED",
    # EXPIRED -> HELD via fresh acquire by new holder (fencing_token++)
    ("EXPIRED", "acquire"): "HELD",
    # EXPIRED -> STOLEN via steal
    ("EXPIRED", "steal"): "STOLEN",
    # STOLEN -> HELD (implicit; new holder now holds)
    ("STOLEN", "acquire"): "HELD",
}


# Terminal states (cannot transition out of)
_TERMINAL: frozenset[LeaseState] = frozenset({"RELEASED", "REVOKED"})


# ─────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────

def is_allowed(from_state: LeaseState, trigger: str) -> bool:
    """Return True if (from_state, trigger) is a defined transition."""
    return (from_state, trigger) in _ALLOWED


def next_state(from_state: LeaseState, trigger: str) -> LeaseState:
    """Compute the next state for a given trigger.

    Raises KeyError if the transition is not defined.
    """
    try:
        return _ALLOWED[(from_state, trigger)]
    except KeyError as e:
        raise InvalidTransition(from_state, trigger) from e


def is_terminal(state: LeaseState) -> bool:
    """True if the state is terminal — no outgoing transitions."""
    return state in _TERMINAL


def can_acquire_freshly(state: LeaseState) -> bool:
    """True if a fresh (non-reentrant) acquire is allowed from this state.

    Spec §14.1: fresh acquire succeeds only when resource is NONE.
    EXPIRED and STOLEN both transition to HELD but are NOT reentrant —
    they are fresh acquisitions by a new holder.
    """
    return state in ("NONE", "EXPIRED", "STOLEN")


def can_reenter(state: LeaseState) -> bool:
    """True if a reentrant acquire (matching (resource, holder, trace_id)) is allowed.

    Spec §14.1: only allowed when state == HELD.
    """
    return state == "HELD"


def can_steal(state: LeaseState) -> bool:
    """Spec §5.6 v0.3 simplified: steal succeeds only on EXPIRED (or RELEASED).
    On HELD → 409 Conflict (use revoke_all instead).
    """
    return state in ("EXPIRED", "RELEASED")


# ─────────────────────────────────────────────────────────────
# Exceptions
# ─────────────────────────────────────────────────────────────

class InvalidTransition(KeyError):
    """Raised when a (state, trigger) pair is not defined in §4.2."""

    def __init__(self, state: LeaseState, trigger: str) -> None:
        super().__init__(f"No transition defined for state={state!r} trigger={trigger!r}")
        self.state = state
        self.trigger = trigger


__all__ = [
    "is_allowed",
    "next_state",
    "is_terminal",
    "can_acquire_freshly",
    "can_reenter",
    "can_steal",
    "InvalidTransition",
]
